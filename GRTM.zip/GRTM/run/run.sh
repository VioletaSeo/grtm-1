#!/bin/csh
# Forward modeling using the Generalized Reflection and Transmission Method (GRTM)

# input parameter file
set input_para_file = ./demo/inputfile/input_basic.par
set output_para_file=./demo/outputfile

# run executable
../src/bin/grtm ${input_para_file} ${output_para_file}
