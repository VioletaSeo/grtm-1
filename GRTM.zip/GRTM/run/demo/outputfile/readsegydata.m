function data = readsegydata(filename)
% read segy data
% Input:
%    filename: name of the segy file
% Output:
%    data.nt = nt;          number of time samples
%    data.dt = dt;          time sampling (sec)
%    data.t  = t;           time (sec)
%    data.nr = nr;          number of receivers
%    data.gx = gx;          receiver x-coordinates
%    data.gy = gy;          receiver y-coordinates
%    data.gz = gz;          receiver z-coordinates
%    data.sz = sz;          source depth
%    data.nline = nline;    receiver line number
%    data.ntrace = ntrace;  receiver trace number
%    data.trace = trace;    receiver trace data
%
% Xinding Fang
% 2020-11-20
%=============================================================

fid=fopen(filename,'rb');

fseek(fid,0,'eof');
fl=ftell(fid); % file size

fseek(fid,114,'bof');
nt=fread(fid,1,'uint16','ieee-le'); % number of data samples
dt=fread(fid,1,'uint16','ieee-le')*1e-6; % sample interval (unit: sec)
nr=fl/(240+nt*4); % number of traces

fseek(fid,80,'bof');
gx=zeros(nr,1);
gy=zeros(nr,1);
for i=1:nr
    gx(i)=fread(fid,1,'int32','ieee-le');
    gy(i)=fread(fid,1,'int32','ieee-le');
    fseek(fid,(240+nt*4)*i+80,'bof');
end

fseek(fid,40,'bof');
gz=zeros(nr,1);
for i=1:nr
    gz(i)=fread(fid,1,'int32','ieee-le');
    fseek(fid,(240+nt*4)*i+40,'bof');
   
end
%%%%%%%%line number
fseek(fid,8,'bof');
nline = zeros(nr,1);
for i=1:nr
    nline(i)=fread(fid,1,'int32','ieee-le');
    fseek(fid,(240+nt*4)*i+8,'bof');
end
%%%%%%%% trace number
fseek(fid,0,'bof');
ntrace=zeros(nr,1);
for i=1:nr
    ntrace(i)=fread(fid,1,'int32','ieee-le');
    fseek(fid,(240+nt*4)*i+0,'bof');
end


%%%%%%% source depth
fseek(fid,44,'bof');
sz=fread(fid,1,'int32','ieee-le');   % source depth

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
t=[0:nt-1]*dt; % sec
fseek(fid,0,'bof');
trace=fread(fid,inf,'float32','ieee-le'); % waveforms

trace=reshape(trace,nt+60,nr);
trace=trace(61:end,:); % remove headers to get raw trace data

fclose(fid);

data.nt = nt;
data.dt = dt;
data.t  = t;
data.nr = nr;
data.gx = gx;
data.gy = gy;
data.gz = gz;
data.sz = sz;
data.nline = nline;
data.ntrace = ntrace;
data.trace = trace;

end