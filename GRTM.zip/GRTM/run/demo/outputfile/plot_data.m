%
% This matlab script is used to show how to read and plot the output data.
%
% Xinding Fang
% 2020-11-20
%--------------------------

clc, clear all, close all;



filename{1}=['data_vr_shot001.sgy']; % r-comp
filename{2}=['data_vt_shot001.sgy']; % t-comp
filename{3}=['data_vz_shot001.sgy']; % z-comp

for i=1:3
    data{i} = readsegydata(['./' filename{i}]);
end


figure('color','wh','position',[100,100,1400,1000])
subplot(2,3,1:3); hold on;
plot3(data{1}.gx,data{1}.gy,data{1}.gz,'bo','MarkerSize',6,'MarkerFaceColor','b');
plot3(0,0,data{1}.sz,'rh','MarkerSize',8,'MarkerFaceColor','r');
for i=1:data{1}.nr
    text(data{1}.gx(i)+1,data{1}.gy(i)+1,data{1}.gz(i),num2str(i),'FontSize',10);
end

legend('Receivers','Source','Location','NorthWest');
xlabel('X/m','FontSize',18);
ylabel('Y/m','FontSize',18);
zlabel('Z/m','FontSize',18);
grid on
axis tight; axis equal;
set(gca,'fontsize',18,'zdir','reverse','box','on');
view(45,45);

TT={'Radial';'Transverse';'Vertical'};
for icomp=1:3
    subplot(2,3,icomp+3); hold on;
    imagesc(1:data{icomp}.nr,data{icomp}.t,data{icomp}.trace);
    xlabel('Receiver #','fontsize',18);
    ylabel('Time (sec)','fontsize',18);
    title(TT{icomp},'fontsize',18);
    set(gca,'fontsize',18,'ydir','rev','box','on');
    axis tight;
end
colormap(gray);

