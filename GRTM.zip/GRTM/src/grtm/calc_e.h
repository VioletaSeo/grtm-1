#pragma once

#include "cwp_mini.h"

void calcE(const double k, const dcomplex omega, const double mu,
	const dcomplex alpha, const dcomplex beta,
	const dcomplex gamma, const dcomplex nu, dcomplex E[4][4]);

void calcE11E12(const double k, const dcomplex omega, const double mu,
	const dcomplex alpha, const dcomplex beta,
	const dcomplex gamma, const dcomplex nu, dcomplex E11[2][2], dcomplex E12[2][2]);

void calcE21E22(const double k, const dcomplex omega, const double mu,
	const dcomplex alpha, const dcomplex beta,
	const dcomplex gamma, const dcomplex nu, dcomplex E21[2][2], dcomplex E22[2][2]);

void assemEdEu(dcomplex Edd[4][4], dcomplex Euu[4][4], dcomplex Eud[4][4], dcomplex Edu[4][4]);

void partMat44to22(dcomplex M44[4][4], dcomplex M11[2][2], dcomplex M12[2][2], dcomplex M21[2][2], dcomplex M22[2][2]);

