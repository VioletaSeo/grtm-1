#include "wavelet.h"
#include <math.h>
#include "cwp_mini.h"
#include <string.h>

/**
funtction to calclate the spectrum of wavelet of source
*/
dcomplex wavelet(dcomplex w, double fc, double tou, char* Type_STF,double fwth)
{
	double wc;
	dcomplex ctemp,temp,temp2,temp1;
    dcomplex ctemp1;
	wc = 2.*PI*fc;
	dcomplex rp, rp1,rp2;
	double rrp;
	//////////////////delay time
	rp=dcmplx2(0,1.);
	rp1=w;
	rp=dcmul2(rp,rp1);
	rrp=-tou;
         ctemp1=dcrmul2(rp,rrp);
         ctemp1=dcexp(ctemp1);
    //////////////////     
	if (!strcmp(Type_STF,"Ricker")) {
        rp=w;
        rrp= 1. / wc;
		ctemp = dcrmul2(rp,rrp);
		ctemp = dcmul2(ctemp, ctemp);
		rp=ctemp;
		rp=dcneg2(rp);
		
		rrp=1. / wc;
		rp1=dcrmul2(ctemp, rrp);
		rp=dcexp(rp);
		rp2=dcmul2(rp1, rp);
		return dcmul2(rp2,ctemp1);
                
	}

	if (!strcmp(Type_STF, "Triangle")) {

               rrp=fwth/4.;
               rp=dcmplx2(rrp,0);
               rp1=dcmplx2(0,1);
               rp2=w;
               rp=dcmul2(rp,rp2);
               temp1=dcmul2(rp,rp1);
               rrp=fwth/4.;
               rp=dcmplx2(rrp,0);
               rp1=w;
               rp=dcmul2(rp,rp1);
                rp2=dcmplx2(0,-1);
               temp2=dcmul2(rp,rp2);
               temp=dcsub(dcexp(temp1),dcexp(temp2));
               rp=dcmplx2(0,2);
               temp=dcdiv2(temp,rp);
               rrp=fwth/4.;
               rp=dcmplx2(rrp,0);
               rp1=w;
               rp=dcmul2(rp,rp1);
               temp=dcdiv2(temp,rp);
               temp=dcmul2(temp,temp);
               temp=dcmul2(temp,ctemp1);
               return temp;


	}

	if (!strcmp(Type_STF, "SSTEP")) {

	}

	if (!strcmp(Type_STF, "Ramp")) {

	}

	if (!strcmp(Type_STF, "Bouchon")) {

	}

	if (!strcmp(Type_STF, "B(shift)")) {

	}

	if (!strcmp(Type_STF, "Green")) {

	}

	if (!strcmp(Type_STF, "Trapezoid")) {

	}

	if (!strcmp(Type_STF, "Heaviside")) {

	}

	//default type set as "Ricker"		
	ctemp = dcrmul(w, 1. / wc);
	ctemp = dcmul(ctemp, ctemp);

	return dcmul(dcrmul(ctemp, 1. / wc), dcexp(dcneg(ctemp)));
}
void eig44(FKRTmodel *model,dcomplex omega1,double k,dcomplex eig[4],dcomplex eigvector[16],int lay)
{
double  a1, a2, a3, a4, a5,a6,a7;
 double *L,*F,*A,*P,*C,W,WC;
  int i,j;
  dcomplex temp1,temp4, temp2,temp3,temp10,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16,t0,t00;
  W=omega1.r;
  WC=-omega1.i;
  L=model->LL;
  F=model->FF;
  P=model->Rho;
  A=model->AA;
  C=model->CC;

  //dcomplex *eig,*eigvector,*feig,*feigvector;

   /*eig=(dcomplex*)malloc(sizeof(dcomplex)*4);
   eigvector=(dcomplex*)malloc(sizeof(dcomplex)*4*4);
   feig=(dcomplex*)malloc(sizeof(dcomplex)*4);
   feigvector=(dcomplex*)malloc(sizeof(dcomplex)*4*4);*/
if(k==0)
k=0.001;
   a1=k;
   a2=1./L[lay];
   a3=-F[lay]*k/C[lay];
   a4=1./C[lay];
   a5=A[lay]*k*k-F[lay]*F[lay]*k*k/C[lay]-P[lay]*(W*W-WC*WC);
   a6=2*W*WC*P[lay];
   a7=-P[lay]*(W*W-WC*WC);


/////////////eigvalue 1 2 3 4;
   t1=dcadd(dcmplx(-4*a1*a1*a4*a5,-a1*a1*a4*a6*4),dcmplx(4*a1*a2*a3*a5,a1*a2*a3*a6*4));

   t2=dcadd(dcmplx(4*a1*a3*a4*a7 + a2*a2*a5*a5,a1*a3*a4*a6*4),dcmplx(- a2*a2*a6*a6,a2*a2*a5*a6*2));

   t3=dcadd(dcmplx(- 4*a2*a3*a3*a7,- a2*a3*a3*a6*4),dcmplx(- 2*a2*a4*a5*a7,- a2*a4*a5*a6*2));

   t4=dcadd(dcmplx(2*a2*a4*a6*a6,- a2*a4*a6*a7*2),dcmplx(- a4*a4*a6*a6+a4*a4*a7*a7, a4*a4*a6*a7*2));


   t5= dcmplx(2*a1*a3 + a2*a5+ a4*a7,a2*a6+ a4*a6);
   temp1=dcsqrt( dcadd(dcadd(t1,t2),dcadd(t3,t4)) );
   temp2=dcsqrt(dcsub(t5,temp1));
  

  
   eig[0]=dcrmul(dcrmul(temp2,sqrt(2)),1./2);
   eig[2]=dcneg(eig[0]);
  // temp1=dcsqrt( dcadd(dcadd(t1,t2),dcadd(t3,t4)) );
   temp2=dcsqrt(dcadd(t5,temp1));
   eig[1]=dcrmul(dcrmul(temp2,sqrt(2)),1./2);
   eig[3]=dcneg(eig[1]);
/////////////////////////eigvector
  
//  temp1=dcsqrt( dcadd(dcadd(t1,t2),dcadd(t3,t4)) );
  temp10=dcrmul(temp1,1./2);

  temp2=dcmplx(a1*a3 + a4*a7,a4*a6);
  temp2=dcdiv(temp2,dcmplx(a1*a5 - a3*a7, a1*a6 - a3*a6));
  temp3=dcmplx(a1*a3 + (a2*a5)/2+ (a4*a7)/2, (a2*a6)/2 + (a4*a6)/2 );
  temp3=dcsub(temp3,temp10);
  temp4=dcmplx(a1*a5 - a3*a7, a1*a6 - a3*a6);
  temp3=dcdiv(temp3,temp4);
  temp2=dcsub(temp2,temp3);
  eigvector[0*4+0]=temp2;
  eigvector[0*4+2]=eigvector[0*4+0];
  //////////
  temp2=dcmplx(a1*a3 + a4*a7,a4*a6);
  temp2=dcdiv(temp2,dcmplx(a1*a5 - a3*a7, a1*a6 - a3*a6));
  temp3=dcmplx(a1*a3 + (a2*a5)/2+ (a4*a7)/2, (a2*a6)/2 + (a4*a6)/2 );
  temp4=dcmplx(a1*a5 - a3*a7, a1*a6 - a3*a6);
  temp3=dcadd(temp3,temp10);
  temp3=dcdiv(temp3,temp4);
  temp2=dcsub(temp2,temp3);

 
/////////////////////////////
  
  eigvector[0*4+1]=temp2;
  eigvector[0*4+3]=eigvector[0*4+1];


//////////

  t5=dcmplx(2*a1*a3+a2*a5+a4*a7,a2*a6+a4*a6);
  t6=dcmplx(a1*a2*a5/2.+a1*a4*a7/2.-a2*a3*a7,a1*a2*a6/2.+a1*a4*a6/2.-a2*a3*a6);
  t7=dcmplx(a1*a5-a3*a7,a1*a6-a3*a6);
  t7=dcmul(dcmplx(a1*a1+a2*a7,a2*a6),t7);
  t7=dcrmul(t7,2);

  temp2=dcrmul(dcsqrt(dcsub(t5,temp1)),sqrt(2.));
  temp3=dcadd(t6,dcrmul(temp1,a1/2.));
  eigvector[1*4+0]=dcdiv(dcmul(temp2,temp3),t7);
  eigvector[1*4+2]=dcneg(eigvector[1*4+0]);

  temp2=dcrmul(dcsqrt(dcadd(t5,temp1)),sqrt(2.));
  temp3=dcsub(t6,dcrmul(temp1,a1/2.));
  eigvector[1*4+1]=dcdiv(dcmul(temp2,temp3),t7);
  eigvector[1*4+3]=dcneg(eigvector[1*4+1]);

////////////////eigvalue 3,4;
   t1=dcadd(dcmplx(-4*a1*a1*a4*a5,-a1*a1*a4*a6*4),dcmplx(4*a1*a2*a3*a5,a1*a2*a3*a6*4));

   t2=dcadd(dcmplx(4*a1*a3*a4*a7 + a2*a2*a5*a5,a1*a3*a4*a6*4),dcmplx(- a2*a2*a6*a6,a2*a2*a5*a6*2));

   t3=dcadd(dcmplx(- 4*a2*a3*a3*a7,- a2*a3*a3*a6*4),dcmplx(- 2*a2*a4*a5*a7,- a2*a4*a5*a6*2));

   t4=dcadd(dcmplx(2*a2*a4*a6*a6,- a2*a4*a6*a7*2),dcmplx(- a4*a4*a6*a6+a4*a4*a7*a7, a4*a4*a6*a7*2));


   t5= dcmplx(2*a1*a3 + a2*a5+ a4*a7,a2*a6+ a4*a6);
   t1=dcsqrt( dcadd(dcadd(t1,t2),dcadd(t3,t4)) );

   t2=dcsub(t5,t1);
if(t2.r>0)
   t2=dcmul(dcsqrt(dcmul(t2,dcmul(t2,t2))),dcmplx(0,1));
 else
   t2=dcneg(dcmul(dcsqrt(dcmul(t2,dcmul(t2,t2))),dcmplx(0,1)));
   t3=dcrmul(dcmul(dcmplx(a7,a6),t2),sqrt(2));

   t4=dcrmul(dcmul(dcmplx(-a2*a6,a1*a1+a2*a7),dcmplx(a1*a5-a3*a7,a1*a6-a3*a6)),4);

   t5=dcsqrt(dcsub(t5,t1));

   t6=dcmplx(a4*a7*a7/3-a4*a6*a6/3-a1*a1*a5/3+2*a1*a3*a7/3,-a1*a1*a6/3+a1*a3*a6*2/3+a4*a6*a7*2/3);
   t7=dcmplx(a1*a5-a3*a7,a1*a6-a3*a6);
   t8=dcrmul(dcmplx(-a2*a6,a1*a1+a2*a7),2);
   t9=dcrmul(dcmul(dcmul(t5,t6),dcmplx(0,3)),sqrt(2));
   t10=dcsub(dcdiv(t3,t4),dcdiv(t9,dcmul(t8,t7)));
   
  //////////////////////
  eigvector[2*4+2]=t10;
  eigvector[2*4+0]=dcneg(eigvector[2*4+2]);

  t5= dcmplx(2*a1*a3 + a2*a5+ a4*a7,a2*a6+ a4*a6);
  t2=dcsqrt(dcadd(t5,t1));

  t3=dcmplx(a4*a7*a7/3-a4*a6*a6/3-a1*a1*a5/3+2*a1*a3*a7/3,-a1*a1*a6/3+a1*a3*a6*2/3+a4*a6*a7*2/3);

  t4=dcrmul(dcmul(dcmplx(-a2*a6,a1*a1+a2*a7),dcmplx(a1*a5-a3*a7,a1*a6-a3*a6)),2);
  
  t6=dcadd(t5,t1);

   if(t6.r>0)
    t6=dcsqrt(dcmul(dcmul(t6,t6),t6));
   else
    t6=dcneg(dcsqrt(dcmul(dcmul(t6,t6),t6)));

  t7=dcmul(dcrmul(dcmul(dcmplx(a7,a6),t6),sqrt(2)),dcmplx(0,1));

  t8=dcmplx(a1*a5-a3*a7,a1*a6-a3*a6);

  t9=dcrmul(dcmplx(-a2*a6,a1*a1+a2*a7),4);
  t10=dcrmul(dcmul(dcmul(t2,t3),dcmplx(0,3)),sqrt(2));
  t11=dcdiv(t10,t4);
  t12=dcmul(t8,t9);
  t13=dcdiv(t7,t12);
  t14=dcsub(t11,t13);
 
  eigvector[2*4+1]=t14;
  eigvector[2*4+3]=dcneg(eigvector[2*4+1]);

  eigvector[3*4+0]=dcmplx(1,0);
  eigvector[3*4+1]=dcmplx(1,0);
  eigvector[3*4+2]=dcmplx(1,0);
  eigvector[3*4+3]=dcmplx(1,0);

                        /*t1=eigvector[0*4+0];t2=eigvector[0*4+1];t3=eigvector[0*4+2];t4=eigvector[0*4+3];
                        t5=eigvector[1*4+0];t6=eigvector[1*4+1];t7=eigvector[1*4+2];t8=eigvector[1*4+3];
                        t9=eigvector[2*4+0];t10=eigvector[2*4+1];t11=eigvector[2*4+2];t12=eigvector[2*4+3];
                        t13=eigvector[3*4+0];t14=eigvector[3*4+1];t15=eigvector[3*4+2];t16=eigvector[3*4+3];*/

                        

 
}
void eig22(FKRTmodel *model,dcomplex omega1,double k,dcomplex eig2[2],dcomplex eig2vector[4],int lay)
{
  double a1,a2,a3;
double *N,*F,*A,*P,*C,*L,W,WC;
dcomplex t1 ,t2,t3,t4;
  W=omega1.r;
  WC=-omega1.i;
  N=model->NN;
  F=model->FF;
  P=model->Rho;
  A=model->AA;
  C=model->CC;
  L=model->LL;
if(k==0)
k=0.001;
  a1=1./L[lay];
  a2=-P[lay]*(W*W-WC*WC)+N[lay]*k*k;
  a3=2.*W*WC*P[lay];

  eig2[0]=dcneg(dcsqrt(dcmplx(a1*a2,a1*a3)));
  eig2[1]=dcneg(eig2[0]);

  t1=dcmplx(a2,a3);
  eig2vector[0]=dcdiv(eig2[0],t1);
  eig2vector[1]=dcneg(eig2vector[0]);
  eig2vector[2]=dcmplx(1.,0);
  eig2vector[3]=dcmplx(1.,0);

t1=eig2vector[0];
t2=eig2vector[1];
t3=eig2vector[2];
t4=eig2vector[3];

                    
  



}
void eig4(double k, double L, double F, double A,double P,double C,double W,double WC,dcomplex eig[4],dcomplex eigvector[16])
{
double  a1, a2, a3, a4, a5,a6,a7;
  //double  k,L,F,A,P,C,W,WC;
  int i,j;
  dcomplex temp1, temp2,temp3,temp10,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16;
  //dcomplex *eig,*eigvector,*feig,*feigvector;

   /*eig=(dcomplex*)malloc(sizeof(dcomplex)*4);
   eigvector=(dcomplex*)malloc(sizeof(dcomplex)*4*4);
   feig=(dcomplex*)malloc(sizeof(dcomplex)*4);
   feigvector=(dcomplex*)malloc(sizeof(dcomplex)*4*4);*/

   a1=k;
   a2=1./L;
   a3=-F*k/C;
   a4=1./C;
   a5=A*k*k-F*F*k*k/C-P*(W*W-WC*WC);
   a6=2*W*WC*P;
   a7=-P*(W*W-WC*WC);
   
/////////////eigvalue 1 2 3 4;
   t1=dcadd(dcmplx(-4*a1*a1*a4*a5,-a1*a1*a4*a6*4),dcmplx(4*a1*a2*a3*a5,a1*a2*a3*a6*4));

   t2=dcadd(dcmplx(4*a1*a3*a4*a7 + a2*a2*a5*a5,a1*a3*a4*a6*4),dcmplx(- a2*a2*a6*a6,a2*a2*a5*a6*2));

   t3=dcadd(dcmplx(- 4*a2*a3*a3*a7,- a2*a3*a3*a6*4),dcmplx(- 2*a2*a4*a5*a7,- a2*a4*a5*a6*2));

   t4=dcadd(dcmplx(2*a2*a4*a6*a6,- a2*a4*a6*a7*2),dcmplx(- a4*a4*a6*a6+a4*a4*a7*a7, a4*a4*a6*a7*2));


   t5= dcmplx(2*a1*a3 + a2*a5+ a4*a7,a2*a6+ a4*a6);
   temp1=dcsqrt( dcadd(dcadd(t1,t2),dcadd(t3,t4)) );
   temp2=dcsqrt(dcsub(t5,temp1));
  /* printf("%lf\n",a1);  printf("%lf\n",t5.i);

   exit(0);*/
   eig[0]=dcrmul(dcrmul(temp2,sqrt(2)),1./2);
   eig[2]=dcneg(eig[0]);
  // temp1=dcsqrt( dcadd(dcadd(t1,t2),dcadd(t3,t4)) );
   temp2=dcsqrt(dcadd(t5,temp1));
   eig[1]=dcrmul(dcrmul(temp2,sqrt(2)),1./2);
   eig[3]=dcneg(eig[1]);
/////////////////////////eigvector
    
  t5= dcmplx(a2*a6*- a4*a6,a4*a7-a2*a5);   
  t6=dcrmul(dcmplx(a3*a6-a1*a6,a1*a5-a3*a7),2);
//  temp1=dcsqrt( dcadd(dcadd(t1,t2),dcadd(t3,t4)) );
  temp10=dcmul(temp1,dcmplx(0,1));
  temp2=dcadd(temp10,t5);
  eigvector[0*4+0]=dcdiv(temp2,t6);
  eigvector[0*4+2]=eigvector[0*4+0];
/////////////////////////////
  temp10=dcmul(temp1,dcmplx(0,1));
  t5= dcmplx(a2*a6*- a4*a6,a4*a7-a2*a5);   
  t6=dcrmul(dcmplx(a3*a6-a1*a6,a1*a5-a3*a7),2);
  temp2=dcsub(t5,temp10);
  eigvector[0*4+1]=dcdiv(temp2,t6);
  eigvector[0*4+3]=eigvector[0*4+1];

//////////

  t5=dcmplx(2*a1*a3+a2*a5+a4*a7,a2*a6+a4*a6);
  t6=dcmplx(a1*a2*a5/2.+a1*a4*a7/2.-a2*a3*a7,a1*a2*a6/2.+a1*a4*a6/2.-a2*a3*a6);
  t7=dcmplx(a1*a5-a3*a7,a1*a6-a3*a6);
  t7=dcmul(dcmplx(a1*a1+a2*a7,a2*a6),t7);
  t7=dcrmul(t7,2);
 /* (2^(1/2)*(t5 -temp1)^(1/2)*( a1*temp1/2 +t6 ))/t7;
  (2^(1/2)*(t5 + temp1)^(1/2)*(t6- a1*temp1/2 ))/t7;*/
  temp2=dcrmul(dcsqrt(dcsub(t5,temp1)),sqrt(2.));
  temp3=dcadd(t6,dcrmul(temp1,a1/2.));
  eigvector[1*4+0]=dcdiv(dcmul(temp2,temp3),t7);
  eigvector[1*4+2]=dcneg(eigvector[1*4+0]);

  temp2=dcrmul(dcsqrt(dcadd(t5,temp1)),sqrt(2.));
  temp3=dcsub(t6,dcrmul(temp1,a1/2.));
  eigvector[1*4+1]=dcdiv(dcmul(temp2,temp3),t7);
  eigvector[1*4+3]=dcneg(eigvector[1*4+1]);

////////////////eigvalue 3,4;
  t5=dcmplx(2*a1*a3+a2*a5+a4*a7,a2*a6+a4*a6);
  t6=dcmplx(2*a1*a3+a2*a5+a4*a7,a2*a6+a4*a6);
  t7=dcmplx(a1*a5-a3*a7,a1*a6-a3*a6);
  t7=dcmul(dcmplx(-a2*a6,a1*a1+a2*a7),t7);
  t8=dcmplx(-a2*a6,a1*a1+a2*a7);
  t9=dcmplx(a1*a5-a3*a7,a1*a6-a3*a6);
  t10=dcmplx(a4*a7*a7/3.-a4*a6*a6/3.-a1*a1*a5/3.+2.*a1*a3*a7/3.,-a1*a1*a6/3.+a1*a3*a6*2./3.+a4*a6*a7*2./3.);
  t11=dcrmul(dcmplx(a7,a6),sqrt(2.));
  temp2=dcmul(dcmplx(0,-1),dcmul(t11, dcsqrt(dcmul(dcmul(dcsub(t5,temp1),dcsub(t5,temp1)),dcsub(t5,temp1))) ));     //  dcsqrt(dcmul(dcmul(dcsub(t5,temp1),dcsub(t5,temp1)),dcsub(t5,temp1)))
  temp2=dcdiv(temp2,dcmul(t8,dcrmul(t9,4.)));
  temp3=dcrmul(dcsqrt(dcsub(t6,temp1)),sqrt(2.));
  temp3=dcmul(dcmul(temp3,t10),dcmplx(0,3));
  temp3=dcdiv(temp3,dcrmul(t7,2.));
  eigvector[2*4+0]=dcadd(temp2,temp3);
  eigvector[2*4+2]=dcneg(eigvector[2*4+0]);
  temp2=dcrmul(dcsqrt(dcadd(t5,temp1)),sqrt(2.));
  temp2=dcmul(dcmul(temp2,t10),dcmplx(0,3));
  temp2=dcdiv(temp2,dcmul(t8,dcrmul(t9,2.)));
  temp3=dcmul(t11,dcsqrt(dcmul( dcadd(t6,temp1),dcmul(dcadd(t6,temp1),dcadd(t6,temp1)))));  //dcsqrt(dcmul( dcadd(t6,temp1),dcmul(dcadd(t6,temp1),dcadd(t6,temp1))))
  temp3=dcmul(temp3,dcmplx(0,1));
  temp3=dcdiv(temp3,dcrmul(t7,4));
  eigvector[2*4+1]=dcsub(temp2,temp3);
  eigvector[2*4+3]=dcneg(eigvector[2*4+1]);

  eigvector[3*4+0]=dcmplx(1,0);
  eigvector[3*4+1]=dcmplx(1,0);
  eigvector[3*4+2]=dcmplx(1,0);
  eigvector[3*4+3]=dcmplx(1,0);
/*- (t11*(t5-temp1 )^(3/2)*1i)/(4*t8*t9) + (2^(1/2)*(t6 -temp1 )^(1/2)*t10*3i)/(2*t7);
(2^(1/2)*(t5+ temp1)^(1/2)*t10*3i)/(2*t8*t9)- (t11*(t6+ temp1)^(3/2)*1i)/(4*t7);*/
/////////////
t1=eig[0];
t2=eig[1];
t2=eig[2];
t3=eig[3];
eig[3]=t1;
eig[2]=t2;
eig[1]=t3;
eig[0]=t4;

                        t1=eigvector[0*4+0];t2=eigvector[0*4+1];t3=eigvector[0*4+2];t4=eigvector[0*4+3];
                        t5=eigvector[1*4+0];t6=eigvector[1*4+1];t7=eigvector[1*4+2];t8=eigvector[1*4+3];
                        t9=eigvector[2*4+0];t10=eigvector[2*4+1];t11=eigvector[2*4+2];t12=eigvector[2*4+3];
                        t13=eigvector[3*4+0];t14=eigvector[3*4+1];t15=eigvector[3*4+2];t16=eigvector[3*4+3];
                        eigvector[3*4+0]=t1;eigvector[3*4+1]=t2;eigvector[3*4+2]=t3;eigvector[3*4+3]=t4;
                        eigvector[2*4+0]=t5;eigvector[2*4+1]=t6;eigvector[2*4+2]=t7;eigvector[2*4+3]=t8;
                        eigvector[1*4+0]=t9;eigvector[1*4+1]=t10;eigvector[1*4+2]=t11;eigvector[1*4+3]=t12;
                        eigvector[0*4+0]=t13;eigvector[0*4+1]=t14;eigvector[0*4+2]=t15;eigvector[0*4+3]=t16;
  







}