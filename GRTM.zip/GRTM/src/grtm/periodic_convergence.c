#include "periodic_convergence.h"
#include "cwp_mini.h"

#define MAXCYCLE 10

void  periodic_convergence(double kn, dcomplex Urtz[3], int flagZero[3], int *convergence,
	int *counter, int numCycle[12], int flagSearchCycle[12])
{
	/**
	* N.B. Initialization of some array must be done before call this function, as following:
	*   counter must be initialized as 0
	*   numCycle[12] must be intialized as 0
	*   flagSearchCycle[12] must be intialized as integers > 0
	* P.S. The static variables maybe result in fault sharing in multi-thread.
	*/

	//static int counter = 0;
	//static int numCycle[12] = { 0,0,0,0,0,0,0,0,0,0,0,0 };
	//static int flagSearchCycle[12] = { 1,1,1,1,1,1,1,1,1,1,1,1 };
	//*********************** N.B. above three variables can't use static for multi-source-receiver-pair
	//memory for peaks and trouphs of U
	static double urpeak[MAXCYCLE][4], urtrof[MAXCYCLE][4], urr[3], uri[3];
	static double utpeak[MAXCYCLE][4], uttrof[MAXCYCLE][4], utr[3], uti[3];
	static double uzpeak[MAXCYCLE][4], uztrof[MAXCYCLE][4], uzr[3], uzi[3];
	double urrSum, utrSum, uzrSum;
	double uriSum, utiSum, uziSum;

	int  i, flagGetAllPeakTrouph[3];

	if (*counter<=2) {
		urr[*counter] = Urtz[0].r;
		uri[*counter] = Urtz[0].i;
		utr[*counter] = Urtz[1].r;
		uti[*counter] = Urtz[1].i;
		uzr[*counter] = Urtz[2].r;
		uzi[*counter] = Urtz[2].i;
	}
	else if (*counter > 2) {
		//searching peaks and troughs in periodic functions
		//ur
		if (flagZero[0] != 0) {
			urr[0] = urr[1];
			uri[0] = uri[1];
			urr[1] = urr[2];
			uri[1] = uri[2];
			urr[2] = Urtz[0].r;
			uri[2] = Urtz[0].i;
			if (numCycle[0]<MAXCYCLE && urr[1]>urr[0] && urr[1] >= urr[2]) {
				urpeak[numCycle[0]][0] = kn;
				urpeak[numCycle[0]][1] = urr[1];
				numCycle[0] = numCycle[0] + 1;
				if (numCycle[0] == MAXCYCLE) flagSearchCycle[0] = 0;
			}
			if (numCycle[1]<MAXCYCLE && uri[1]>uri[0] && uri[1] >= uri[2]) {
				urpeak[numCycle[1]][2] = kn;
				urpeak[numCycle[1]][3] = uri[1];
				numCycle[1] = numCycle[1] + 1;
				if (numCycle[1] == MAXCYCLE) flagSearchCycle[1] = 0;
			}
			if (numCycle[2] < MAXCYCLE && urr[1] < urr[0] && urr[1] <= urr[2]) {
				urtrof[numCycle[2]][0] = kn;
				urtrof[numCycle[2]][1] = urr[1];
				numCycle[2] = numCycle[2] + 1;
				if (numCycle[2] == MAXCYCLE - 1) flagSearchCycle[2] = 0;
			}
			if (numCycle[3] < MAXCYCLE && uri[1] < uri[0] && uri[1] <= uri[2]) {
				urtrof[numCycle[3]][2] = kn;
				urtrof[numCycle[3]][3] = uri[1];
				numCycle[3] = numCycle[3] + 1;
				if (numCycle[3] == MAXCYCLE - 1) flagSearchCycle[3] = 0;
			}
		}

		//ut
		if (flagZero[0] != 0) {
			utr[0] = utr[1];
			uti[0] = uti[1];
			utr[1] = utr[2];
			uti[1] = uti[2];
			utr[2] = Urtz[1].r;
			uti[2] = Urtz[1].i;
			if (numCycle[4]<MAXCYCLE && utr[1]>utr[0] && utr[1] >= utr[2]) {
				utpeak[numCycle[4]][0] = kn;
				utpeak[numCycle[4]][1] = utr[1];
				numCycle[4] = numCycle[4] + 1;
				if (numCycle[4] == MAXCYCLE) flagSearchCycle[4] = 0;
			}
			if (numCycle[5]<MAXCYCLE && uti[1]>uti[0] && uti[1] >= uti[2]) {
				utpeak[numCycle[5]][2] = kn;
				utpeak[numCycle[5]][3] = uti[1];
				numCycle[5] = numCycle[5] + 1;
				if (numCycle[5] == MAXCYCLE) flagSearchCycle[5] = 0;
			}
			if (numCycle[6] < MAXCYCLE && utr[1] < utr[0] && utr[1] <= utr[2]) {
				uttrof[numCycle[6]][0] = kn;
				uttrof[numCycle[6]][1] = utr[1];
				numCycle[6] = numCycle[6] + 1;
				if (numCycle[6] == MAXCYCLE - 1) flagSearchCycle[6] = 0;
			}
			if (numCycle[7] < MAXCYCLE && uti[1] < uti[0] && uti[1] <= uti[2]) {
				uttrof[numCycle[7]][2] = kn;
				uttrof[numCycle[7]][3] = uti[1];
				numCycle[7] = numCycle[7] + 1;
				if (numCycle[7] == MAXCYCLE - 1) flagSearchCycle[7] = 0;
			}
		}

		//uz
		if (flagZero[0] != 0) {
			uzr[0] = uzr[1];
			uzi[0] = uzi[1];
			uzr[1] = uzr[2];
			uzi[1] = uzi[2];
			uzr[2] = Urtz[2].r;
			uzi[2] = Urtz[2].i;
			if (numCycle[8]<MAXCYCLE && uzr[1]>uzr[0] && uzr[1] >= uzr[2]) {
				uzpeak[numCycle[8]][0] = kn;
				uzpeak[numCycle[8]][1] = uzr[1];
				numCycle[8] = numCycle[8] + 1;
				if (numCycle[8] == MAXCYCLE) flagSearchCycle[8] = 0;
			}
			if (numCycle[9]<MAXCYCLE && uzi[1]>uzi[0] && uzi[1] >= uzi[2]) {
				uzpeak[numCycle[9]][2] = kn;
				uzpeak[numCycle[9]][3] = uzi[1];
				numCycle[9] = numCycle[9] + 1;
				if (numCycle[9] == MAXCYCLE) flagSearchCycle[9] = 0;
			}
			if (numCycle[10] < MAXCYCLE && uzr[1] < uzr[0] && uzr[1] <= uzr[2]) {
				uztrof[numCycle[10]][0] = kn;
				uztrof[numCycle[10]][1] = uzr[1];
				numCycle[10] = numCycle[10] + 1;
				if (numCycle[10] == MAXCYCLE - 1) flagSearchCycle[10] = 0;
			}
			if (numCycle[11] < MAXCYCLE && uzi[1] < uzi[0] && uzi[1] <= uzi[2]) {
				uztrof[numCycle[11]][2] = kn;
				uztrof[numCycle[11]][3] = uzi[1];
				numCycle[11] = numCycle[11] + 1;
				if (numCycle[11] == MAXCYCLE - 1) flagSearchCycle[11] = 0;
			}
		}

		//chech whether all peaks and troughs were found
		for (i = 0; i < 3; i++) {
			flagGetAllPeakTrouph[i] = 0;
		}
		if (flagZero[0] != 0) {
			for (i = 0; i < 4; i++) {
				flagGetAllPeakTrouph[0] = flagGetAllPeakTrouph[0] + flagSearchCycle[i];
			}
		}
		if (flagZero[1] != 0) {
			for (i = 4; i < 8; i++) {
				flagGetAllPeakTrouph[1] = flagGetAllPeakTrouph[1] + flagSearchCycle[i];
			}
		}
		if (flagZero[2] != 0) {
			for (i = 8; i < 12; i++) {
				flagGetAllPeakTrouph[2] = flagGetAllPeakTrouph[2] + flagSearchCycle[i];
			}
		}
		//get all peaks and troughs, calculating the integral of the periodic functions
		if ((flagGetAllPeakTrouph[0]+ flagGetAllPeakTrouph[1]+ flagGetAllPeakTrouph[2]) == 0) {
			//urr
			if (flagZero[0] != 0) {
				urrSum = (urpeak[0][1] + urpeak[MAXCYCLE - 1][1]) / 2.;
				if (urpeak[0][0] > urtrof[0][0]) {
					for (i = 0; i < MAXCYCLE - 2; i++) {
						urrSum = urrSum + urtrof[i][1] + urpeak[i + 1][1];
					}
					urrSum = (urrSum + urtrof[MAXCYCLE - 2][1]) / (2.*(MAXCYCLE - 1));
				}
				else {
					for (i = 1; i < MAXCYCLE - 1; i++) {
						urrSum = urrSum + urtrof[i][1] + urpeak[i][1];
					}
					urrSum = (urrSum + urtrof[MAXCYCLE - 1][1]) / (2.*(MAXCYCLE - 1));
				}
				//uri
				uriSum = (urpeak[0][3] + urpeak[MAXCYCLE - 1][3]) / 2.;
				if (urpeak[0][2] > urtrof[0][2]) {
					for (i = 0; i < MAXCYCLE - 2; i++) {
						uriSum = uriSum + urtrof[i][3] + urpeak[i + 1][3];
					}
					uriSum = (uriSum + urtrof[MAXCYCLE - 2][3]) / (2.*(MAXCYCLE - 1));
				}
				else {
					for (i = 1; i < MAXCYCLE - 1; i++) {
						uriSum = uriSum + urtrof[i][3] + urpeak[i][3];
					}
					uriSum = (uriSum + urtrof[MAXCYCLE - 1][3]) / (2.*(MAXCYCLE - 1));
				}
				Urtz[0] = dcmplx(urrSum, uriSum);
			}
			//utr
			if (flagZero[1] != 0) {
				utrSum = (utpeak[0][1] + utpeak[MAXCYCLE - 1][1]) / 2.;
				if (utpeak[0][0] > uttrof[0][0]) {
					for (i = 0; i < MAXCYCLE - 2; i++) {
						utrSum = utrSum + uttrof[i][1] + utpeak[i + 1][1];
					}
					utrSum = (utrSum + uttrof[MAXCYCLE - 2][1]) / (2.*(MAXCYCLE - 1));
				}
				else {
					for (i = 1; i < MAXCYCLE - 1; i++) {
						utrSum = utrSum + uttrof[i][1] + utpeak[i][1];
					}
					utrSum = (utrSum + uttrof[MAXCYCLE - 1][1]) / (2.*(MAXCYCLE - 1));
				}
				//uti
				utiSum = (utpeak[0][3] + utpeak[MAXCYCLE - 1][3]) / 2.;
				if (utpeak[0][2] > uttrof[0][2]) {
					for (i = 0; i < MAXCYCLE - 2; i++) {
						utiSum = utiSum + uttrof[i][3] + utpeak[i + 1][3];
					}
					utiSum = (utiSum + uttrof[MAXCYCLE - 2][3]) / (2.*(MAXCYCLE - 1));
				}
				else {
					for (i = 1; i < MAXCYCLE - 1; i++) {
						utiSum = utiSum + uttrof[i][3] + utpeak[i][3];
					}
					utiSum = (utiSum + uttrof[MAXCYCLE - 1][3]) / (2.*(MAXCYCLE - 1));
				}
				Urtz[1] = dcmplx(utrSum, utiSum);
			}
			//uzr
			if (flagZero[2] != 0) {
				uzrSum = (uzpeak[0][1] + uzpeak[MAXCYCLE - 1][1]) / 2.;
				if (uzpeak[0][0] > uztrof[0][0]) {
					for (i = 0; i < MAXCYCLE - 2; i++) {
						uzrSum = uzrSum + uztrof[i][1] + uzpeak[i + 1][1];
					}
					uzrSum = (uzrSum + uztrof[MAXCYCLE - 2][1]) / (2.*(MAXCYCLE - 1));
				}
				else {
					for (i = 1; i < MAXCYCLE - 1; i++) {
						uzrSum = uzrSum + uztrof[i][1] + uzpeak[i][1];
					}
					uzrSum = (uzrSum + uztrof[MAXCYCLE - 1][1]) / (2.*(MAXCYCLE - 1));
				}
				//uzi
				uziSum = (uzpeak[0][3] + uzpeak[MAXCYCLE - 1][3]) / 2.;
				if (uzpeak[0][2] > uztrof[0][2]) {
					for (i = 0; i < MAXCYCLE - 2; i++) {
						uziSum = uziSum + uztrof[i][3] + uzpeak[i + 1][3];
					}
					uziSum = (uziSum + uztrof[MAXCYCLE - 2][3]) / (2.*(MAXCYCLE - 1));
				}
				else {
					for (i = 1; i < MAXCYCLE - 1; i++) {
						uziSum = uziSum + uztrof[i][3] + uzpeak[i][3];
					}
					uziSum = (uziSum + uztrof[MAXCYCLE - 1][3]) / (2.*(MAXCYCLE - 1));
				}
				Urtz[2] = dcmplx(uzrSum, uziSum);
			}
			//update the U and declare convergence
			*convergence = 0;
		}

	}

	(*counter)++;

	return;
}

void  periodic_convergence_E(double kn, dcomplex Urtz[3], int *convergence,
	int *counter, int numCycle[12], int flagSearchCycle[12])
{
	/**
	* N.B. Initialization of some array must be done before call this function, as following:
	*   counter must be initialized as 0
	*   numCycle[12] must be intialized as 0
	*   flagSearchCycle[12] must be intialized as integers > 0
	* P.S. The static variables maybe result in fault sharing in multi-thread.
	*/

	//static int counter = 0;
	//static int numCycle[12] = { 0,0,0,0,0,0,0,0,0,0,0,0 };
	//static int flagSearchCycle[12] = { 1,1,1,1,1,1,1,1,1,1,1,1 };
	//*********************** N.B. above three variables can't use static for multi-source-receiver-pair
	//memory for peaks and trouphs of U
	static double urpeak[MAXCYCLE][4], urtrof[MAXCYCLE][4], urr[3], uri[3];
	//static double utpeak[MAXCYCLE][4], uttrof[MAXCYCLE][4], utr[3], uti[3];
	static double uzpeak[MAXCYCLE][4], uztrof[MAXCYCLE][4], uzr[3], uzi[3];
	//double urrSum, utrSum, uzrSum;
	//double uriSum, utiSum, uziSum;
	double urrSum, uzrSum;
	double uriSum, uziSum;

	int  i, flagGetAllPeakTrouph;

	if (*counter <= 2) {
		urr[*counter] = Urtz[0].r;
		uri[*counter] = Urtz[0].i;
		//utr[*counter] = Urtz[1].r;
		//uti[*counter] = Urtz[1].i;
		uzr[*counter] = Urtz[2].r;
		uzi[*counter] = Urtz[2].i;
	}
	else if (*counter > 2) {
		urr[0] = urr[1];
		uri[0] = uri[1];
		//utr[0] = utr[1];
		//uti[0] = uti[1];
		uzr[0] = uzr[1];
		uzi[0] = uzi[1];
		urr[1] = urr[2];
		uri[1] = uri[2];
		//utr[1] = utr[2];
		//uti[1] = uti[2];
		uzr[1] = uzr[2];
		uzi[1] = uzi[2];
		urr[2] = Urtz[0].r;
		uri[2] = Urtz[0].i;
		//utr[2] = Urtz[1].r;
		//uti[2] = Urtz[1].i;
		uzr[2] = Urtz[2].r;
		uzi[2] = Urtz[2].i;
		//searching peaks and troughs in periodic functions
		//ur
		if (numCycle[0]<MAXCYCLE && urr[1]>urr[0] && urr[1] >= urr[2]) {
			urpeak[numCycle[0]][0] = kn;
			urpeak[numCycle[0]][1] = urr[1];
			numCycle[0] = numCycle[0] + 1;
			if (numCycle[0] == MAXCYCLE) flagSearchCycle[0] = 0;
		}
		if (numCycle[1]<MAXCYCLE && uri[1]>uri[0] && uri[1] >= uri[2]) {
			urpeak[numCycle[1]][2] = kn;
			urpeak[numCycle[1]][3] = uri[1];
			numCycle[1] = numCycle[1] + 1;
			if (numCycle[1] == MAXCYCLE) flagSearchCycle[1] = 0;
		}
		if (numCycle[2] < MAXCYCLE && urr[1] < urr[0] && urr[1] <= urr[2]) {
			urtrof[numCycle[2]][0] = kn;
			urtrof[numCycle[2]][1] = urr[1];
			numCycle[2] = numCycle[2] + 1;
			if (numCycle[2] == MAXCYCLE - 1) flagSearchCycle[2] = 0;
		}
		if (numCycle[3] < MAXCYCLE && uri[1] < uri[0] && uri[1] <= uri[2]) {
			urtrof[numCycle[3]][2] = kn;
			urtrof[numCycle[3]][3] = uri[1];
			numCycle[3] = numCycle[3] + 1;
			if (numCycle[3] == MAXCYCLE - 1) flagSearchCycle[3] = 0;
		}
		//ut
		//if (numCycle[4]<MAXCYCLE && utr[1]>utr[0] && utr[1] >= utr[2]) {
		//	utpeak[numCycle[4]][0] = kn;
		//	utpeak[numCycle[4]][1] = utr[1];
		//	numCycle[4] = numCycle[4] + 1;
		//	if (numCycle[4] == MAXCYCLE) flagSearchCycle[4] = 0;
		//}
		//if (numCycle[5]<MAXCYCLE && uti[1]>uti[0] && uti[1] >= uti[2]) {
		//	utpeak[numCycle[5]][2] = kn;
		//	utpeak[numCycle[5]][3] = uti[1];
		//	numCycle[5] = numCycle[5] + 1;
		//	if (numCycle[5] == MAXCYCLE) flagSearchCycle[5] = 0;
		//}
		//if (numCycle[6] < MAXCYCLE && utr[1] < utr[0] && utr[1] <= utr[2]) {
		//	uttrof[numCycle[6]][0] = kn;
		//	uttrof[numCycle[6]][1] = utr[1];
		//	numCycle[6] = numCycle[6] + 1;
		//	if (numCycle[6] == MAXCYCLE - 1) flagSearchCycle[6] = 0;
		//}
		//if (numCycle[7] < MAXCYCLE && uti[1] < uti[0] && uti[1] <= uti[2]) {
		//	uttrof[numCycle[7]][2] = kn;
		//	uttrof[numCycle[7]][3] = uti[1];
		//	numCycle[7] = numCycle[7] + 1;
		//	if (numCycle[7] == MAXCYCLE - 1) flagSearchCycle[7] = 0;
		//}
		//uz
		if (numCycle[8]<MAXCYCLE && uzr[1]>uzr[0] && uzr[1] >= uzr[2]) {
			uzpeak[numCycle[8]][0] = kn;
			uzpeak[numCycle[8]][1] = uzr[1];
			numCycle[8] = numCycle[8] + 1;
			if (numCycle[8] == MAXCYCLE) flagSearchCycle[8] = 0;
		}
		if (numCycle[9]<MAXCYCLE && uzi[1]>uzi[0] && uzi[1] >= uzi[2]) {
			uzpeak[numCycle[9]][2] = kn;
			uzpeak[numCycle[9]][3] = uzi[1];
			numCycle[9] = numCycle[9] + 1;
			if (numCycle[9] == MAXCYCLE) flagSearchCycle[9] = 0;
		}
		if (numCycle[10] < MAXCYCLE && uzr[1] < uzr[0] && uzr[1] <= uzr[2]) {
			uztrof[numCycle[10]][0] = kn;
			uztrof[numCycle[10]][1] = uzr[1];
			numCycle[10] = numCycle[10] + 1;
			if (numCycle[10] == MAXCYCLE - 1) flagSearchCycle[10] = 0;
		}
		if (numCycle[11] < MAXCYCLE && uzi[1] < uzi[0] && uzi[1] <= uzi[2]) {
			uztrof[numCycle[11]][2] = kn;
			uztrof[numCycle[11]][3] = uzi[1];
			numCycle[11] = numCycle[11] + 1;
			if (numCycle[11] == MAXCYCLE - 1) flagSearchCycle[11] = 0;
		}
		//chech whether all peaks and troughs were found
		flagGetAllPeakTrouph = 0;
		for (i = 0; i<4; i++) {
			flagGetAllPeakTrouph = flagGetAllPeakTrouph + flagSearchCycle[i];
		}
		for (i = 8; i<12; i++) {
			flagGetAllPeakTrouph = flagGetAllPeakTrouph + flagSearchCycle[i];
		}
		//get all peaks and troughs, calculating the integral of the periodic functions
		if (flagGetAllPeakTrouph == 0) {
			//urr
			urrSum = (urpeak[0][1] + urpeak[MAXCYCLE - 1][1]) / 2.;
			if (urpeak[0][0]>urtrof[0][0]) {
				for (i = 0; i<MAXCYCLE - 2; i++) {
					urrSum = urrSum + urtrof[i][1] + urpeak[i + 1][1];
				}
				urrSum = (urrSum + urtrof[MAXCYCLE - 2][1]) / (2.*(MAXCYCLE - 1));
			}
			else {
				for (i = 1; i<MAXCYCLE - 1; i++) {
					urrSum = urrSum + urtrof[i][1] + urpeak[i][1];
				}
				urrSum = (urrSum + urtrof[MAXCYCLE - 1][1]) / (2.*(MAXCYCLE - 1));
			}
			//uri
			uriSum = (urpeak[0][3] + urpeak[MAXCYCLE - 1][3]) / 2.;
			if (urpeak[0][2]>urtrof[0][2]) {
				for (i = 0; i<MAXCYCLE - 2; i++) {
					uriSum = uriSum + urtrof[i][3] + urpeak[i + 1][3];
				}
				uriSum = (uriSum + urtrof[MAXCYCLE - 2][3]) / (2.*(MAXCYCLE - 1));
			}
			else {
				for (i = 1; i<MAXCYCLE - 1; i++) {
					uriSum = uriSum + urtrof[i][3] + urpeak[i][3];
				}
				uriSum = (uriSum + urtrof[MAXCYCLE - 1][3]) / (2.*(MAXCYCLE - 1));
			}
			//utr
			//utrSum = (utpeak[0][1] + utpeak[MAXCYCLE - 1][1]) / 2.;
			//if (utpeak[0][0]>uttrof[0][0]) {
			//	for (i = 0; i<MAXCYCLE - 2; i++) {
			//		utrSum = utrSum + uttrof[i][1] + utpeak[i + 1][1];
			//	}
			//	utrSum = (utrSum + uttrof[MAXCYCLE - 2][1]) / (2.*(MAXCYCLE - 1));
			//}
			//else {
			//	for (i = 1; i<MAXCYCLE - 1; i++) {
			//		utrSum = utrSum + uttrof[i][1] + utpeak[i][1];
			//	}
			//	utrSum = (utrSum + uttrof[MAXCYCLE - 1][1]) / (2.*(MAXCYCLE - 1));
			//}
			////uti
			//utiSum = (utpeak[0][3] + utpeak[MAXCYCLE - 1][3]) / 2.;
			//if (utpeak[0][2]>uttrof[0][2]) {
			//	for (i = 0; i<MAXCYCLE - 2; i++) {
			//		utiSum = utiSum + uttrof[i][3] + utpeak[i + 1][3];
			//	}
			//	utiSum = (utiSum + uttrof[MAXCYCLE - 2][3]) / (2.*(MAXCYCLE - 1));
			//}
			//else {
			//	for (i = 1; i<MAXCYCLE - 1; i++) {
			//		utiSum = utiSum + uttrof[i][3] + utpeak[i][3];
			//	}
			//	utiSum = (utiSum + uttrof[MAXCYCLE - 1][3]) / (2.*(MAXCYCLE - 1));
			//}
			//uzr
			uzrSum = (uzpeak[0][1] + uzpeak[MAXCYCLE - 1][1]) / 2.;
			if (uzpeak[0][0]>uztrof[0][0]) {
				for (i = 0; i<MAXCYCLE - 2; i++) {
					uzrSum = uzrSum + uztrof[i][1] + uzpeak[i + 1][1];
				}
				uzrSum = (uzrSum + uztrof[MAXCYCLE - 2][1]) / (2.*(MAXCYCLE - 1));
			}
			else {
				for (i = 1; i<MAXCYCLE - 1; i++) {
					uzrSum = uzrSum + uztrof[i][1] + uzpeak[i][1];
				}
				uzrSum = (uzrSum + uztrof[MAXCYCLE - 1][1]) / (2.*(MAXCYCLE - 1));
			}
			//uzi
			uziSum = (uzpeak[0][3] + uzpeak[MAXCYCLE - 1][3]) / 2.;
			if (uzpeak[0][2]>uztrof[0][2]) {
				for (i = 0; i<MAXCYCLE - 2; i++) {
					uziSum = uziSum + uztrof[i][3] + uzpeak[i + 1][3];
				}
				uziSum = (uziSum + uztrof[MAXCYCLE - 2][3]) / (2.*(MAXCYCLE - 1));
			}
			else {
				for (i = 1; i<MAXCYCLE - 1; i++) {
					uziSum = uziSum + uztrof[i][3] + uzpeak[i][3];
				}
				uziSum = (uziSum + uztrof[MAXCYCLE - 1][3]) / (2.*(MAXCYCLE - 1));
			}
			//update the U and declare convergence
			Urtz[0] = dcmplx(urrSum, uriSum);
			Urtz[1] = dcmplx(0., 0.);
			Urtz[2] = dcmplx(uzrSum, uziSum);
			*convergence = 0;
		}

	}
	(*counter)++;

	return;
}
