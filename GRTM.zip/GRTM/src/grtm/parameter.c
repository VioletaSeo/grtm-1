#include "parameter.h"
#include "cwp_mini.h"
#include <string.h>

void input_calculation_parameters(const char *parafile,
	double *Twin, double *dt, double *coef, double *fc,
	char *Type_STF, double *tou, double *fpeak,
	double *fmin, double *fmax, char *PeriodCheck,
	char *modefile, char *sourfile, char *recvfile, char *prefix_output,char *outputdata,char *outdirectory,char *outputdata1,int *mediatype)
{
	char tempstr[1024];
	FILE *pFile;
	if ((pFile = fopen(parafile, "r")) == NULL) {
		printf("Parameters file could not be opened.\n");
		exit(EXIT_FAILURE);
	}
	else {
		//####################### input parameters file##########################
		if (!feof(pFile)) fgets(tempstr, 1024, pFile);   //line1
		if (!feof(pFile)) fscanf(pFile, "%lf", Twin);    //time length(sec) 
		if (!feof(pFile)) fgets(tempstr, 1024, pFile);

		if (!feof(pFile)) fscanf(pFile, "%lf", dt);       //time samping dt
		if (!feof(pFile)) fgets(tempstr, 1024, pFile);

		if (!feof(pFile)) fscanf(pFile, "%lf", coef);     //coefficients
		if (!feof(pFile)) fgets(tempstr, 1024, pFile);
       //####################### Diectory for input file #########################
		if (!feof(pFile)) fgets(tempstr, 1024, pFile);
		if (!feof(pFile)) fscanf(pFile, "%s", modefile);   
		if (!feof(pFile)) fgets(tempstr, 1024, pFile);

		if (!feof(pFile)) fscanf(pFile, "%s", sourfile);   
		if (!feof(pFile)) fgets(tempstr, 1024, pFile);

		if (!feof(pFile)) fscanf(pFile, "%s", recvfile);   
		if (!feof(pFile)) fgets(tempstr, 1024, pFile);
        //###################### Output parameters ###############################
        if (!feof(pFile)) fgets(tempstr, 1024, pFile);

        if (!feof(pFile)) fscanf(pFile, "%s", outputdata);   
        if (!feof(pFile)) fgets(tempstr, 1024, pFile);

        if (!feof(pFile)) fscanf(pFile, "%s", outputdata1);   //for curl output 
        if (!feof(pFile)) fgets(tempstr, 1024, pFile);
        // ##################### calculate frequency range #######################
        if (!feof(pFile)) fgets(tempstr, 1024, pFile);
        if (!feof(pFile)) fscanf(pFile, "%lf", fmin);       
		if (!feof(pFile)) fgets(tempstr, 1024, pFile);
		if (!feof(pFile)) fscanf(pFile, "%lf", fmax);       
		if (!feof(pFile)) fgets(tempstr, 1024, pFile);
        //###################### Reference frequency in velocity attenuation ######
        if (!feof(pFile)) fgets(tempstr, 1024, pFile);
        if (!feof(pFile)) fscanf(pFile, "%lf", fpeak);     
		if (!feof(pFile)) fgets(tempstr, 1024, pFile);
        // ##################### Peak valley average method #######################
        if (!feof(pFile)) fgets(tempstr, 1024, pFile);
        if (!feof(pFile)) fscanf(pFile, "%s", PeriodCheck);  
		if (!feof(pFile)) fgets(tempstr, 1024, pFile);
        // ##################### choose media type #######################
        if (!feof(pFile)) fgets(tempstr, 1024, pFile);
        if (!feof(pFile)) fscanf(pFile, "%d", mediatype);  
		if (!feof(pFile)) fgets(tempstr, 1024, pFile);

		
		
	}
	fclose(pFile);
	return;
}


void set_calculation_parameters(double Twin, double dt, double coef, double fmin, double fmax,
	int *nt, int *nfft, int *nfreq, int *nfreqBeg, int *nfreqEnd, double *df, double *iomega,double fc,char* Type_STF)
{
	int   exponent;
	float mantissa;
	double fnyq;
	int fcn,temp;
	//number of samples
	*nt = Twin / dt + 1;
	mantissa = frexp((float)*nt, &exponent);
	*nfft = (int)pow(2.0, exponent) * 2;
	*nfreq = *nfft / 2 + 1;
	fnyq = 1. / (2.*dt);
	*df = fnyq / (*nfreq - 1);
	
	fcn=3*ceil(fc/ *df);
	//for damping
	//use the recommended value coef=1 and the equation
	*iomega = coef*(PI / Twin);
	//use the recommended value coef=50 and the equation
	//*iomega = log(coef) / Twin;
	//useful frequency range
	*nfreqBeg = MAX(1, (int)(fmin / *df));
	*nfreqEnd = MIN(*nfreq, (int)(fmax / *df));
	temp= *nfreqEnd;
	if (!strcmp(Type_STF,"Ricker")) 
	{

	if(temp<=fcn)
	{
		*nfreqEnd=fcn;
		
	}
    }
	
}
