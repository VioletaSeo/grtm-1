#pragma once

#include "model.h"

#define INDEX_DIP 0
#define INDEX_RAKE 1
#define INDEX_STRIKE 2
#define INDEX_D0S 3
#define INDEX_A0S 4

#define INDEX_NX 0
#define INDEX_NY 1
#define INDEX_NZ 2

#define INDEX_MXX 0
#define INDEX_MYY 1
#define INDEX_MZZ 2
#define INDEX_MXY 3
#define INDEX_MXZ 4
#define INDEX_MYZ 5

#define ZEROSOURCE 1e-10

typedef struct _Source_Parameters {
	char SourceType;
	double para[6];
	//para[0]------D:dip || S:nx
	//para[1]------D:rake || S:ny
	//para[2]------D:strike || S:nz
	//para[3]------D:D0s
	//para[4]------D:A0s
	//para[5]------
	double depth;
	int layer;
	double amplitude;
}Source_Parameters;

typedef struct _Receriver_Station_Parameters {
	double depth;
	double distance;
	double azimuth;
	int layer;
	int line;
	int ngather;
	double g_x;
	double g_y;
	double g_z;
	double sign_r; // judge the x coordinate sign
}_Receriver_Station_Parameters;

#define SourPara Source_Parameters
#define RecvStat _Receriver_Station_Parameters


typedef struct _radiapattern_D {
	double rsh1;
	double rsh2;
	double rpsv1;
	double rpsv2;
	double rpsv01;
	double rpsv02;
	// for derivative modified by Tang Le 2020 1.13
	double rsh1d;
	double rsh2d;
	double rpsv1d;
	double rpsv2d;
	double rpsv01d;
	double rpsv02d;
	//////////////////////
}RadPat_D;

typedef struct _radiapattern_S {
	double rsh1;
	double rpsv0;
	double rpsv1;
	// for derivative modified by Tang Le 2020 1.13
	double rsh1d;
	double rpsv0d;
	double rpsv1d;
	////////////////
}RadPat_S;

void calc_R_D(double azimuth, double dip, double rake, double strike, RadPat_D *R);
void calc_R_S(double azimuth, double nx, double ny, double nz, RadPat_S *R);
void calc_R_M(double azimuth, const SourPara *source, RadPat_D *R);

void calc_source_parameters_D(SourPara *source, const FKRTmodel *model);
void calc_source_parameters_S(SourPara *source, const FKRTmodel *model);
void calc_source_parameters_E(SourPara *source, const FKRTmodel *model);
void calc_source_parameters_M(SourPara *source, const FKRTmodel *model);
void calc_receiver_parameters(RecvStat *recvstat, const FKRTmodel *model);

SourPara* get_sources(int *nsour, const char *sourfile,double *fc,char *Type_STF,double *tou);
RecvStat* get_receivers(int *nrecv, const char *recvfile);
void preprocessing_model_source_receiver(FKRTmodel *model, SourPara* lstsourpara, RecvStat* lstrecvstat, int nsour, int nrecv);

SourPara *alloc1SourPara(size_t n1);
RecvStat *alloc1RecvStat(size_t n1);
void free1SourPara(SourPara *p);
void free1RecvStat(RecvStat *p);
