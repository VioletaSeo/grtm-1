#pragma once

#include "model.h"
#include "source_and_receiver.h"
#include "cwp_mini.h"

void DWIM_D(FKRTmodel *model, const RadPat_D *radpat, const double kmin, const double kmax, const double dk,
	const int layerSour, const int layerRecv, const double zSour, const double zRecv, const double distance_SR,
	dcomplex integral[3], dcomplex integterm_last[3],dcomplex integrald[3], dcomplex integterm_lastd[3]);

void DWIM_S(FKRTmodel *model, const RadPat_S *radpat, const double kmin, const double kmax, const double dk,
	const int layerSour, const int layerRecv, const double zSour, const double zRecv, const double distance_SR,
	dcomplex integral[3], dcomplex integterm_last[3],dcomplex integrald[3], dcomplex integterm_lastd[3]);

void DWIM_E(FKRTmodel *model, const double kmin, const double kmax, const double dk,
	const int layerSour, const int layerRecv, const double zSour, const double zRecv, const double distance_SR,
	dcomplex integral[3], dcomplex integterm_last[3]);