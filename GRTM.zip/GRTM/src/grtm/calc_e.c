#include "cwp_mini.h"

void calcE(const double k, const dcomplex omega, const double mu,
	const dcomplex alpha, const dcomplex beta,
	const dcomplex gamma, const dcomplex nu, dcomplex E[4][4])
{
	
	dcomplex omega0=omega,alpha0=alpha,beta0=beta,gamma0=gamma,nu0=nu,rp,rp1;
	double k0=k,mu0=mu;
	dcomplex chi, alphomega, betaomega;
	rp=dcmul2(nu0,nu0);
	chi = dcradd2( rp,k0*k0);
	alphomega = dcdiv2(alpha0, omega0);
	betaomega = dcdiv2(beta0, omega0);
	rp=alphomega;
	///////
	E[0][0] = dcrmul2(rp, k0);
	rp=betaomega;
	E[0][1] = dcmul2(rp, nu0);
	E[0][2] = E[0][0];
	E[0][3] = E[0][1];
	rp=alphomega;
	E[1][0] = dcmul2(rp, gamma0);
	rp=betaomega;
	E[1][1] = dcrmul2(rp, k0);
	rp=E[1][0];
	E[1][2] = dcneg2(rp);
	rp=E[1][1];
	E[1][3] = dcneg2(rp);
	rp=alphomega;
	rp=dcmul2(rp, gamma0);
	E[2][0] = dcrmul2(rp, -2.*mu0*k0);
	rp=betaomega;
	rp1=chi;
	rp=dcmul2(rp, rp1);
	E[2][1] = dcrmul2(rp, -mu0);
	rp=E[2][0];
	E[2][2] = dcneg2(rp);
	rp=E[2][1];
	E[2][3] = dcneg2(rp);
	rp=alphomega;
	rp1=chi;
	rp=dcmul2(rp, rp1);
	E[3][0] = dcrmul2(rp, -mu0);
	rp=betaomega;
	rp1=nu;
	rp=dcmul2(rp,rp1 );
	E[3][1] = dcrmul2(rp, -2.* mu0*k0);
	E[3][2] = E[3][0];
	E[3][3] = E[3][1];
}


void calcE11E12(const double k, const dcomplex omega, const double mu, 
	const dcomplex alpha, const dcomplex beta,
	const dcomplex gamma, const dcomplex nu, dcomplex E11[2][2], dcomplex E12[2][2])
{
	
	dcomplex chi, alphomega, betaomega,rp,rp1;
	double rrp;
	rp=nu;
	rp=dcmul2(rp,rp);
	rrp=k*k;
	chi = dcradd2(rp, rrp);
	rp=alpha;rp1=omega;
	alphomega = dcdiv2(rp,rp1);
	rp=beta;
	betaomega = dcdiv2(rp,rp1);
    rp=alphomega;
    rrp=k;
	E11[0][0] = dcrmul2(rp, rrp);
	rp=betaomega;
	rp1=nu;
	E11[0][1] = dcmul2(rp,rp1);
	rp=alphomega;
	rp1=gamma;
	E11[1][0] = dcmul2(rp,rp1);
	rp1=betaomega;
	rrp=k;
	E11[1][1] = dcrmul2(rp1, rrp);

	E12[0][0] = E11[0][0];
	E12[0][1] = E11[0][1];
	rp=E11[1][0];
	E12[1][0] = dcneg2(rp);
	rp=E11[1][1];
	E12[1][1] = dcneg2(rp);
}

void calcE21E22(const double k, const dcomplex omega, const double mu, 
	const dcomplex alpha, const dcomplex beta,
	const dcomplex gamma, const dcomplex nu, dcomplex E21[2][2], dcomplex E22[2][2])
{
	
	dcomplex chi, alphomega, betaomega;
	dcomplex rp,rp1;
	double rrp;
	rp=nu;
	rp=dcmul2(rp, rp);
	rrp=k*k;
	chi = dcradd2(rp, rrp);
	rp=alpha;
	rp1=omega;
	alphomega = dcdiv2(rp,rp1);
	rp=beta;
	rp1=omega;
	betaomega = dcdiv2(rp,rp1);
	rp=alphomega;rp1= gamma;
	rp=dcmul2(rp,rp1);
	rrp=-2.*mu*k;
	E21[0][0] = dcrmul2(rp,rrp);
	rp=betaomega;
	rp1= chi;
	rp=dcmul2(rp,rp1);
	rrp=-mu;
	E21[0][1] = dcrmul2(rp, rrp);
	rp=alphomega;
	rp1=chi;
	rp=dcmul2(rp, rp1);
	rrp= -mu;
	E21[1][0] = dcrmul2(rp,rrp);
	rp=betaomega;
	rp1=nu;
	rp=dcmul2(rp,rp1);
	rrp= -2.* mu*k;
	E21[1][1] = dcrmul(rp,rrp);
    rp=E21[0][0];
	E22[0][0] = dcneg2(rp);
	rp=E21[0][1];
	E22[0][1] = dcneg2(rp);
	E22[1][0] = E21[1][0];
	E22[1][1] = E21[1][1];
}

void assemEdEu(dcomplex Edd[4][4], dcomplex Euu[4][4], dcomplex Eud[4][4], dcomplex Edu[4][4])
{
	int i, j;
	for (i = 0; i < 4; i++) {
		for (j = 0; j < 2; j++) {
			Eud[i][j] = Euu[i][j];
			Edu[i][j] = Edd[i][j];
		}
		for (j = 2; j < 4; j++) {
			dcomplex rp=Edd[i][j],rp1=Euu[i][j];
			Eud[i][j] = dcneg2(rp);
			Edu[i][j] = dcneg2(rp1);
		}
	}
}

void partMat44to22(dcomplex M44[4][4], dcomplex M11[2][2], dcomplex M12[2][2], dcomplex M21[2][2], dcomplex M22[2][2])
{
	int i, j;
	for (i = 0; i < 2; i++) {
		for (j = 0; j < 2; j++) {
			M11[i][j] = M44[i][j];
			M12[i][j] = M44[i][j + 2];
			M21[i][j] = M44[i + 2][j];
			M22[i][j] = M44[i + 2][j + 2];
		}
	}
}

