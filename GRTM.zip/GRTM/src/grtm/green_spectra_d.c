#include "green_spectra.h"
#include "model.h"
#include "source_and_receiver.h"
#include "dwim.h"
#include "integral_function_coeff.h"
#include "periodic_convergence.h"
#include <math.h>
#include <stdio.h>

 
//Green function of one pair(source, receiver)
void green_spectra_D(FKRTmodel *model, double df, int nfreqBeg, int nfreqEnd,
	double iomega, double freq_reference, double dk,
	const SourPara *source, const RecvStat *recvstat,
	dcomplex *ur, dcomplex *ut, dcomplex *uz, char *PeriodCheck,dcomplex *urd, dcomplex *utd, dcomplex *uzd)
{
	//source and receiver information
	double r0, zSour, zRecv;
	int layerSour, layerRecv;
	dcomplex rp,rp1;
	double rrp;
	//radiaction pattern
	RadPat_D  radpat;
	//f-k
	double kmin, kcritical, kn, freq, dk_2;
	//for periodic convergence
	int counter, flagSearchCycle[12], numCycle[12],numCycle0[12],flagSearchCycle0[12];//curl
	int convergence;
	double condition;
	int flag0or1[14];
	int flagZero[3];
	//bessel and integral
	double j0, j1, j2,j3,j4, j0d, j1d, j2d,j1dd,j2dd;
	dcomplex fun[12],fund[32];
	dcomplex tmpU[3], sumU[3],sumUd[3]; // d for curl
	dcomplex integterm_last[3],integterm_lastd[3];
	dcomplex integterm_new[3],integterm_newd[3];
	//temporary
	int i, ifreq;
	dcomplex dctemp, dctemp2;

	r0 = recvstat->distance;
	zSour = source->depth;
	zRecv = recvstat->depth;
	layerSour = source->layer;
	layerRecv = recvstat->layer;
	//source radiation pattern
	calc_R_M(recvstat->azimuth, source, &radpat);
	for (i = 0; i < 14; i++) {
		flag0or1[i] = 1;
	}
	if (fabs(radpat.rpsv2) < ZEROSOURCE) {
		radpat.rpsv2 = 0.;
		flag0or1[3] = 0;
		flag0or1[5] = 0;
		flag0or1[13] = 0;
	}

	if (fabs(radpat.rpsv1) < ZEROSOURCE) {
		radpat.rpsv1 = 0.;
		flag0or1[0] = 0;
		flag0or1[4] = 0;
		flag0or1[12] = 0;
	}
	if (fabs(radpat.rpsv01) < ZEROSOURCE) {
		radpat.rpsv01 = 0.;
		flag0or1[1] = 0;
		flag0or1[10] = 0;
	}
	if (fabs(radpat.rpsv02) < ZEROSOURCE) {
		radpat.rpsv02 = 0.;
		flag0or1[2] = 0;
		flag0or1[11] = 0;
	}
	if (fabs(radpat.rsh2) < ZEROSOURCE) {
		radpat.rsh2 = 0.;
		flag0or1[7] = 0;
		flag0or1[9] = 0;
	}
	if (fabs(radpat.rsh1) < ZEROSOURCE) {
		radpat.rsh1 = 0.;
		flag0or1[6] = 0;
		flag0or1[8] = 0;
	}
	flagZero[0] = flag0or1[0] + flag0or1[1] + flag0or1[2] + flag0or1[3] + flag0or1[4] + flag0or1[5];
	flagZero[1] = flag0or1[6] + flag0or1[7] + flag0or1[8] + flag0or1[9];
	flagZero[2] = flag0or1[10] + flag0or1[11] + flag0or1[12] + flag0or1[13];

	/*flagZero[0] = 1;
	flagZero[1] = 0;
	flagZero[2] = 0;*/
	//calculation start...
	for (ifreq = nfreqBeg; ifreq <= nfreqEnd; ifreq++) 
	{
		//printf("ifreq: %d\n", ifreq);
		freq = ifreq*df;
		set_complex_frequency_variables(model, freq, iomega, freq_reference);

		dctemp = dcmplx(PI2*df*3., -iomega);
		kcritical = get_critical_k(model, dctemp, ifreq, layerSour, layerRecv, zSour, zRecv);
		
		
		
		//discrete wavenumber integration
		DWIM_D(model, &radpat, 0., kcritical, dk,
			layerSour, layerRecv, zSour, zRecv, r0, sumU, integterm_last,sumUd, integterm_lastd);
	/*printf("%lf\n", sumU[0].r);
	printf("%lf\n", sumU[0].i);		
	printf("%lf\n", sumU[1].r);
	printf("%lf\n", sumU[1].i);		
	printf("%lf\n", sumU[2].r);
	printf("%lf\n", sumU[2].i);	*/
	
       
		if (!strcmp(PeriodCheck, "ON")) 
		{
			//convergence judge
			condition = CONVERGENCE_THRESH;
			convergence = 0; //0-convergence, 1-nonconvergence
			if (drcabs(model->qSH1) > condition) convergence = 1;
			if (drcabs(model->qSH2) > condition) convergence = 1;
			for (i = 0; i < 2; i++) {
				if (drcabs(model->qPSV0[i]) > condition) convergence = 1;
				if (drcabs(model->qPSV1[i]) > condition) convergence = 1;
				if (drcabs(model->qPSV2[i]) > condition) convergence = 1;
			}
			//periodic_convergence integration calculation
			kn = kcritical;
			dk_2 = dk / 2.;
			counter = 0;
			for (i = 0; i < 12; i++) {
				numCycle[i] = 0;
				flagSearchCycle[i] = 1;
			}

			//while (0) {
			while (convergence != 0 && counter <MAXCYCLECHECKTIME )//MAXCYCLECHECKTIME 
			{
			//while (convergence != 0) {
				kn = kn + dk;
				integral_function_coeff_D(kn, model, &radpat, layerSour, layerRecv, zSour, zRecv, fun,fund);

		        BesselJ012d(r0*kn, &j0, &j1, &j2, &j0d, &j1d, &j2d,&j3,&j4,&j1dd,&j2dd);
		        integration_D(integterm_new, fun, j0, j1, j2, j0d, j1d, j2d,integterm_newd,fund, j3, j4, j1dd, j2dd);
				

				for (i = 0; i < 3; i++)
				 {
					/*rp=integterm_last[i];rp1=integterm_new[i];
					rp=dcadd2(rp, rp1);rrp=dk_2;
					rp=dcrmul2(rp, rrp);
					rp1=sumU[i];
					sumU[i] = dcadd2(rp1, rp);
					integterm_last[i] = integterm_new[i];*/

					sumU[i] = dcadd(sumU[i], dcrmul(dcadd(integterm_last[i], integterm_new[i]), dk_2));
					integterm_last[i] = integterm_new[i];					
				

				  }

				periodic_convergence(kn, sumU, flagZero, &convergence, &counter, numCycle, flagSearchCycle);
				
		   	}

		
		}
		/////////////////////
		if (!strcmp(PeriodCheck, "ON")) 
		{
			//convergence judge
			condition = CONVERGENCE_THRESH;
			convergence = 0; //0-convergence, 1-nonconvergence
			if (drcabs(model->qSH1) > condition) convergence = 1;
			if (drcabs(model->qSH2) > condition) convergence = 1;
			for (i = 0; i < 2; i++) {
				if (drcabs(model->qPSV0[i]) > condition) convergence = 1;
				if (drcabs(model->qPSV1[i]) > condition) convergence = 1;
				if (drcabs(model->qPSV2[i]) > condition) convergence = 1;
			}
			//periodic_convergence integration calculation
			kn = kcritical;
			dk_2 = dk / 2.;
			counter = 0;
			for (i = 0; i < 12; i++) {
				numCycle0[i] = 0;
				flagSearchCycle0[i] = 1;
			}
			//////////////// for curl ////////////////////////////
			while (convergence != 0 && counter <MAXCYCLECHECKTIME) 
			{
			//while (convergence != 0) {
				kn = kn + dk;
				integral_function_coeff_D(kn, model, &radpat, layerSour, layerRecv, zSour, zRecv, fun,fund);
		        BesselJ012d(r0*kn, &j0, &j1, &j2, &j0d, &j1d, &j2d,&j3,&j4,&j1dd,&j2dd);
		        integration_D(integterm_new, fun, j0, j1, j2, j0d, j1d, j2d,integterm_newd,fund, j3, j4, j1dd, j2dd);

				for (i = 0; i < 3; i++)
				 {
					rp=integterm_lastd[i];rp1=integterm_newd[i];
					rp=dcadd2(rp, rp1);rrp=dk_2;
					rp=dcrmul2(rp, rrp);
					rp1=sumUd[i];
					sumUd[i] = dcadd2(rp1, rp);
					integterm_lastd[i] = integterm_newd[i];
					//////////////////////////////////////////////////
				}
				periodic_convergence(kn, sumUd, flagZero, &convergence, &counter, numCycle0, flagSearchCycle0);
			}
			//////////////////////////////////////////////////////
		}
		/////////////////////////
		ur[ifreq] = sumU[0];
		ut[ifreq] = sumU[1];
		uz[ifreq] = sumU[2];
		/////// for curl /////////////
		urd[ifreq] = sumUd[0];
		utd[ifreq] = sumUd[1];
		uzd[ifreq] = sumUd[2];
		//printf("%d\n",counter);
       /*printf("ok\n");
		printf("%lf\n",sumU[0].r );
		printf("%lf\n",sumU[0].i );
		printf("%lf\n",sumU[1].r );
		printf("%lf\n",sumU[1].i );
		printf("%lf\n",sumU[2].r );
		printf("%lf\n",sumU[2].i );*/
		
	}
	//exit(0);
	
}
