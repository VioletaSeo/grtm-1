#include "cwp_mini.h"
#include "model.h"
#include "source_and_receiver.h"
#include "green_spectra.h"
#include "wavelet.h"
#include "segywrite.h"
#include "parameter.h"
#include <string.h>
#include<time.h>
#include "../common/common.h"
int main(int argc, char *argv[])
{
	clock_t stime,ftime;
	float time;
	stime=clock();

    char parfile[128];
    strcpy(parfile,argv[1]); // parameter file, argv[0] is the executable name

    //parfile="./grtm/input_basic.par";
	const dcomplex AJ = dcmplx(0., 1.);
	//file name of parameter files
	char outputdata[10],outputdata1[10],outdirectory[64];//*parfile,
	//poiter of output file
	char prefix_output[64];
	char Ur_output[64];
	char Ut_output[64];
	char Uz_output[64];
	char head[3600]={'0'};
	FILE *fileUr, *fileUt, *fileUz;
	//self-defined structure
	FKRTmodel model;
	SourPara *lstsourpara;
	RecvStat *lstrecvstat;
	SourPara source;
	RecvStat recvstat;
	double deepest;
	//basic input parameters
	double Twin, dt, coef, fc, tou, fpeak, fmin, fmax,fre_r,fcc;
	char SourceType[64], Type_STF[64];
	char PeriodCheck[64];
	char modelfile[64];
	char sourfile[64];
	char recvfile[64];
	//basic patameters
	int nt, nfft, nfreq, nfreqBeg, nfreqEnd;
	double df, iomega, L, dk,sign_r0;
	//for source and receiver information
	double r0, dz0;
	int nsour, nrecv;
	//for wavelet, filter, and fft to time domain
	double *urreal, *urimag, *utreal, *utimag, *uzreal, *uzimag;
	
	/////////////////////////////
	double freq, win, amp0;
	dcomplex omega, wavespec;
	//segy format trace
	float *urdata, *utdata, *uzdata;
	
	segy tr;
	//data
	dcomplex **ur;
	dcomplex **ut;
	dcomplex **uz;
	// for curl 
	dcomplex **urd;
	dcomplex **utd;
	dcomplex **uzd;
	//temporary
	double vmin, vmax, vave;
	int isour, irecv, i, j,mediatype;
	double dtemp;
	dcomplex ctemp, ctemp1, ctemp2, ctemp3,temp;
	//file name for input parameters and model
	//parfile = "input_basic.par";
	//input basic parameters
	input_calculation_parameters(parfile,
		&Twin, &dt, &coef, &fc,
		Type_STF, &tou, &fpeak,
		&fmin, &fmax,PeriodCheck, 
		modelfile, sourfile, recvfile, prefix_output,outputdata,outdirectory,outputdata1,&mediatype);
  
  //////// media type ///////////////////////	
	if (mediatype==1)
	{
		printf("This is isotropy media\n");
	}
	else
	{
		printf("This is VTI media\n");
	}

   strcpy(prefix_output,argv[2]); //  argv[2] is the output directory
  if(strcmp(outputdata,"000")!=0&&strcmp(outputdata,"001")!=0&&strcmp(outputdata,"010")!=0&&strcmp(outputdata,"011")!=0&&strcmp(outputdata,"100")!=0
      &&strcmp(outputdata,"101")!=0&&strcmp(outputdata,"110")!=0&&strcmp(outputdata,"111")!=0)
  {  printf("please choose the output data from input_basic.par line15\n");
    return 0;
  }
  ////
	//set basic parameters
 
	set_calculation_parameters(Twin, dt, coef, fmin, fmax,
		&nt, &nfft, &nfreq, &nfreqBeg, &nfreqEnd, &df, &iomega,fc,Type_STF);
	printf("nt=%d\n",nt);
	//model
	input_physical_model(&model, modelfile,mediatype);
	//source
	lstsourpara = get_sources(&nsour, sourfile,&fc,Type_STF,&tou);
	//receiver
	lstrecvstat = get_receivers(&nrecv, recvfile);
	//preprocessing the model, source, receiver
	preprocessing_model_source_receiver(&model, lstsourpara, lstrecvstat, nsour, nrecv);
	////////////////////////////////////////////////////////////////////////////////////////
	//  finish prepare model / source /receiver, start modeling........
	//allocate memory for U
	ur = alloc2dcomplex(nfreq + 1, nrecv);
	ut = alloc2dcomplex(nfreq + 1, nrecv);
	uz = alloc2dcomplex(nfreq + 1, nrecv);
	// for curl //////////////
	urd = alloc2dcomplex(nfreq + 1, nrecv);
	utd = alloc2dcomplex(nfreq + 1, nrecv);
	uzd = alloc2dcomplex(nfreq + 1, nrecv);
	////////////////////////
	//allocate workspace for fft to time domain data
	urreal = alloc1double(nfft);
	urimag = alloc1double(nfft);
	utreal = alloc1double(nfft);
	utimag = alloc1double(nfft);
	uzreal = alloc1double(nfft);
	uzimag = alloc1double(nfft);
	urdata = alloc1float(nt);
	utdata = alloc1float(nt);
	uzdata = alloc1float(nt);
	

	/////////////////////////////////////////
	//for estimate dk
	get_max_min_velocity(&model, &vmax, &vmin);
	vave = (vmax + vmin) / 2.;
	for (isour = 0; isour < nsour; isour++) {
		memset((void *)ur[0], 0, sizeof(dcomplex)*nfreq*nrecv);
		memset((void *)ut[0], 0, sizeof(dcomplex)*nfreq*nrecv);
		memset((void *)uz[0], 0, sizeof(dcomplex)*nfreq*nrecv);
		//calculate Green function
		source = lstsourpara[isour];
		

		for (irecv = 0; irecv < nrecv; irecv++) 
		{
			printf("isour: %d      irecv: %d\n", isour + 1, irecv + 1);
			recvstat = lstrecvstat[irecv];
			r0 = recvstat.distance;
			
			dz0 = ABS(source.depth - recvstat.depth);
			
			
			L = vmax*Twin + r0 + vmax / vave*sqrt(r0*r0 + pow(dz0, 2)) + 100;
			//L = 9.5 * r0;
			dk = PI2 / L;
			//printf("%lf %lf %lf\n",vmax,Twin,vmin);
			if (source.SourceType == 'D' || source.SourceType == 'M') 
			{
				green_spectra_D(&model, df, nfreqBeg, nfreqEnd,
					iomega, fpeak, dk,
					&source, &recvstat,
					ur[irecv], ut[irecv], uz[irecv], PeriodCheck,urd[irecv], utd[irecv], uzd[irecv]);
			}
			else if (source.SourceType == 'S') 
			{
				green_spectra_S(&model, df, nfreqBeg, nfreqEnd,
					iomega, fpeak, dk,
					&source, &recvstat,
					ur[irecv], ut[irecv], uz[irecv], PeriodCheck,urd[irecv], utd[irecv], uzd[irecv]);
			}
			else if (source.SourceType == 'E') 
			{
				green_spectra_E(&model, df, nfreqBeg, nfreqEnd,
					iomega, fpeak, dk,
					&source, &recvstat,
					ur[irecv], ut[irecv], uz[irecv], PeriodCheck);
			}
		}

		////////////////////////////////////////////////////////////////////////
		////////////////////////////////////////////////////////////////////////
		//Output time domain data
		//convolve the Green function with wavelet, amplitude and filtering
		amp0 = source.amplitude;
		for (i = nfreqBeg; i <= nfreqEnd; i++) 
		{
			freq = df*i;
			omega = dcmplx(PI2*freq, -iomega);
            //first "fc" for ricker's central frequency(unit:Hz), second "fcc" for the width of triangle function (unit:s)
            fcc=1/fc;
			wavespec = wavelet(omega, fc, tou, Type_STF,fcc);
			//ctemp = dcrmul(wavespec, amp0*df*nfft);
            ctemp = dcrmul(wavespec, amp0);
/*            printf("ok\n");
			printf("%lf\n",ctemp.r);
			printf("%lf\n",ctemp.i);*/
			for (irecv = 0; irecv < nrecv; irecv++) 
			{
				// judge the x coordinate
				recvstat = lstrecvstat[irecv];
				if (recvstat.sign_r<0)
				sign_r0 = -1;
				else
				sign_r0=1;
				/*printf("ok\n");
				printf("%lf\n",ur[irecv][i].r);
				printf("%lf\n",ur[irecv][i].i);*/

				dcomplex rp=ur[irecv][i];
				ur[irecv][i] = dcmul2(rp, ctemp);
				ur[irecv][i]=dcrmul(ur[irecv][i],sign_r0);
				         rp=ut[irecv][i];
				ut[irecv][i] = dcmul2(rp, ctemp);
				ut[irecv][i]=dcrmul(ut[irecv][i],sign_r0);
				         rp=uz[irecv][i];
				uz[irecv][i] = dcmul2(rp, ctemp);


				/////////// for curl ////////////////
				        temp=urd[irecv][i];
				urd[irecv][i] = dcmul2(temp, ctemp);
				urd[irecv][i]=dcrmul(urd[irecv][i],sign_r0);
				         temp=utd[irecv][i];
				utd[irecv][i] = dcmul2(temp, ctemp);
				utd[irecv][i]=dcrmul(utd[irecv][i],sign_r0);
				         temp=uzd[irecv][i];
				uzd[irecv][i] = dcmul2(temp, ctemp);
			}
		}
		//exit(0);
       /////////////// for curl of displacement//////////////////
	if(strcmp(outputdata1,"100")==0||strcmp(outputdata1,"110")==0||strcmp(outputdata1,"101")==0||strcmp(outputdata1,"111")==0)
      {
		sprintf(Ur_output, "%s%s%03d%s", prefix_output, "/curl_ur_shot", isour + 1, ".sgy");
		sprintf(Ut_output, "%s%s%03d%s", prefix_output, "/curl_ut_shot", isour + 1, ".sgy");
		sprintf(Uz_output, "%s%s%03d%s", prefix_output, "/curl_uz_shot", isour + 1, ".sgy");
		if ((fileUr = fopen(Ur_output, "wb")) == NULL) {
			printf("File Ur_TD could not be opened. \n");
			exit(1);
		}
		//openfile: output time domain transverse vibration wave data
		if ((fileUt = fopen(Ut_output, "wb")) == NULL) {
			printf("File Ut_TD could not be opened. \n");
			exit(1);
		}
		//openfile: output time domain vertical vibration wave data
		if ((fileUz = fopen(Uz_output, "wb")) == NULL) {
			printf("File Uz_TD could not be opened. \n");
			exit(1);
		}
		for (irecv = 0; irecv < nrecv; irecv++) {
			//zero the memory
			memset(urreal, 0, nfft * sizeof(double));
			memset(urimag, 0, nfft * sizeof(double));
			memset(utreal, 0, nfft * sizeof(double));
			memset(utimag, 0, nfft * sizeof(double));
			memset(uzreal, 0, nfft * sizeof(double));
			memset(uzimag, 0, nfft * sizeof(double));
			//split the real and image part of complex
			for (i = 0; i <= nfreq; i++) {
				urreal[i] = urd[irecv][i].r;
				urimag[i] = urd[irecv][i].i;
				utreal[i] = utd[irecv][i].r;
				utimag[i] = utd[irecv][i].i;
				uzreal[i] = uzd[irecv][i].r;
				uzimag[i] = uzd[irecv][i].i;
			}
			for (i = nfft - 1; i > nfreq; i--) {
				urreal[i] = urreal[nfft - i];
				urimag[i] = -urimag[nfft - i];
				utreal[i] = utreal[nfft - i];
				utimag[i] = -utimag[nfft - i];
				uzreal[i] = uzreal[nfft - i];
				uzimag[i] = -uzimag[nfft - i];
			}
			//transform to time domain
			fft842(1, nfft, urreal, urimag);
			fft842(1, nfft, utreal, utimag);
			fft842(1, nfft, uzreal, uzimag);
			//recover the amplitude dampping along time
			for (i = 0; i < nt; i++) {
				dtemp = exp(iomega*i*dt);
				urdata[i] = urreal[i] * dtemp/8.9198/pow(10,17)/dt;
				utdata[i] = utreal[i] * dtemp/8.9198/pow(10,17)/dt;
				uzdata[i] = uzreal[i] * dtemp/8.9198/pow(10,17)/dt;
			}
			//set segy headword
			recvstat = lstrecvstat[irecv];
			memset(&tr, 0, HDRBYTES);
			tr.ns =(unsigned short)nt;
			tr.dt = (unsigned short)(dt * 1000000);
			tr.offset =(int)(recvstat.distance*1000*1000);
			tr.gelev = (int)(recvstat.depth*1000*1000);
			tr.gx = (int)(recvstat.g_x*1000);

			tr.gy = (int)(recvstat.g_y*1000);
			tr.sdepth = (int)(source.depth*1000*1000);
			tr.selev = (int)(source.depth*1000*1000);
			tr.styp = source.SourceType;
			tr.fldr =recvstat.line;
			tr.ep = isour + 1;
			tr.tracl = recvstat.ngather;
			tr.scalco =(short)1000;
			tr.delrt =(short)(tou*1000);//unit:ms
			//write the trace head and data in SEGY format
          
			fwritetrdata(fileUr, tr, urdata);
			fwritetrdata(fileUt, tr, utdata);
			fwritetrdata(fileUz, tr, uzdata);
     
		}
		fclose(fileUr);
		fclose(fileUt);
		fclose(fileUz);
      }//curl outputdata
		///////////////////////////////////////
		//openfile: output time domain radial vibration wave data
    if(strcmp(outputdata,"100")==0||strcmp(outputdata,"110")==0||strcmp(outputdata,"101")==0||strcmp(outputdata,"111")==0)
      {
		sprintf(Ur_output, "%s%s%03d%s", prefix_output, "/data_ur_shot", isour + 1, ".sgy");
		sprintf(Ut_output, "%s%s%03d%s", prefix_output, "/data_ut_shot", isour + 1, ".sgy");
		sprintf(Uz_output, "%s%s%03d%s", prefix_output, "/data_uz_shot", isour + 1, ".sgy");
		if ((fileUr = fopen(Ur_output, "wb")) == NULL) {
			printf("File Ur_TD could not be opened. \n");
			exit(1);
		}
		//openfile: output time domain transverse vibration wave data
		if ((fileUt = fopen(Ut_output, "wb")) == NULL) {
			printf("File Ut_TD could not be opened. \n");
			exit(1);
		}
		//openfile: output time domain vertical vibration wave data
		if ((fileUz = fopen(Uz_output, "wb")) == NULL) {
			printf("File Uz_TD could not be opened. \n");
			exit(1);
		}
		for (irecv = 0; irecv < nrecv; irecv++) {
			//zero the memory
			memset(urreal, 0, nfft * sizeof(double));
			memset(urimag, 0, nfft * sizeof(double));
			memset(utreal, 0, nfft * sizeof(double));
			memset(utimag, 0, nfft * sizeof(double));
			memset(uzreal, 0, nfft * sizeof(double));
			memset(uzimag, 0, nfft * sizeof(double));
			//split the real and image part of complex
			for (i = 0; i <= nfreq; i++) {
				urreal[i] = ur[irecv][i].r;
				urimag[i] = ur[irecv][i].i;
				utreal[i] = ut[irecv][i].r;
				utimag[i] = ut[irecv][i].i;
				uzreal[i] = uz[irecv][i].r;
				uzimag[i] = uz[irecv][i].i;
			}
			for (i = nfft - 1; i > nfreq; i--) {
				urreal[i] = urreal[nfft - i];
				urimag[i] = -urimag[nfft - i];
				utreal[i] = utreal[nfft - i];
				utimag[i] = -utimag[nfft - i];
				uzreal[i] = uzreal[nfft - i];
				uzimag[i] = -uzimag[nfft - i];
			}
			//transform to time domain
			fft842(1, nfft, urreal, urimag);
			fft842(1, nfft, utreal, utimag);
			fft842(1, nfft, uzreal, uzimag);
			//recover the amplitude dampping along time
			for (i = 0; i < nt; i++) {
				dtemp = exp(iomega*i*dt);
				urdata[i] = urreal[i] * dtemp/8.9198/pow(10,14)/dt;
				utdata[i] = utreal[i] * dtemp/8.9198/pow(10,14)/dt;
				uzdata[i] = uzreal[i] * dtemp/8.9198/pow(10,14)/dt;
			}
			//set segy headword
			recvstat = lstrecvstat[irecv];
			memset(&tr, 0, HDRBYTES);
	  	tr.ns =(unsigned short)nt;
			tr.dt = (unsigned short)(dt * 1000000);
			tr.offset =(int)(recvstat.distance*1000*1000);
			tr.gelev = (int)(recvstat.depth*1000*1000);
			tr.gx = (int)(recvstat.g_x*1000);

			tr.gy = (int)(recvstat.g_y*1000);
			tr.sdepth = (int)(source.depth*1000*1000);
			tr.selev = (int)(source.depth*1000*1000);
			tr.styp = source.SourceType;
			tr.fldr =recvstat.line;
			tr.ep = isour + 1;
			tr.tracl = recvstat.ngather;
			tr.scalco =(short)1000;
			tr.delrt =(short)(tou*1000);//unit:ms
			//write the trace head and data in SEGY format
          
			fwritetrdata(fileUr, tr, urdata);
			fwritetrdata(fileUt, tr, utdata);
			fwritetrdata(fileUz, tr, uzdata);
     
		}
		fclose(fileUr);
		fclose(fileUt);
		fclose(fileUz);
      }//outputdata
		//////////////////////////////////////////////
      ///////////////////// curl of velocity //////////////////////
    if(strcmp(outputdata1,"010")==0||strcmp(outputdata1,"110")==0||strcmp(outputdata1,"011")==0||strcmp(outputdata1,"111")==0)
    {
	
		sprintf(Ur_output, "%s%s%03d%s", prefix_output, "/curl_vr_shot", isour + 1, ".sgy");
		sprintf(Ut_output, "%s%s%03d%s", prefix_output, "/curl_vt_shot", isour + 1, ".sgy");
		sprintf(Uz_output, "%s%s%03d%s", prefix_output, "/curl_vz_shot", isour + 1, ".sgy");
		if ((fileUr = fopen(Ur_output, "wb")) == NULL) {
			printf("File Vr_TD could not be opened. \n");
			exit(1);
		}
		//openfile: output time domain transverse vibration wave data
		if ((fileUt = fopen(Ut_output, "wb")) == NULL) {
			printf("File Vt_TD could not be opened. \n");
			exit(1);
		}
		//openfile: output time domain vertical vibration wave data
		if ((fileUz = fopen(Uz_output, "wb")) == NULL) {
			printf("File Vz_TD could not be opened. \n");
			exit(1);
		}
		//write the header
        
		for (irecv = 0; irecv < nrecv; irecv++) {
			//zero the memory
			memset(urreal, 0, nfft * sizeof(double));
			memset(urimag, 0, nfft * sizeof(double));
			memset(utreal, 0, nfft * sizeof(double));
			memset(utimag, 0, nfft * sizeof(double));
			memset(uzreal, 0, nfft * sizeof(double));
			memset(uzimag, 0, nfft * sizeof(double));
			//transform to particle velocity, split the real and image part of complex
			for (i = 0; i <= nfreq; i++) {
				freq = df*i;
				omega = dcmplx(PI2*freq, -iomega);
				//omega = dcmplx(PI2*freq, 0);

				ctemp = dcmul(AJ, omega);
				dcomplex rp=urd[irecv][i];
				ctemp1 = dcmul2(rp, ctemp);
				         rp=utd[irecv][i];
				ctemp2 = dcmul2(rp, ctemp);
				         rp=uzd[irecv][i];
				ctemp3 = dcmul2(rp, ctemp);
				urreal[i] = ctemp1.r;
				urimag[i] = ctemp1.i;
				utreal[i] = ctemp2.r;
				utimag[i] = ctemp2.i;
				uzreal[i] = ctemp3.r;
				uzimag[i] = ctemp3.i;
			}
			for (i = nfft - 1; i > nfreq; i--) {
				urreal[i] = urreal[nfft - i];
				urimag[i] = -urimag[nfft - i];
				utreal[i] = utreal[nfft - i];
				utimag[i] = -utimag[nfft - i];
				uzreal[i] = uzreal[nfft - i];
				uzimag[i] = -uzimag[nfft - i];
			}
			//transform to time domain
			fft842(1, nfft, urreal, urimag);
			fft842(1, nfft, utreal, utimag);
			fft842(1, nfft, uzreal, uzimag);
			//recover the amplitude dampping along time
			for (i = 0; i < nt; i++) {
				dtemp = exp(iomega*i*dt);
				urdata[i] = urreal[i] * dtemp/8.9198/pow(10,17)/dt;
				utdata[i] = utreal[i] * dtemp/8.9198/pow(10,17)/dt;
				uzdata[i] = uzreal[i] * dtemp/8.9198/pow(10,17)/dt;
			}
			//set segy headword
			recvstat = lstrecvstat[irecv];
			memset(&tr, 0, HDRBYTES);
			tr.ns =(unsigned short)nt;
			tr.dt = (unsigned short)(dt * 1000000);
			tr.offset =(int)(recvstat.distance*1000*1000);
			tr.gelev = (int)(recvstat.depth*1000*1000);
			tr.gx = (int)(recvstat.g_x*1000);

			tr.gy = (int)(recvstat.g_y*1000);
			tr.sdepth = (int)(source.depth*1000*1000);
			tr.selev = (int)(source.depth*1000*1000);
			tr.styp = source.SourceType;
			tr.fldr =recvstat.line;
			tr.ep = isour + 1;
			tr.tracl = recvstat.ngather;
			tr.scalco =(short)1000;
			tr.delrt =(short)(tou*1000);//unit:ms
			//write the trace head and data in SEGY format
			fwritetrdata(fileUr, tr, urdata);
			fwritetrdata(fileUt, tr, utdata);
			fwritetrdata(fileUz, tr, uzdata);
		}
		fclose(fileUr);
		fclose(fileUt);
		fclose(fileUz);

    }//outputdata
		//particle velocity
    if(strcmp(outputdata,"010")==0||strcmp(outputdata,"110")==0||strcmp(outputdata,"011")==0||strcmp(outputdata,"111")==0)
    {
	
		sprintf(Ur_output, "%s%s%03d%s", prefix_output, "/data_vr_shot", isour + 1, ".sgy");
		sprintf(Ut_output, "%s%s%03d%s", prefix_output, "/data_vt_shot", isour + 1, ".sgy");
		sprintf(Uz_output, "%s%s%03d%s", prefix_output, "/data_vz_shot", isour + 1, ".sgy");
		if ((fileUr = fopen(Ur_output, "wb")) == NULL) {
			printf("File Vr_TD could not be opened. \n");
			exit(1);
		}
		//openfile: output time domain transverse vibration wave data
		if ((fileUt = fopen(Ut_output, "wb")) == NULL) {
			printf("File Vt_TD could not be opened. \n");
			exit(1);
		}
		//openfile: output time domain vertical vibration wave data
		if ((fileUz = fopen(Uz_output, "wb")) == NULL) {
			printf("File Vz_TD could not be opened. \n");
			exit(1);
		}
		//write the header
        
		for (irecv = 0; irecv < nrecv; irecv++) {
			//zero the memory
			memset(urreal, 0, nfft * sizeof(double));
			memset(urimag, 0, nfft * sizeof(double));
			memset(utreal, 0, nfft * sizeof(double));
			memset(utimag, 0, nfft * sizeof(double));
			memset(uzreal, 0, nfft * sizeof(double));
			memset(uzimag, 0, nfft * sizeof(double));
			//transform to particle velocity, split the real and image part of complex
			for (i = 0; i <= nfreq; i++) {
				freq = df*i;
				omega = dcmplx(PI2*freq, -iomega);
				//omega = dcmplx(PI2*freq, 0);

				ctemp = dcmul(AJ, omega);
				dcomplex rp=ur[irecv][i];
				ctemp1 = dcmul2(rp, ctemp);
				         rp=ut[irecv][i];
				ctemp2 = dcmul2(rp, ctemp);
				         rp=uz[irecv][i];
				ctemp3 = dcmul2(rp, ctemp);
				urreal[i] = ctemp1.r;
				urimag[i] = ctemp1.i;
				utreal[i] = ctemp2.r;
				utimag[i] = ctemp2.i;
				uzreal[i] = ctemp3.r;
				uzimag[i] = ctemp3.i;
			}
			for (i = nfft - 1; i > nfreq; i--) {
				urreal[i] = urreal[nfft - i];
				urimag[i] = -urimag[nfft - i];
				utreal[i] = utreal[nfft - i];
				utimag[i] = -utimag[nfft - i];
				uzreal[i] = uzreal[nfft - i];
				uzimag[i] = -uzimag[nfft - i];
			}
			//transform to time domain
			fft842(1, nfft, urreal, urimag);
			fft842(1, nfft, utreal, utimag);
			fft842(1, nfft, uzreal, uzimag);
			//recover the amplitude dampping along time
			for (i = 0; i < nt; i++) {
				dtemp = exp(iomega*i*dt);
				urdata[i] = urreal[i] * dtemp/8.9198/pow(10,14)/dt;
				utdata[i] = utreal[i] * dtemp/8.9198/pow(10,14)/dt;
				uzdata[i] = uzreal[i] * dtemp/8.9198/pow(10,14)/dt;
			}
			//set segy headword
			recvstat = lstrecvstat[irecv];
			memset(&tr, 0, HDRBYTES);
			tr.ns =(unsigned short)nt;
			tr.dt = (unsigned short)(dt * 1000000);
			tr.offset =(int)(recvstat.distance*1000*1000);
			tr.gelev = (int)(recvstat.depth*1000*1000);
			tr.gx = (int)(recvstat.g_x*1000);

			tr.gy = (int)(recvstat.g_y*1000);
			tr.sdepth = (int)(source.depth*1000*1000);
			tr.selev = (int)(source.depth*1000*1000);
			tr.styp = source.SourceType;
			tr.fldr =recvstat.line;
			tr.ep = isour + 1;
			tr.tracl = recvstat.ngather;
			tr.scalco =(short)1000;
			tr.delrt =(short)(tou*1000);//unit:ms
			//write the trace head and data in SEGY format
			fwritetrdata(fileUr, tr, urdata);
			fwritetrdata(fileUt, tr, utdata);
			fwritetrdata(fileUz, tr, uzdata);
		}
		fclose(fileUr);
		fclose(fileUt);
		fclose(fileUz);

    }//outputdata
		///////////////////// for curl of acceleration/////////////////////////
    if(strcmp(outputdata1,"001")==0||strcmp(outputdata1,"101")==0||strcmp(outputdata1,"011")==0||strcmp(outputdata1,"111")==0)
    {
		sprintf(Ur_output, "%s%s%03d%s", prefix_output, "/curl_ar_shot", isour + 1, ".sgy");
		sprintf(Ut_output, "%s%s%03d%s", prefix_output, "/curl_at_shot", isour + 1, ".sgy");
		sprintf(Uz_output, "%s%s%03d%s", prefix_output, "/curl_az_shot", isour + 1, ".sgy");
		if ((fileUr = fopen(Ur_output, "wb")) == NULL) {
			printf("File Ar_TD could not be opened. \n");
			exit(1);
		}
		//openfile: output time domain transverse vibration wave data
		if ((fileUt = fopen(Ut_output, "wb")) == NULL) {
			printf("File At_TD could not be opened. \n");
			exit(1);
		}
		//openfile: output time domain vertical vibration wave data
		if ((fileUz = fopen(Uz_output, "wb")) == NULL) {
			printf("File Az_TD could not be opened. \n");
			exit(1);
		}
   
		for (irecv = 0; irecv < nrecv; irecv++) {
			//zero the memory
			memset(urreal, 0, nfft * sizeof(double));
			memset(urimag, 0, nfft * sizeof(double));
			memset(utreal, 0, nfft * sizeof(double));
			memset(utimag, 0, nfft * sizeof(double));
			memset(uzreal, 0, nfft * sizeof(double));
			memset(uzimag, 0, nfft * sizeof(double));
			//transform to particle acceleration, split the real and image part of complex
			for (i = 0; i <= nfreq; i++) {
				freq = df*i;
				omega = dcmplx(PI2*freq, -iomega);
				//omega = dcmplx(PI2*freq, 0);
				ctemp = dcneg(dcmul(omega, omega));
				dcomplex rp=urd[irecv][i];
				ctemp1 = dcmul2(rp, ctemp);
				         rp=utd[irecv][i];
				ctemp2 = dcmul2(rp, ctemp);
				         rp=uzd[irecv][i];
				ctemp3 = dcmul2(rp,ctemp);
				urreal[i] = ctemp1.r;
				urimag[i] = ctemp1.i;
				utreal[i] = ctemp2.r;
				utimag[i] = ctemp2.i;
				uzreal[i] = ctemp3.r;
				uzimag[i] = ctemp3.i;
			}
			for (i = nfft - 1; i > nfreq; i--) {
				urreal[i] = urreal[nfft - i];
				urimag[i] = -urimag[nfft - i];
				utreal[i] = utreal[nfft - i];
				utimag[i] = -utimag[nfft - i];
				uzreal[i] = uzreal[nfft - i];
				uzimag[i] = -uzimag[nfft - i];
			}
			//transform to time domain
			fft842(1, nfft, urreal, urimag);
			fft842(1, nfft, utreal, utimag);
			fft842(1, nfft, uzreal, uzimag);
			//recover the amplitude dampping along time
			for (i = 0; i < nt; i++) {
				dtemp = exp(iomega*i*dt);
				urdata[i] = urreal[i] * dtemp/8.9198/pow(10,17)/dt;
				utdata[i] = utreal[i] * dtemp/8.9198/pow(10,17)/dt;
				uzdata[i] = uzreal[i] * dtemp/8.9198/pow(10,17)/dt;
			}
			//set segy headword
			recvstat = lstrecvstat[irecv];
			memset(&tr, 0, HDRBYTES);
			tr.ns =(unsigned short)nt;
			tr.dt = (unsigned short)(dt * 1000000);
			tr.offset =(int)(recvstat.distance*1000*1000);
			tr.gelev = (int)(recvstat.depth*1000*1000);
			tr.gx = (int)(recvstat.g_x*1000);

			tr.gy = (int)(recvstat.g_y*1000);
			tr.sdepth = (int)(source.depth*1000*1000);
			tr.selev = (int)(source.depth*1000*1000);
			tr.styp = source.SourceType;
			tr.fldr =recvstat.line;
			tr.ep = isour + 1;
			tr.tracl = recvstat.ngather;
			tr.scalco =(short)1000;
			tr.delrt =(short)(tou*1000);//unit:ms
						//write the trace head and data in SEGY format
			fwritetrdata(fileUr, tr, urdata);
			fwritetrdata(fileUt, tr, utdata);
			fwritetrdata(fileUz, tr, uzdata);
		}
		fclose(fileUr);
		fclose(fileUt);
		fclose(fileUz);

    }//outputdata
		//particle acceleration
    if(strcmp(outputdata,"001")==0||strcmp(outputdata,"101")==0||strcmp(outputdata,"011")==0||strcmp(outputdata,"111")==0)
    {
		sprintf(Ur_output, "%s%s%03d%s", prefix_output, "/data_ar_shot", isour + 1, ".sgy");
		sprintf(Ut_output, "%s%s%03d%s", prefix_output, "/data_at_shot", isour + 1, ".sgy");
		sprintf(Uz_output, "%s%s%03d%s", prefix_output, "/data_az_shot", isour + 1, ".sgy");
		if ((fileUr = fopen(Ur_output, "wb")) == NULL) {
			printf("File Ar_TD could not be opened. \n");
			exit(1);
		}
		//openfile: output time domain transverse vibration wave data
		if ((fileUt = fopen(Ut_output, "wb")) == NULL) {
			printf("File At_TD could not be opened. \n");
			exit(1);
		}
		//openfile: output time domain vertical vibration wave data
		if ((fileUz = fopen(Uz_output, "wb")) == NULL) {
			printf("File Az_TD could not be opened. \n");
			exit(1);
		}
   
		for (irecv = 0; irecv < nrecv; irecv++) {
			//zero the memory
			memset(urreal, 0, nfft * sizeof(double));
			memset(urimag, 0, nfft * sizeof(double));
			memset(utreal, 0, nfft * sizeof(double));
			memset(utimag, 0, nfft * sizeof(double));
			memset(uzreal, 0, nfft * sizeof(double));
			memset(uzimag, 0, nfft * sizeof(double));
			//transform to particle acceleration, split the real and image part of complex
			for (i = 0; i <= nfreq; i++) {
				freq = df*i;
				omega = dcmplx(PI2*freq, -iomega);
				//omega = dcmplx(PI2*freq, 0);
				ctemp = dcneg(dcmul(omega, omega));
				dcomplex rp=ur[irecv][i];
				ctemp1 = dcmul2(rp, ctemp);
				         rp=ut[irecv][i];
				ctemp2 = dcmul2(rp, ctemp);
				         rp=uz[irecv][i];
				ctemp3 = dcmul2(rp,ctemp);
				urreal[i] = ctemp1.r;
				urimag[i] = ctemp1.i;
				utreal[i] = ctemp2.r;
				utimag[i] = ctemp2.i;
				uzreal[i] = ctemp3.r;
				uzimag[i] = ctemp3.i;
			}
			for (i = nfft - 1; i > nfreq; i--) {
				urreal[i] = urreal[nfft - i];
				urimag[i] = -urimag[nfft - i];
				utreal[i] = utreal[nfft - i];
				utimag[i] = -utimag[nfft - i];
				uzreal[i] = uzreal[nfft - i];
				uzimag[i] = -uzimag[nfft - i];
			}
			//transform to time domain
			fft842(1, nfft, urreal, urimag);
			fft842(1, nfft, utreal, utimag);
			fft842(1, nfft, uzreal, uzimag);
			//recover the amplitude dampping along time
			for (i = 0; i < nt; i++) {
				dtemp = exp(iomega*i*dt);
				urdata[i] = urreal[i] * dtemp/8.9198/pow(10,14)/dt;
				utdata[i] = utreal[i] * dtemp/8.9198/pow(10,14)/dt;
				uzdata[i] = uzreal[i] * dtemp/8.9198/pow(10,14)/dt;
			}
			//set segy headword
			recvstat = lstrecvstat[irecv];
			memset(&tr, 0, HDRBYTES);
			tr.ns = (unsigned short)nt;
			tr.dt = (unsigned short)(dt * 1000000);
			tr.offset =(int)(recvstat.distance*1000*1000);
			tr.gelev = (int)(recvstat.depth*1000*1000);
			tr.gx = (int)(recvstat.g_x*1000);

			tr.gy = (int)(recvstat.g_y*1000);
			tr.sdepth = (int)(source.depth*1000*1000);
			tr.selev = (int)(source.depth*1000*1000);
			tr.styp = source.SourceType;
			tr.fldr =recvstat.line;
			tr.ep = isour + 1;
			tr.tracl = recvstat.ngather;
			tr.scalco =(short)1000;
			tr.delrt =(short)(tou*1000);//unit:ms
			//write the trace head and data in SEGY format
			fwritetrdata(fileUr, tr, urdata);
			fwritetrdata(fileUt, tr, utdata);
			fwritetrdata(fileUz, tr, uzdata);
		}
		fclose(fileUr);
		fclose(fileUt);
		fclose(fileUz);

    }//outputdata
		//finish output time domain data
		////////////////////////////////////////////////////////////////////////
		////////////////////////////////////////////////////////////////////////
	}
	printf("Finish computing seimogram synthesis.\n");
	ftime=clock();
    time=(float)(ftime-stime)/CLOCKS_PER_SEC;
    printf("total cpu time=%lf s\n",time);
	//free the memory
	free2dcomplex(ur);
	free2dcomplex(ut);
	free2dcomplex(uz);
	free1double(urreal);
	free1double(urimag);
	free1double(utreal);
	free1double(utimag);
	free1double(uzreal);
	free1double(uzimag);
	free1float(urdata);
	free1float(utdata);
	free1float(uzdata);
	free1SourPara(lstsourpara);
	free1RecvStat(lstrecvstat);
	dealloc_model(&model);
	////// for curl /////////////////
	free2dcomplex(urd);
	free2dcomplex(utd);
	free2dcomplex(uzd);
	
	return 0;
}
