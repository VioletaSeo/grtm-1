#pragma once

#include "cwp_mini.h"
#include "model.h"

dcomplex wavelet(dcomplex w, double fc, double tou, char* Type_STF,double fwth);
void eig44(FKRTmodel *model,dcomplex omega1,double k,dcomplex eig4[4],dcomplex eig4vector[16],int lay);
void eig22(FKRTmodel *model,dcomplex omega1,double k,dcomplex eig2[2],dcomplex eig2vector[4],int lay);
void eig4(double k, double L, double F, double A,double P,double C,double W,double WC,dcomplex eig[4],dcomplex eigvector[16]);


