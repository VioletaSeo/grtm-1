#pragma once

#include "model.h"
#include "source_and_receiver.h"

void integral_function_coeff_D(double k, FKRTmodel *model, const RadPat_D *radpat,
	const int layerSour, const int layerRecv,
	const double zSour, const double zRecv,
	dcomplex fun_coeff[12],dcomplex fun_coeffd[32]);

void integration_D(dcomplex integ[3], const dcomplex fun_coeff[12], 
	double j0, double j1, double j2, double j0d, double j1d, double j2d,dcomplex integd[3], const dcomplex fun_coeffd[32],
	double j3, double j4, double j1dd, double j2dd);

void integral_function_coeff_S(double k, FKRTmodel *model, const RadPat_S *radpat,
	const int layerSour, const int layerRecv,
	const double zSour, const double zRecv,
	dcomplex fun_coeff[7],dcomplex fun_coeffd[14]);

void integration_S(dcomplex integ[3], const dcomplex fun_coeff[7],
	double j0, double j1, double j0d, double j1d,double j2, double j3, double j2d,dcomplex integd[3], const dcomplex fun_coeffd[14]);

void integral_function_coeff_E(double k, FKRTmodel *model,
	const int layerSour, const int layerRecv,
	const double zSour, const double zRecv,
	dcomplex fun_coeff[2]);

void integration_E(dcomplex integ[3], const dcomplex fun_coeff[2],
	double j0, double j0d);

void integral_function_coeff_E0(double k, FKRTmodel *model,
	const int layerSour, const int layerRecv,
	const double zSour, const double zRecv,
	dcomplex fun_coeff[2]);