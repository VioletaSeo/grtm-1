#pragma once

#include "model.h"

void calc_q_D(FKRTmodel *model, const int layerSour, const double zSour, const double zRecv);

void calc_q_S(FKRTmodel *model, const int layerSour, const double zSour, const double zRecv);

void calc_q_E(FKRTmodel *model, const int layerSour, const double zSour, const double zRecv);

void calc_q_E0(FKRTmodel *model, const int layerSour, const double zSour, const double zRecv);