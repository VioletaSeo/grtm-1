#pragma once

#include "cwp_mini.h"

typedef struct _Reflect_Transm_model_in_FK {
	int totalLayer,media;
	double k;        //horizontal wavenumber
	dcomplex omega;  //complex frequency
	double *z;  //depth of bottom boundary of layer
	double *Rho;
	double *Vp;
	double *Vs;
	double *Qp;
	double *Qs;
	double *mu; //Lame constant
	//frequency-domain model
	dcomplex *CVp;  //complex Vp
	dcomplex *CVs;  //complex Vs
	//frequency-wavenumber-domain model
	dcomplex *kzp;  //vertical wavenumber of primary wave
	dcomplex *kzs;  //vertical wavenumber of secondary wave
	/**********R/T of a layer means R/T of bottom boundary of the layer*********/
	//RT SH
	dcomplex *TddSH;
	dcomplex *TuuSH;
	dcomplex *RduSH;
	dcomplex *RudSH;
	//GRT SH
	dcomplex *GTddSH;
	dcomplex *GTuuSH;
	dcomplex *GRduSH;
	dcomplex *GRudSH;
	//RT PSV
	dcomplex **TddPSV;
	dcomplex **TuuPSV;
	dcomplex **RduPSV;
	dcomplex **RudPSV;
	//GRT PSV
	dcomplex **GTddPSV;
	dcomplex **GTuuPSV;
	dcomplex **GRduPSV;
	dcomplex **GRudPSV;
	//wavefield extrapolating quantity through a certaine layer
	dcomplex **ex;

	/////////////// for VTI medium
        double  *AA;
        double  *FF;
        double  *NN;
        double  *CC;
        double  *LL;
        dcomplex **iex;//wavefield extrapolating quantity through a certaine layer for VTI SH
	    dcomplex *shkzs;  //vertical wavenumber of secondary wave sh
        dcomplex **shE;
        dcomplex **psvshE;
	//propagating wavefield between source and receiver
	dcomplex ySH;
	dcomplex yPSV[4];
	dcomplex qSH1;
	dcomplex qSH2;
	dcomplex qPSV0[2];
	dcomplex qPSV1[2];
	dcomplex qPSV2[2];
	// for the curl of displacement modified by Tang Le 2020.1.13
	// derivative
	dcomplex ySHd;
	dcomplex yPSVd[4];
	dcomplex qSH1d;
	dcomplex qSH2d;
	dcomplex qPSV0d[2];
	dcomplex qPSV1d[2];
	dcomplex qPSV2d[2];
	///////////////
}Reflect_Transm_model_in_FK;

#define FKRTmodel Reflect_Transm_model_in_FK

void alloc_initialize_model(FKRTmodel *model, int allocLayers);
void dealloc_model(FKRTmodel *model);

void input_physical_model(FKRTmodel *model, const char *filemodel,int mediatype);

int get_layernumber(const FKRTmodel *model, const double depth);

void get_max_min_velocity(const FKRTmodel *model, double *velmax, double *velmin);

double get_critical_k(FKRTmodel *model, dcomplex omagemin, int nf,
	int layerSour, int layerRecv, double zSour, double zRecv);

void set_complex_frequency_variables(FKRTmodel *model, double freq, double iomega, double freq_reference);

void set_wavenumber_variables(FKRTmodel *model, double k);

