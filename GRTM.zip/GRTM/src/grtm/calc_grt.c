#include "calc_grt.h"
#include "dcsimpleblas.h"
#include "calc_e.h"

void calc_GRT(FKRTmodel *model, const int layerSour)
{
///////for VTI
  dcomplex eig2[2],eig2vector[4],eig4[4],eig4vector[16];
  dcomplex **SHE,pSHE[4],pSHE1[4],pSHE2[4],**pSVSHE ;
	//begin: declare variables in FKRTmodel
	int			totalLayer;
	double		k;
	dcomplex	omega;
	double		*pZ;
	double		*pMU;
	dcomplex	*pCVP;
	dcomplex	*pCVS;
	dcomplex	*pKZP;
	dcomplex	*pKZS;
/////////////VTI/////////////
  dcomplex   *pSHKZS;
  dcomplex  **pIEX;
////////////////////////////
	dcomplex	*pTddSH;
	dcomplex	*pTuuSH;
	dcomplex	*pRduSH;
	dcomplex	*pRudSH;
	dcomplex	*pGTddSH;
	dcomplex	*pGTuuSH;
	dcomplex	*pGRduSH;
	dcomplex	*pGRudSH;
	dcomplex    **pTddPSV;
	dcomplex    **pTuuPSV;
	dcomplex    **pRduPSV;
	dcomplex    **pRudPSV;
	dcomplex    **pGTddPSV;
	dcomplex    **pGTuuPSV;
	dcomplex    **pGRduPSV;
	dcomplex    **pGRudPSV;
	dcomplex    **pEX;
	//end: declare variables in FKRTmodel
	//local variable
	int lay, lp1, lm1;
	int i, j;
	double dz;
	dcomplex temp2,temp3,temp31,temp21,rp,rp1,rp2,rp3,temp1;
	double rrp;
	//temporary linear memrory space
	dcomplex WorkSpace[64];
	dcomplex *A44, *B44, *C44, *D44;
	dcomplex *Mat22A, *Mat22B;
	dcomplex *Mdd, *Mud, *Mdu, *Muu;
	dcomplex *Gdd, *Gud, *Gdu, *Guu;
	dcomplex *A22, *B22, *C22, *D22;
	//used in this function domain
	A44 = WorkSpace;
	//only used for Modified RT
	B44 = WorkSpace + 16;
	C44 = WorkSpace + 32;
	D44 = WorkSpace + 48;
	//only used for Generalized RT
	Mdd = WorkSpace+16;
	Mud = WorkSpace + 20;
	Mdu = WorkSpace + 24;
	Muu = WorkSpace + 28;

	Gdd = WorkSpace + 32;
	Gud = WorkSpace + 36;
	Gdu = WorkSpace + 40;
	Guu = WorkSpace + 44;

	A22 = WorkSpace + 48;
	B22 = WorkSpace + 52;
	C22 = WorkSpace + 56;
	D22 = WorkSpace + 60;

	//begin: refer to variables in FKRTmodel
	totalLayer = model->totalLayer;
	pZ = model->z;
	pMU = model->mu;
	omega = model->omega;
	k = model->k;
	pCVP = model->CVp;
	pCVS = model->CVs;
	pKZP = model->kzp;
	pKZS = model->kzs;
 ///////////VTI //////
  pSHKZS=model->shkzs;
  pIEX=model->iex;
  SHE=model->shE;
  pSVSHE=model->psvshE;
 //////////////////////
	pTddSH = model->TddSH;
	pTuuSH = model->TuuSH;
	pRduSH = model->RduSH;
	pRudSH = model->RudSH;
	pGTddSH = model->GTddSH;
	pGTuuSH = model->GTuuSH;
	pGRduSH = model->GRduSH;
	pGRudSH = model->GRudSH;
	pTddPSV = model->TddPSV;
	pTuuPSV = model->TuuPSV;
	pRduPSV = model->RduPSV;
	pRudPSV = model->RudPSV;
	pGTddPSV = model->GTddPSV;
	pGTuuPSV = model->GTuuPSV;
	pGRduPSV = model->GRduPSV;
	pGRudPSV = model->GRudPSV;
	pEX = model->ex;
	//end: refer to variables in FKRTmodel
	//SH
	//Modified RT
	for (lay = 1; lay < totalLayer; lay++)
	 {
		//extrapolation operator
		lp1 = lay + 1;
		lm1 = lay - 1;
		dz = pZ[lm1] - pZ[lay];

		if(model->media==1) //isotropy
		{

		rp=pKZP[lay];
		
		
		
		pEX[lay][0] = dcexp(dcrmul2(rp, dz));

		rp=pKZS[lay];
		
		pEX[lay][1] = dcexp(dcrmul2(rp, dz));
		//SH
		rp=pKZS[lay];
		rrp=pMU[lay];
		temp1 = dcrmul2(rp, rrp);
		rp=pKZS[lp1];
		rrp=pMU[lp1];
				
		temp2 = dcrmul2(rp,rrp);
				
		rp=temp1;
		rp1=temp2;
		temp3 = dcadd2(rp, rp1);
                rp=temp1;   
		rp=dcrmul2(rp, 2.0);
		rp1=temp3;
		pTddSH[lay] = dcdiv2(rp,rp1);
		rp=temp1;rp1=temp2;
		rp=dcsub2(rp,rp1);
		rp1=temp3;
		pRduSH[lay] = dcdiv2(rp,rp1);
		rp=pRduSH[lay];
		pRudSH[lay] = dcneg2(rp);
		rp=temp2;
		rp=dcrmul2(rp, 2.0);
		rp1=temp3;
		pTuuSH[lay] = dcdiv(rp,rp1);
		

		
		//PSV
		calcE(k, omega, pMU[lay], pCVP[lay], pCVS[lay], pKZP[lay], pKZS[lay], C44);
		calcE(k, omega, pMU[lp1], pCVP[lp1], pCVS[lp1], pKZP[lp1], pKZS[lp1], D44);
		assemEdEu(C44, D44, A44, B44);
		dcinv44(A44);
		dcmul44(A44, B44, C44);
		partMat44to22(C44, pTddPSV[lay], pRudPSV[lay], pRduPSV[lay], pTuuPSV[lay]);
		

		}
		else //VTI
		{
			pEX[lay][0] = dcexp(dcrmul(pKZP[lay], dz));
			pEX[lay][1] = dcexp(dcrmul(pKZS[lay], dz));
       		pIEX[lay][0]= dcexp(dcrmul(pSHKZS[lay], dz));
    /////////////////FOR VTI 

 
      		pSHE[0]=SHE[lp1][0];
      		pSHE[1]=dcneg(SHE[lay][1]);
      		pSHE[2]=SHE[lp1][2];
      		pSHE[3]=dcneg(SHE[lay][3]);
      		pSHE1[0]=SHE[lay][0];
      		pSHE1[1]=dcneg(SHE[lp1][1]);
      		pSHE1[2]=SHE[lay][2];
      		pSHE1[3]=dcneg(SHE[lp1][3]);
   
      		dcinv22(pSHE);

      		dcmul22(pSHE,pSHE1,pSHE2);
      		pTddSH[lay]=pSHE2[0];  	
      		pRudSH[lay]=pSHE2[1];
      		pRduSH[lay]=pSHE2[2];
      		pTuuSH[lay]=pSHE2[3];

    ///////////////	//PSV
    		for(i=0;i<16;i++)
    		{
          		C44[i]=pSVSHE[lay][i];
          		D44[i]=pSVSHE[lp1][i];
    		}  

			assemEdEu(C44, D44, A44, B44);

			dcinv44(A44);

			dcmul44(A44, B44, C44);
			partMat44to22(C44, pTddPSV[lay], pRudPSV[lay], pRduPSV[lay], pTuuPSV[lay]);


		}

	}
	
	//generalized RT dowward: 0~LaySource-1
	//SH
      ////////////////////////

//////////////////////////////////////// 
	if (model->media==1)//isotropy
	{
	pGRudSH[0] = dcmplx(1.0, 0.);
	//PSV
	//GRudPSV[0]=-E22/E21
	calcE21E22(k, omega, pMU[1], pCVP[1], pCVS[1], pKZP[1], pKZS[1], A22, B22);
	dcinv22(A22);
	dcmul22(A22, B22, pGRudPSV[0]);
	dcneg22(pGRudPSV[0]);
	}
	else
	{
		/////SH
    	pGRudSH[0] = dcmul(dcneg(dcdiv(dcmplx(1,0),SHE[1][2])),SHE[1][3]);

        /////PSV

    
           A22[0]=pSVSHE[1][8];
           A22[1]=pSVSHE[1][9];
           B22[0]=pSVSHE[1][10];
           B22[1]=pSVSHE[1][11];
           A22[2]=pSVSHE[1][12];
           A22[3]=pSVSHE[1][13];
           B22[2]=pSVSHE[1][14];
           B22[3]=pSVSHE[1][15];

     

  			dcinv22(A22); 
  	  
  			dcmul22(A22, B22, pGRudPSV[0]);
  			dcneg22(pGRudPSV[0]);

	}

	for (lay = 1; lay < layerSour; lay++) 
	{
		lm1 = lay - 1;
		if (model->media==1)//isotropy
		{
		//SH
        rp=pGRudSH[lm1];
        rp1= pEX[lay][1];
		temp1 = dcmul2(rp,rp1);
		rp=pRduSH[lay];
		rp1= pEX[lay][1];
		temp2 = dcmul2(rp,rp1);
		rp=pTddSH[lay];
		rp1=pEX[lay][1];
		temp3 = dcmul2(rp, rp1);
		rp=temp1;rp1=temp2;
		rp=dcmul2(rp,rp1);
		rp1=drcsub2(1.0, rp);
		rp2=pTuuSH[lay];
        pGTuuSH[lay] = dcdiv2(rp2, rp1);
        rp=temp1;rp1=temp3;
        rp=dcmul2(rp,rp1);
        rp1=pGTuuSH[lay];
        rp2=dcmul2(rp, rp1);
        rp3=pRudSH[lay];
		pGRudSH[lay] = dcadd2(rp3, rp2);
               
    		
		//PSV
		dcmulRD22(pRduPSV[lay], pEX[lay], Mdu);
		dcmulRD22(pTddPSV[lay], pEX[lay], Mdd);
		dcmulRD22(pGRudPSV[lm1], pEX[lay], Gud);
		//GTuuPSV
		dcmul22(Mdu, Gud, A22);
		dcUnitSub22(A22);
		dcinv22(A22);
		dcmul22(A22, pTuuPSV[lay], pGTuuPSV[lay]);
		//GRudPSV
		dcmul22(Mdd, Gud, B22);
		dcmul22(B22, pGTuuPSV[lay], C22);
		dcadd22(C22, pRudPSV[lay], pGRudPSV[lay]);
		}
		else//VTI
		{
     	 //SH
   		temp1 = dcmul(pGRudSH[lm1], pIEX[lay][0]);
		temp2 = dcmul(pRduSH[lay], pIEX[lay][0]);
		temp3 = dcmul(pTddSH[lay], pIEX[lay][0]);
        pGTuuSH[lay] = dcdiv(pTuuSH[lay], drcsub(1.0, dcmul(temp1, temp2)));
		pGRudSH[lay] = dcadd(pRudSH[lay], dcmul(dcmul(temp1, temp3), pGTuuSH[lay]));
    	/////PSV	
     
		dcmulRD22(pRduPSV[lay], pEX[lay], Mdu);
		dcmulRD22(pTddPSV[lay], pEX[lay], Mdd);
		dcmulRD22(pGRudPSV[lm1], pEX[lay], Gud);
		//GTuuPSV
		dcmul22(Mdu, Gud, A22);
		dcUnitSub22(A22);

		dcinv22(A22);
		dcmul22(A22, pTuuPSV[lay], pGTuuPSV[lay]);
		//GRudPSV
		dcmul22(Mdd, Gud, B22);
		dcmul22(B22, pGTuuPSV[lay], C22);
		dcadd22(C22, pRudPSV[lay], pGRudPSV[lay]);			

		}



	}


//////////////
	//generalized RT upward: (N-1)~LaySource
	lay = totalLayer - 1;
	//SH
	pGRduSH[lay] = pRduSH[lay];
	//PSV
	dcassign22(pRduPSV[lay], pGRduPSV[lay]);
	for (lay = totalLayer - 2; lay >= layerSour; lay--) 
	{
		lp1 = lay + 1;

		if(model->media==1)//isotropy
		{
		rp=pGRduSH[lp1];
		rp1=pEX[lp1][1];
		temp1 = dcmul2(rp, rp1);
		rp=pRudSH[lay];
		rp1= pEX[lp1][1];
		temp2 = dcmul2(rp,rp1);
		rp=pTuuSH[lay];
		rp1=pEX[lp1][1];
		temp3 = dcmul2(rp, rp1);
		rp=temp1;rp1=temp2;
		rp=dcmul2(rp,rp1);
		rp1=drcsub2(1.0, rp);
		rp2=pTddSH[lay];
		pGTddSH[lay] = dcdiv2(rp2, rp1);
		rp=temp1;rp1=temp3;
		rp=dcmul2(rp,rp1);
		rp1=pGTddSH[lay];
		rp2=dcmul2(rp, rp1);
		rp3=pRduSH[lay];
		pGRduSH[lay] = dcadd2(rp3, rp2);
		//PSV
		dcmulRD22(pRudPSV[lay], pEX[lp1], Mud);
		dcmulRD22(pTuuPSV[lay], pEX[lp1], Muu);
		dcmulRD22(pGRduPSV[lp1], pEX[lp1], Gdu);
		//GTddPSV
		dcmul22(Mud, Gdu, A22);
		dcUnitSub22(A22);
		dcinv22(A22);
		dcmul22(A22, pTddPSV[lay], pGTddPSV[lay]);
		//GRduPSV
		dcmul22(Muu, Gdu, B22);
		dcmul22(B22, pGTddPSV[lay], C22);
		dcadd22(C22, pRduPSV[lay], pGRduPSV[lay]);
		

		}
		else//VTI
		{
		temp1 = dcmul(pGRduSH[lp1], pIEX[lp1][0]);
		temp2 = dcmul(pRudSH[lay], pIEX[lp1][0]);
		temp3 = dcmul(pTuuSH[lay], pIEX[lp1][0]);
		pGTddSH[lay] = dcdiv(pTddSH[lay], drcsub(1.0, dcmul(temp1, temp2)));
		pGRduSH[lay] = dcadd(pRduSH[lay], dcmul(dcmul(temp1, temp3), pGTddSH[lay]));
		
		//PSV
		dcmulRD22(pRudPSV[lay], pEX[lp1], Mud);
		dcmulRD22(pTuuPSV[lay], pEX[lp1], Muu);
		dcmulRD22(pGRduPSV[lp1], pEX[lp1], Gdu);
		//GTddPSV
		dcmul22(Mud, Gdu, A22);
		dcUnitSub22(A22);
		dcinv22(A22);
		dcmul22(A22, pTddPSV[lay], pGTddPSV[lay]);
		//GRduPSV
		dcmul22(Muu, Gdu, B22);
		dcmul22(B22, pGTddPSV[lay], C22);
		dcadd22(C22, pRduPSV[lay], pGRduPSV[lay]);

		}
		


	}



	return;
}
