//modified from su

/* Copyright (c) Colorado School of Mines, 2011.*/
/* All rights reserved.                       */

/* HDRPKGE: $Revision: 1.12 $ ; $Date: 2011/11/11 23:57:38 $	*/

#include "segywrite.h"

//void fwritetr(FILE *pf, segy *tr)
//{
//	int index;
//	int nt;
//	nt = tr->ns;
//	for (index = 0; index < SU_NKEYS; index++)
//		swaphval(tr, index);
//	for (index = 0; index < nt; index++)
//		swap_float_4(&(tr->data[index]));
//	fwrite(tr, sizeof(float)*nt+HDRBYTES, 1, pf);
//}

void fwritetrdata(FILE *pf, segy tr, float *data)
{
	int index;
	int nt;
	
	nt = tr.ns;
		
	/*for (index = 0; index < SU_NKEYS; index++)
		swaphval(&tr, index);
	for (index = 0; index < nt; index++)
		swap_float_4(&(data[index]));*/

	fwrite(&tr, HDRBYTES, 1, pf);
	fwrite(data, sizeof(float), nt, pf);
}


void swaphval(segy *tr, int index)
{
	register char *tp = (char *)tr;

	switch (*(hdr[index].type)) {
	case 'h': swap_short_2((short*)(tp + hdr[index].offs));
		break;
	case 'u': swap_u_short_2((unsigned short*)(tp + hdr[index].offs));
		break;
	case 'i': swap_int_4((int*)(tp + hdr[index].offs));
		break;
	case 'p': swap_u_int_4((unsigned int*)(tp + hdr[index].offs));
		break;
	case 'l': swap_long_4((long*)(tp + hdr[index].offs));
		break;
	case 'v': swap_u_long_4((unsigned long*)(tp + hdr[index].offs));
		break;
	case 'f': swap_float_4((float*)(tp + hdr[index].offs));
		break;
	case 'd': swap_double_8((double*)(tp + hdr[index].offs));
		break;
		//default: err("%s: %s: unsupported data type", __FILE__, __LINE__);
		//break;
	}

	return;
}


void swap_short_2(short *tni2)
/**************************************************************************
swap_short_2            swap a short integer
***************************************************************************/
{
	*tni2 = (((*tni2 >> 8) & 0xff) | ((*tni2 & 0xff) << 8));
}

void swap_u_short_2(unsigned short *tni2)
/**************************************************************************
swap_u_short_2          swap an unsigned short integer
***************************************************************************/
{
	*tni2 = (((*tni2 >> 8) & 0xff) | ((*tni2 & 0xff) << 8));
}

void swap_int_4(int *tni4)
/**************************************************************************
swap_int_4              swap a 4 byte integer
***************************************************************************/
{
	*tni4 = (((*tni4 >> 24) & 0xff) | ((*tni4 & 0xff) << 24) |
		((*tni4 >> 8) & 0xff00) | ((*tni4 & 0xff00) << 8));
}

void swap_u_int_4(unsigned int *tni4)
/**************************************************************************
swap_u_int_4            swap an unsigned integer
***************************************************************************/
{
	*tni4 = (((*tni4 >> 24) & 0xff) | ((*tni4 & 0xff) << 24) |
		((*tni4 >> 8) & 0xff00) | ((*tni4 & 0xff00) << 8));
}

void swap_long_4(long *tni4)
/**************************************************************************
swap_long_4             swap a long integer
***************************************************************************/
{
	*tni4 = (((*tni4 >> 24) & 0xff) | ((*tni4 & 0xff) << 24) |
		((*tni4 >> 8) & 0xff00) | ((*tni4 & 0xff00) << 8));
}

void swap_u_long_4(unsigned long *tni4)
/**************************************************************************
swap_u_long_4           swap an unsigned long integer
***************************************************************************/
{
	*tni4 = (((*tni4 >> 24) & 0xff) | ((*tni4 & 0xff) << 24) |
		((*tni4 >> 8) & 0xff00) | ((*tni4 & 0xff00) << 8));
}

void swap_float_4(float *tnf4)
/**************************************************************************
swap_float_4            swap a float
***************************************************************************/
{
	int *tni4 = (int *)tnf4;
	*tni4 = (((*tni4 >> 24) & 0xff) | ((*tni4 & 0xff) << 24) |
		((*tni4 >> 8) & 0xff00) | ((*tni4 & 0xff00) << 8));
}

void swap_double_8(double *tndd8)
/**************************************************************************
swap_double_8           swap a double
***************************************************************************/
{
	char *tnd8 = (char *)tndd8;
	char tnc;

	tnc = *tnd8;
	*tnd8 = *(tnd8 + 7);
	*(tnd8 + 7) = tnc;

	tnc = *(tnd8 + 1);
	*(tnd8 + 1) = *(tnd8 + 6);
	*(tnd8 + 6) = tnc;

	tnc = *(tnd8 + 2);
	*(tnd8 + 2) = *(tnd8 + 5);
	*(tnd8 + 5) = tnc;

	tnc = *(tnd8 + 3);
	*(tnd8 + 3) = *(tnd8 + 4);
	*(tnd8 + 4) = tnc;
}
