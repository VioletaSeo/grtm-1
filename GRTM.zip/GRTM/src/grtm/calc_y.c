#include "calc_y.h"
#include "dcsimpleblas.h"
#include "calc_e.h"

void calc_Y(FKRTmodel *model, const int layerSour, const int layerRecv,
	const double zSour, const double zRecv)
{
	//begin: declare variables in FKRTmodel
	int			totalLayer;
	double		k;
	dcomplex	omega;
	double		*pZ;
	double		*pMU;
	dcomplex	*pCVP;
	dcomplex	*pCVS;
	dcomplex	*pKZP;
	dcomplex	*pKZS;
	dcomplex	*pGTddSH;
	dcomplex	*pGTuuSH;
	dcomplex	*pGRduSH;
	dcomplex	*pGRudSH;
	dcomplex    **pGTddPSV;
	dcomplex    **pGTuuPSV;
	dcomplex    **pGRduPSV;
	dcomplex    **pGRudPSV;
	dcomplex    **pEX;
  ///////// VTI
  dcomplex   *pSHKZS;
  dcomplex   **pIEX;
  dcomplex   **SHE;
  dcomplex   **pSVSHE;

	//end: declare variables in FKRTmodel
    dcomplex rp,rp1,rpd;
    double rrp;
	//local variables
	int lay;
	double dz;
	dcomplex temp1, temp2, temp3;
	dcomplex sourSH, recvSH, tranSH;

	//temporary linear memory space
	dcomplex WorkSpace[64];
	dcomplex *exus, *exds;
	dcomplex *exur, *exdr;
	dcomplex *E11, *E12,*E21,*E22;
	dcomplex *sourPSV, *recvPSV, *tranPSV;
	dcomplex *Rud, *Rdu, *ExR, *ExR2, *EExR, *EEx, *Ytemp1, *Ytemp2;
	//
	 ////////// VTI
  dcomplex shexds[1],shexus[1],shexur[1],shexdr[1];
 
	exus = WorkSpace;
	exds = WorkSpace + 2;
	exur = WorkSpace + 4;
	exdr = WorkSpace + 6;
	E11 = WorkSpace + 8;
	E12 = WorkSpace + 12;
	sourPSV = WorkSpace + 16;
	recvPSV = WorkSpace + 20;
	tranPSV = WorkSpace + 24;
	Rud = WorkSpace + 28;
	Rdu = WorkSpace + 32;
	ExR = WorkSpace + 36;
	ExR2 = WorkSpace + 40;
	EExR = WorkSpace + 44;
	EEx = WorkSpace + 48;
	Ytemp1 = WorkSpace + 52;
	Ytemp2 = WorkSpace + 56;
	//begin: refer to variables in FKRTmodel
	totalLayer = model->totalLayer;
	pZ = model->z;
	pMU = model->mu;
	omega = model->omega;
	k = model->k;
	pCVP = model->CVp;
	pCVS = model->CVs;
	pKZP = model->kzp;
	pKZS = model->kzs;
	pGTddSH = model->GTddSH;
	pGTuuSH = model->GTuuSH;
	pGRduSH = model->GRduSH;
	pGRudSH = model->GRudSH;
	pGTddPSV = model->GTddPSV;
	pGTuuPSV = model->GTuuPSV;
	pGRduPSV = model->GRduPSV;
	pGRudPSV = model->GRudPSV;
	pEX = model->ex;
	 /////////////VTI
  pIEX=model->iex;
  pSHKZS=model->shkzs;
  SHE=model->shE;
  pSVSHE=model->psvshE;
  if (model->media==1)//isotrpy
  {
	//extrapolation operators for source
	dz = zSour - pZ[layerSour];
	//printf("%lf %lf %lf\n",dz,zSour,pZ[layerSour]);
	rp=pKZP[layerSour];
	exds[0] = dcexp(dcrmul2(rp, dz));
	rp=pKZS[layerSour];
	exds[1] = dcexp(dcrmul2(rp, dz));
	dz = pZ[layerSour - 1] - zSour;
	//printf("%lf %lf %lf\n",dz,zSour,pZ[layerSour - 1]);
	//exit(0);
	rp=pKZP[layerSour];
	exus[0] = dcexp(dcrmul2(rp, dz));
	rp=pKZS[layerSour];
	exus[1] = dcexp(dcrmul2(rp, dz));
	//E
	calcE11E12(k, omega, pMU[layerRecv], pCVP[layerRecv], pCVS[layerRecv], pKZP[layerRecv], pKZS[layerRecv], E11, E12);
	//SH source
	rp=pGRduSH[layerSour];
	rp1=exds[1];
	rp=dcmul2(rp, rp1);
	rp1=exds[1];
	temp1 = dcmul2(rp1, rp);
	rp=pGRudSH[layerSour - 1];
	rp1=exus[1];
	rp=dcmul2(rp, rp1);
	rp1=exus[1];
	temp2 = dcmul2(rp1, rp);
        ///////////tang le 2019 10.7
	rp=temp1;rp1=temp2;
	temp3 = dcmul2(rp,rp1);
	rp=temp3;
	rp=drcsub2(1.,rp);
	sourSH = dcinv2(rp);
	}
	else//VTI
	{
	dz = zSour - pZ[layerSour];
	exds[0] = dcexp(dcrmul(pKZP[layerSour], dz));
	exds[1] = dcexp(dcrmul(pKZS[layerSour], dz));
    shexds[0]= dcexp(dcrmul(pSHKZS[layerSour], dz));

	dz = pZ[layerSour - 1] - zSour;
	exus[0] = dcexp(dcrmul(pKZP[layerSour], dz));
	exus[1] = dcexp(dcrmul(pKZS[layerSour], dz));
	shexus[0] = dcexp(dcrmul(pSHKZS[layerSour], dz));
	//E
  E11[0]=pSVSHE[layerRecv][0];
  E11[1]=pSVSHE[layerRecv][1];
  E11[2]=pSVSHE[layerRecv][4];
  E11[3]=pSVSHE[layerRecv][5];
  E12[0]=pSVSHE[layerRecv][2];
  E12[1]=pSVSHE[layerRecv][3];
  E12[2]=pSVSHE[layerRecv][6];
  E12[3]=pSVSHE[layerRecv][7];
 

	//calcE11E12(k, omega, pMU[layerRecv], pCVP[layerRecv], pCVS[layerRecv], pKZP[layerRecv], pKZS[layerRecv], E11, E12);
	//SH source
	temp1 = dcmul(shexds[0], dcmul(pGRduSH[layerSour], shexds[0]));
	temp2 = dcmul(shexus[0], dcmul(pGRudSH[layerSour - 1], shexus[0]));
        ///////////tang le 2019 10.7
        //////////////////////////
	temp3 = dcmul(temp1, temp2);
	sourSH = dcinv(drcsub(1.,temp3));

	}


	if (layerSour == layerRecv && zRecv <= zSour) 
	{
		if(model->media==1)//isotropy
		{
		dz = zRecv - zSour;
		rp=pKZP[layerRecv];
		exur[0] = dcexp(dcrmul2(rp, dz));
		rp=pKZS[layerRecv];
		exur[1] = dcexp(dcrmul2(rp, dz));
		dz = pZ[layerRecv - 1] - zRecv;
		rp=pKZP[layerRecv];
		exdr[0] = dcexp(dcrmul2(rp, dz));
		rp=pKZS[layerRecv];
		exdr[1] = dcexp(dcrmul2(rp, dz));
		//SH
		rp=pGRudSH[layerRecv - 1];
		rp1=exus[1];
		rp=dcmul2(rp, rp1);
		rp1=exdr[1];

		temp1 = dcmul2(rp1, rp);
		rp= exur[1];rp1=temp1;
		recvSH = dcadd2(rp1,rp);
		rp=recvSH;rp1= sourSH;
		model->ySH = dcmul2(rp,rp1);
		// for curl SH
		temp1 = dcneg(dcmul(pKZS[layerRecv],dcmul(exdr[1], dcmul(pGRudSH[layerRecv - 1], exus[1]))));
		temp2 = dcadd(temp1, dcmul(pKZS[layerRecv],exur[1]));
        model->ySHd = dcmul(temp2,rp1);

		//PSV
		//source_term
		dcmulRD22(pGRudPSV[layerSour - 1], exus, Rud);
		dcmulRD22(pGRduPSV[layerSour], exds, Rdu);
		dcmulLD22(exus, Rud, ExR);
		dcmulLD22(exds, Rdu, ExR2);
		dcmul22(ExR2, ExR, sourPSV);
		dcUnitSub22(sourPSV);
		dcinv22(sourPSV);
		//receiver_term
		dcmulLD22(exdr, Rud, ExR);
		dcmul22(E11, ExR, EExR);
		dcmulRD22(E12, exur, EEx);
		dcadd22(EExR, EEx, recvPSV);
		//Yu=recv_term*sour_term
		dcmul22(recvPSV, sourPSV, model->yPSV);
		////////////////// for curl ///////////////
		dz = zRecv - zSour;
		exur[0] = dcmul(pKZP[layerRecv],dcexp(dcrmul(pKZP[layerRecv], dz)));
		exur[1] = dcmul(pKZS[layerRecv],dcexp(dcrmul(pKZS[layerRecv], dz)));
		dz = pZ[layerRecv - 1] - zRecv;
		exdr[0] = dcneg(dcmul(pKZP[layerRecv],dcexp(dcrmul(pKZP[layerRecv], dz))));
		exdr[1] = dcneg(dcmul(pKZS[layerRecv],dcexp(dcrmul(pKZS[layerRecv], dz))));
		dcmulLD22(exdr, Rud, ExR);
		dcmul22(E11, ExR, EExR);
		dcmulRD22(E12, exur, EEx);
		dcadd22(EExR, EEx, recvPSV);
		dcmul22(recvPSV, sourPSV, model->yPSVd);
		//////////////////////////////////////////
		}
		else//VTI
		{
		dz = zRecv - zSour;

    	exur[0] = dcexp(dcrmul(pKZP[layerRecv], dz));
		exur[1] = dcexp(dcrmul(pKZS[layerRecv], dz));
    	shexur[0]= dcexp(dcrmul(pSHKZS[layerRecv], dz));

		dz = pZ[layerRecv - 1] - zRecv;
		exdr[0] = dcexp(dcrmul(pKZP[layerRecv], dz));
		exdr[1] = dcexp(dcrmul(pKZS[layerRecv], dz));
		shexdr[0] = dcexp(dcrmul(pSHKZS[layerRecv], dz));//Ad
		//SH
		temp1 = dcmul(dcmul(shexdr[0], dcmul(pGRudSH[layerRecv - 1], shexus[0])),SHE[layerSour][0]);
		recvSH = dcadd(temp1, dcmul(shexur[0],SHE[layerSour][1]));
		model->ySH = dcmul(recvSH, sourSH);
		// for curl SH
		temp1 = dcneg(dcmul(dcmul(dcmul(shexdr[0], dcmul(pGRudSH[layerRecv - 1], shexus[0])),SHE[layerSour][0]),pSHKZS[layerRecv]));
		recvSH = dcadd(temp1, dcmul(dcmul(shexur[0],SHE[layerSour][1]),pSHKZS[layerRecv]) );
		model->ySHd= dcmul(recvSH, sourSH);
        //PSV
		//source_term
		dcmulRD22(pGRudPSV[layerSour - 1], exus, Rud);
		
		dcmulRD22(pGRduPSV[layerSour], exds, Rdu);
		
		dcmulLD22(exus, Rud, ExR);
		dcmulLD22(exds, Rdu, ExR2);
		dcmul22(ExR2, ExR, sourPSV);
		
		dcUnitSub22(sourPSV);
		dcinv22(sourPSV);
		//receiver_term
		dcmulLD22(exdr, Rud, ExR);
		dcmul22(E11, ExR, EExR);
		dcmulRD22(E12, exur, EEx);
		dcadd22(EExR, EEx, recvPSV);
	
		//Yu=recv_term*sour_term
		dcmul22(recvPSV, sourPSV, model->yPSV);
		////////////////// for curl ///////////////
		dz = zRecv - zSour;
		exur[0] = dcmul(pKZP[layerRecv],dcexp(dcrmul(pKZP[layerRecv], dz)));
		exur[1] = dcmul(pKZS[layerRecv],dcexp(dcrmul(pKZS[layerRecv], dz)));
		dz = pZ[layerRecv - 1] - zRecv;
		exdr[0] = dcneg(dcmul(pKZP[layerRecv],dcexp(dcrmul(pKZP[layerRecv], dz))));
		exdr[1] = dcneg(dcmul(pKZS[layerRecv],dcexp(dcrmul(pKZS[layerRecv], dz))));
		dcmulLD22(exdr, Rud, ExR);
		dcmul22(E11, ExR, EExR);
		dcmulRD22(E12, exur, EEx);
		dcadd22(EExR, EEx, recvPSV);
		dcmul22(recvPSV, sourPSV, model->yPSVd);
		//////////////////////////////////////////

		}
	}
	else if (layerSour == layerRecv && zRecv > zSour) 
	{
		if (model->media==1)//isotropy
		{
		dz = zSour - zRecv;
		rp=pKZP[layerRecv];
		exdr[0] = dcexp(dcrmul2(rp, dz));
		rp=pKZS[layerRecv];
		exdr[1] = dcexp(dcrmul2(rp, dz));
		dz = zRecv - pZ[layerRecv];
		rp=pKZP[layerRecv];
		exur[0] = dcexp(dcrmul2(rp, dz));
		rp=pKZS[layerRecv];
		exur[1] = dcexp(dcrmul2(rp, dz));
		//SH
		rp=pGRduSH[layerRecv];rp1=exds[1];
		rp=dcmul2(rp, rp1);
		rp1=exur[1];
		temp1 = dcmul2(rp1, rp);
		rp=temp1;rp1=exdr[1];
		recvSH = dcadd2(rp, rp1);
		rp=recvSH;rp1=sourSH;
		model->ySH = dcmul2(rp,rp1);
        // for curl SH
		temp1 = dcmul(pKZS[layerRecv],dcmul(exur[1], dcmul(pGRduSH[layerRecv], exds[1])));
		temp2 = dcadd(temp1, dcneg(dcmul(pKZS[layerRecv],exdr[1])));
        model->ySHd = dcmul(temp2,rp1);


		//PSV
		//source_term
		dcmulRD22(pGRudPSV[layerSour - 1], exus, Rud);
		dcmulRD22(pGRduPSV[layerSour], exds, Rdu);
		dcmulLD22(exus, Rud, ExR);
		dcmulLD22(exds, Rdu, ExR2);
		dcmul22(ExR, ExR2, sourPSV);
		dcUnitSub22(sourPSV);
		dcinv22(sourPSV);
		//receiver_term
		dcmulLD22(exur, Rdu, ExR);
		dcmul22(E12, ExR, EExR);
		dcmulRD22(E11, exdr, EEx);
		dcadd22(EExR, EEx, recvPSV);
		//Yd=recv_term*sour_term
		dcmul22(recvPSV, sourPSV, model->yPSV);
		/////////////// for curl ///////////////////////
		dz = zSour - zRecv;
		exdr[0] = dcneg(dcmul(pKZP[layerRecv],dcexp(dcrmul(pKZP[layerRecv], dz))));
		exdr[1] = dcneg(dcmul(pKZS[layerRecv],dcexp(dcrmul(pKZS[layerRecv], dz))));
		dz = zRecv - pZ[layerRecv];
		exur[0] = dcmul(pKZP[layerRecv],dcexp(dcrmul(pKZP[layerRecv], dz)));
		exur[1] = dcmul(pKZS[layerRecv],dcexp(dcrmul(pKZS[layerRecv], dz)));
		dcmulLD22(exur, Rdu, ExR);
		dcmul22(E12, ExR, EExR);
		dcmulRD22(E11, exdr, EEx);
		dcadd22(EExR, EEx, recvPSV);
		dcmul22(recvPSV, sourPSV, model->yPSVd);
		/////////////////////////////////////////////////
		}
		else//VTI
		{
		dz = zSour - zRecv;
		exdr[0] = dcexp(dcrmul(pKZP[layerRecv], dz));
		exdr[1] = dcexp(dcrmul(pKZS[layerRecv], dz));	
        shexdr[0] = dcexp(dcrmul(pSHKZS[layerRecv], dz));//Ad
		dz = zRecv - pZ[layerRecv];
		exur[0] = dcexp(dcrmul(pKZP[layerRecv], dz));
		exur[1] = dcexp(dcrmul(pKZS[layerRecv], dz));
		shexur[0] = dcexp(dcrmul(pSHKZS[layerRecv], dz)); //Au
		//SH
		temp1 =dcmul(dcmul(shexur[0], dcmul(pGRduSH[layerRecv], shexds[0])),SHE[layerSour][1]);
		recvSH = dcadd(temp1, dcmul(shexdr[0],SHE[layerSour][0]) );
		model->ySH = dcmul(recvSH, sourSH);
		/*printf("%lf\n", model->ySH.r);
		printf("%lf\n", model->ySH.i);
		exit(0);*/
		// for curl SH
		temp1 =dcmul(dcmul(dcmul(shexur[0], dcmul(pGRduSH[layerRecv], shexds[0])),SHE[layerSour][1]),pSHKZS[layerRecv]);
		recvSH = dcadd(temp1, dcneg(dcmul(dcmul(shexdr[0],SHE[layerSour][0]),pSHKZS[layerRecv])) );
		model->ySHd = dcmul(recvSH, sourSH);
		//PSV
		//source_term
		dcmulRD22(pGRudPSV[layerSour - 1], exus, Rud);
		dcmulRD22(pGRduPSV[layerSour], exds, Rdu);
		dcmulLD22(exus, Rud, ExR);
		dcmulLD22(exds, Rdu, ExR2);
		dcmul22(ExR, ExR2, sourPSV);
		dcUnitSub22(sourPSV);
		dcinv22(sourPSV);
		//receiver_term
		dcmulLD22(exur, Rdu, ExR);
		dcmul22(E12, ExR, EExR);
		dcmulRD22(E11, exdr, EEx);
		dcadd22(EExR, EEx, recvPSV);
		//Yd=recv_term*sour_term
		dcmul22(recvPSV, sourPSV, model->yPSV);


		/////////////// for curl ///////////////////////
		dz = zSour - zRecv;
		exdr[0] = dcneg(dcmul(pKZP[layerRecv],dcexp(dcrmul(pKZP[layerRecv], dz))));
		exdr[1] = dcneg(dcmul(pKZS[layerRecv],dcexp(dcrmul(pKZS[layerRecv], dz))));
		dz = zRecv - pZ[layerRecv];
		exur[0] = dcmul(pKZP[layerRecv],dcexp(dcrmul(pKZP[layerRecv], dz)));
		exur[1] = dcmul(pKZS[layerRecv],dcexp(dcrmul(pKZS[layerRecv], dz)));
		dcmulLD22(exur, Rdu, ExR);
		dcmul22(E12, ExR, EExR);
		dcmulRD22(E11, exdr, EEx);
		dcadd22(EExR, EEx, recvPSV);
		dcmul22(recvPSV, sourPSV, model->yPSVd);
		/////////////////////////////////////////////////
		}
	}
	else if (layerRecv < layerSour) 
	{
		if(model->media==1)//isotropy
		{
		dz = zRecv - pZ[layerRecv];
		rp=pKZP[layerRecv];
		exur[0] = dcexp(dcrmul2(rp, dz));
		rp=pKZS[layerRecv];
		exur[1] = dcexp(dcrmul2(rp, dz));
		dz = pZ[layerRecv - 1] - zRecv;
		rp=pKZP[layerRecv];
		exdr[0] = dcexp(dcrmul2(rp, dz));
		rp=pKZS[layerRecv];
		exdr[1] = dcexp(dcrmul2(rp, dz));
		//SH
		rp=pGRudSH[layerRecv - 1];rp1= pEX[layerRecv][1];
		rp=dcmul2(rp,rp1);
		rp1=exdr[1];
		temp1 = dcmul2(rp1, rp);
		rp=temp1;rp1= exur[1];
		recvSH = dcadd2(rp,rp1);
		//transmission_term
		//initialize in layerSour-1
		rp=pGTuuSH[layerSour - 1];rp1=exus[1];
		tranSH = dcmul2(rp, rp1);
		for (lay = layerSour - 2; lay >= layerRecv; lay--) 
		{
			rp=pGTuuSH[lay];rp1=pEX[lay + 1][1];
			rp=dcmul2(rp, rp1);rp1=tranSH;
			tranSH = dcmul2(rp1, rp);
		}
		rp=tranSH;rp1=sourSH;
		rp=dcmul2(rp, rp1);
		rp1=recvSH;
		model->ySH = dcmul2(rp1, rp);
		//////////// for curl ////////////////////////
		temp1 = dcneg(dcmul(pKZS[layerRecv],dcmul(exdr[1], dcmul(pGRudSH[layerRecv - 1], pEX[layerRecv][1]))));
		recvSH = dcadd(temp1, dcmul(pKZS[layerRecv],exur[1]));
		model->ySHd = dcmul(recvSH, rp);
		//////////////////////////////////////////////
		//PSV
		//source_term
		dcmulRD22(pGRudPSV[layerSour - 1], exus, Rud);
		dcmulRD22(pGRduPSV[layerSour], exds, Rdu);
		dcmulLD22(exus, Rud, ExR);
		dcmulLD22(exds, Rdu, ExR2);
		dcmul22(ExR2, ExR, sourPSV);
		dcUnitSub22(sourPSV);
		dcinv22(sourPSV);
		//receiver_term
		dcmulRD22(pGRudPSV[layerRecv - 1], pEX[layerRecv], Rud);
		dcmulLD22(exdr, Rud, ExR);
		dcmul22(E11, ExR, EExR);
		dcmulRD22(E12, exur, EEx);
		dcadd22(EExR, EEx, recvPSV);
		//transmission_term
		//initialize in layerSour-1
		dcmulRD22(pGTuuPSV[layerSour - 1], exus, tranPSV);
		for (lay = layerSour - 2; lay >= layerRecv; lay--) {
			dcmulRD22(pGTuuPSV[lay], pEX[lay + 1], Ytemp1);
			dcmul22(Ytemp1, tranPSV, Ytemp2);
			dcassign22(Ytemp2, tranPSV);
		}
		//Yu=recv_term*trans_term*sour_term
		dcmul22(tranPSV, sourPSV, Ytemp1);
		dcmul22(recvPSV, Ytemp1, model->yPSV);
		//////////////// for curl ////////////////////////
		//receiver_term
		dz = zRecv - pZ[layerRecv];
		exur[0] = dcmul(pKZP[layerRecv],dcexp(dcrmul(pKZP[layerRecv], dz)));
		exur[1] = dcmul(pKZS[layerRecv],dcexp(dcrmul(pKZS[layerRecv], dz)));
		dz = pZ[layerRecv - 1] - zRecv;
		exdr[0] = dcneg(dcmul(pKZP[layerRecv],dcexp(dcrmul(pKZP[layerRecv], dz))));
		exdr[1] = dcneg(dcmul(pKZS[layerRecv],dcexp(dcrmul(pKZS[layerRecv], dz))));
		dcmulRD22(pGRudPSV[layerRecv - 1], pEX[layerRecv], Rud);
		dcmulLD22(exdr, Rud, ExR);
		dcmul22(E11, ExR, EExR);
		dcmulRD22(E12, exur, EEx);
		dcadd22(EExR, EEx, recvPSV);
		dcmul22(tranPSV, sourPSV, Ytemp1);
		dcmul22(recvPSV, Ytemp1, model->yPSVd);
		//////////////////////////////////////////////////
		//printf("%lf %lf\n",model->yPSV[1].r,model->yPSV[1].i);
		//exit(0);
		}
		else//VTI
		{
		dz = zRecv - pZ[layerRecv];
		exur[0] = dcexp(dcrmul(pKZP[layerRecv], dz));
		exur[1] = dcexp(dcrmul(pKZS[layerRecv], dz));
   		shexur[0] = dcexp(dcrmul(pSHKZS[layerRecv], dz));

		dz = pZ[layerRecv - 1] - zRecv;
		exdr[0] = dcexp(dcrmul(pKZP[layerRecv], dz));
		exdr[1] = dcexp(dcrmul(pKZS[layerRecv], dz));
		shexdr[0] = dcexp(dcrmul(pSHKZS[layerRecv], dz));

	    temp1 = dcmul(dcmul(shexdr[0], dcmul(pGRudSH[layerRecv - 1], pIEX[layerRecv][0])),SHE[layerRecv][0]);
		recvSH = dcadd(temp1,dcmul(shexur[0],SHE[layerRecv][1]));
		//transmission_term
		//initialize in layerSour-1
		tranSH = dcmul(pGTuuSH[layerSour - 1], shexus[0]);
		for (lay = layerSour - 2; lay >= layerRecv; lay--) {
			tranSH = dcmul(tranSH, dcmul(pGTuuSH[lay], pIEX[lay + 1][0]));
		}
		model->ySH = dcmul(recvSH, dcmul(tranSH, sourSH));
		//////////// for curl ////////////////////////
	    temp1 = dcneg(dcmul(dcmul(dcmul(shexdr[0], dcmul(pGRudSH[layerRecv - 1], pIEX[layerRecv][0])),SHE[layerRecv][0]),pSHKZS[layerRecv]));
		recvSH = dcadd(temp1,dcmul(dcmul(shexur[0],SHE[layerRecv][1]),pSHKZS[layerRecv]) );
		model->ySHd = dcmul(recvSH, dcmul(tranSH, sourSH));
		//PSV
		//source_term
		dcmulRD22(pGRudPSV[layerSour - 1], exus, Rud);
		dcmulRD22(pGRduPSV[layerSour], exds, Rdu);
		dcmulLD22(exus, Rud, ExR);
		dcmulLD22(exds, Rdu, ExR2);
		dcmul22(ExR2, ExR, sourPSV);
		dcUnitSub22(sourPSV);
		dcinv22(sourPSV);
		//receiver_term
		dcmulRD22(pGRudPSV[layerRecv - 1], pEX[layerRecv], Rud);
		dcmulLD22(exdr, Rud, ExR);
		dcmul22(E11, ExR, EExR);
		dcmulRD22(E12, exur, EEx);
		dcadd22(EExR, EEx, recvPSV);
		//transmission_term
		//initialize in layerSour-1
		dcmulRD22(pGTuuPSV[layerSour - 1], exus, tranPSV);
		for (lay = layerSour - 2; lay >= layerRecv; lay--) {
			dcmulRD22(pGTuuPSV[lay], pEX[lay + 1], Ytemp1);
			dcmul22(Ytemp1, tranPSV, Ytemp2);
			dcassign22(Ytemp2, tranPSV);
		}
		//Yu=recv_term*trans_term*sour_term
		dcmul22(tranPSV, sourPSV, Ytemp1);
		dcmul22(recvPSV, Ytemp1, model->yPSV);
		//////////////// for curl ////////////////////////
		//receiver_term
		dz = zRecv - pZ[layerRecv];
		exur[0] = dcmul(pKZP[layerRecv],dcexp(dcrmul(pKZP[layerRecv], dz)));
		exur[1] = dcmul(pKZS[layerRecv],dcexp(dcrmul(pKZS[layerRecv], dz)));
		dz = pZ[layerRecv - 1] - zRecv;
		exdr[0] = dcneg(dcmul(pKZP[layerRecv],dcexp(dcrmul(pKZP[layerRecv], dz))));
		exdr[1] = dcneg(dcmul(pKZS[layerRecv],dcexp(dcrmul(pKZS[layerRecv], dz))));
		dcmulRD22(pGRudPSV[layerRecv - 1], pEX[layerRecv], Rud);
		dcmulLD22(exdr, Rud, ExR);
		dcmul22(E11, ExR, EExR);
		dcmulRD22(E12, exur, EEx);
		dcadd22(EExR, EEx, recvPSV);
		dcmul22(tranPSV, sourPSV, Ytemp1);
		dcmul22(recvPSV, Ytemp1, model->yPSVd);
		//////////////////////////////////////////////////

		}
	}
	else if (layerRecv > layerSour) 
	{
		if(model->media==1)//isotropy
		{
		dz = zRecv - pZ[layerRecv];
		rp=pKZP[layerRecv];
		exur[0] = dcexp(dcrmul2(rp, dz));
		rp=pKZS[layerRecv];
		exur[1] = dcexp(dcrmul2(rp, dz));
		dz = pZ[layerRecv - 1] - zRecv;
		rp=pKZP[layerRecv];
		exdr[0] = dcexp(dcrmul2(rp, dz));
		rp=pKZS[layerRecv];
		exdr[1] = dcexp(dcrmul2(rp, dz));
		//SH
		rp=pGRduSH[layerRecv];rp1=pEX[layerRecv][1];
		rp=dcmul2(rp, rp1);
		rp1=exur[1];
		temp1 = dcmul2(rp1, rp);
		rp=exdr[1];rp1=temp1;
		recvSH = dcadd2(rp1, rp);
		rp=pGTddSH[layerSour];
		rp1=exds[1];
		tranSH = dcmul2(rp, rp1);
		for (lay = layerSour + 1; lay <= layerRecv - 1; lay++) {
			rp=pEX[lay][1];rp1=pGTddSH[lay];
			rp=dcmul2(rp1, rp);
			rp1=tranSH;
			tranSH = dcmul2(rp1, rp);
		}
		rp=tranSH;rp1=sourSH;
		rp=dcmul2(rp, rp1);
		rp1=recvSH;
		model->ySH = dcmul2(rp1, rp);
		//////////////// for curl ///////////////
		temp1 = dcmul(pKZS[layerRecv],dcmul(exur[1], dcmul(pGRduSH[layerRecv], pEX[layerRecv][1])));
		recvSH = dcadd(temp1, dcneg(dcmul(pKZS[layerRecv],exdr[1])));
		model->ySHd = dcmul(recvSH, rp);
		/////////////////////////////////////////
		//PSV
		//source_term
		dcmulRD22(pGRudPSV[layerSour - 1], exus, Rud);
		dcmulRD22(pGRduPSV[layerSour], exds, Rdu);
		dcmulLD22(exus, Rud, ExR);
		dcmulLD22(exds, Rdu, ExR2);
		dcmul22(ExR, ExR2, sourPSV);
		dcUnitSub22(sourPSV);
		dcinv22(sourPSV);
		//receiver_term
		dcmulRD22(pGRduPSV[layerRecv], pEX[layerRecv], Rdu);
		dcmulLD22(exur, Rdu, ExR);
		dcmul22(E12, ExR, EExR);
		dcmulRD22(E11, exdr, EEx);
		dcadd22(EExR, EEx, recvPSV);
		//transmission_term
		//initialize in layerSour
		dcmulRD22(pGTddPSV[layerSour], exds, tranPSV);
		for (lay = layerSour + 1; lay <= layerRecv - 1; lay++) {
			dcmulRD22(pGTddPSV[lay], pEX[lay], Ytemp1);
			dcmul22(Ytemp1, tranPSV, Ytemp2);
			dcassign22(Ytemp2, tranPSV);
		}
		//Yd=recv_term*trans_term*sour_term
		dcmul22(tranPSV, sourPSV, Ytemp1);
		dcmul22(recvPSV, Ytemp1, model->yPSV);
		////////////// for curl ///////////////////////////////
		//receiver_term
		dz = zRecv - pZ[layerRecv];
		exur[0] = dcmul(pKZP[layerRecv],dcexp(dcrmul(pKZP[layerRecv], dz)));
		exur[1] = dcmul(pKZS[layerRecv],dcexp(dcrmul(pKZS[layerRecv], dz)));
		dz = pZ[layerRecv - 1] - zRecv;
		exdr[0] = dcneg(dcmul(pKZP[layerRecv],dcexp(dcrmul(pKZP[layerRecv], dz))));
		exdr[1] = dcneg(dcmul(pKZS[layerRecv],dcexp(dcrmul(pKZS[layerRecv], dz))));
		dcmulRD22(pGRduPSV[layerRecv], pEX[layerRecv], Rdu);
		dcmulLD22(exur, Rdu, ExR);
		dcmul22(E12, ExR, EExR);
		dcmulRD22(E11, exdr, EEx);
		dcadd22(EExR, EEx, recvPSV);
		dcmul22(tranPSV, sourPSV, Ytemp1);
		dcmul22(recvPSV, Ytemp1, model->yPSVd);
		///////////////////////////////////////////////////////
		}
		else//VTI
		{
		dz = zRecv - pZ[layerRecv];
		exur[0] = dcexp(dcrmul(pKZP[layerRecv], dz));
		exur[1] = dcexp(dcrmul(pKZS[layerRecv], dz));
  	    shexur[0] = dcexp(dcrmul(pSHKZS[layerRecv], dz));

		dz = pZ[layerRecv - 1] - zRecv;
		exdr[0] = dcexp(dcrmul(pKZP[layerRecv], dz));
		exdr[1] = dcexp(dcrmul(pKZS[layerRecv], dz));
		shexdr[0] = dcexp(dcrmul(pSHKZS[layerRecv], dz));
		//SH
		temp1 =dcmul(dcmul(shexur[0], dcmul(pGRduSH[layerRecv], pIEX[layerRecv][0])),SHE[layerRecv][1]);
		recvSH = dcadd(temp1, dcmul(shexdr[0], SHE[layerRecv][0]));
		tranSH = dcmul(pGTddSH[layerSour], shexds[0]);
		for (lay = layerSour + 1; lay <= layerRecv - 1; lay++) {
			tranSH = dcmul(tranSH, dcmul(pGTddSH[lay], pIEX[lay][0]));
		}
		model->ySH = dcmul(recvSH, dcmul(tranSH, sourSH));
		//////////// for curl ////////////////////////
		temp1 =dcmul(dcmul(dcmul(shexur[0], dcmul(pGRduSH[layerRecv], pIEX[layerRecv][0])),SHE[layerRecv][1]),pSHKZS[layerRecv]);
		recvSH = dcadd(temp1, dcneg(dcmul(dcmul(shexdr[0], SHE[layerRecv][0]),pSHKZS[layerRecv])) );
		model->ySHd = dcmul(recvSH, dcmul(tranSH, sourSH));
		//PSV
		//source_term
		dcmulRD22(pGRudPSV[layerSour - 1], exus, Rud);
		dcmulRD22(pGRduPSV[layerSour], exds, Rdu);
		dcmulLD22(exus, Rud, ExR);
		dcmulLD22(exds, Rdu, ExR2);
		dcmul22(ExR, ExR2, sourPSV);
		dcUnitSub22(sourPSV);
		dcinv22(sourPSV);
		//receiver_term
		dcmulRD22(pGRduPSV[layerRecv], pEX[layerRecv], Rdu);
		dcmulLD22(exur, Rdu, ExR);
		dcmul22(E12, ExR, EExR);
		dcmulRD22(E11, exdr, EEx);
		dcadd22(EExR, EEx, recvPSV);
		//transmission_term
		//initialize in layerSour
		dcmulRD22(pGTddPSV[layerSour], exds, tranPSV);
		for (lay = layerSour + 1; lay <= layerRecv - 1; lay++) {
			dcmulRD22(pGTddPSV[lay], pEX[lay], Ytemp1);
			dcmul22(Ytemp1, tranPSV, Ytemp2);
			dcassign22(Ytemp2, tranPSV);
		}
		//Yd=recv_term*trans_term*sour_term
		dcmul22(tranPSV, sourPSV, Ytemp1);
		dcmul22(recvPSV, Ytemp1, model->yPSV);
		////////////// for curl ///////////////////////////////
		//receiver_term
		dz = zRecv - pZ[layerRecv];
		exur[0] = dcmul(pKZP[layerRecv],dcexp(dcrmul(pKZP[layerRecv], dz)));
		exur[1] = dcmul(pKZS[layerRecv],dcexp(dcrmul(pKZS[layerRecv], dz)));
		dz = pZ[layerRecv - 1] - zRecv;
		exdr[0] = dcneg(dcmul(pKZP[layerRecv],dcexp(dcrmul(pKZP[layerRecv], dz))));
		exdr[1] = dcneg(dcmul(pKZS[layerRecv],dcexp(dcrmul(pKZS[layerRecv], dz))));
		dcmulRD22(pGRduPSV[layerRecv], pEX[layerRecv], Rdu);
		dcmulLD22(exur, Rdu, ExR);
		dcmul22(E12, ExR, EExR);
		dcmulRD22(E11, exdr, EEx);
		dcadd22(EExR, EEx, recvPSV);
		dcmul22(tranPSV, sourPSV, Ytemp1);
		dcmul22(recvPSV, Ytemp1, model->yPSVd);
		///////////////////////////////////////////////////////
		}
	}
}
