#pragma once

#include "model.h"

void calc_GRT(FKRTmodel *model, int layerSour);