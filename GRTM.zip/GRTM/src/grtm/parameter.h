#pragma once

void input_calculation_parameters(const char *parafile,
	double *Twin, double *dt, double *coef, double *fc,
	char *Type_STF, double *tou, double *fpeak,
	double *fmin, double *fmax, char *PeriodCheck,
	char *modefile, char *sourfile, char *recvfile, char *prefix_output,char *outputdata,char *outdirectory,char *outputdata1,int *mediatype);

void set_calculation_parameters(double Twin, double dt, double coef, double fmin, double fmax, 
	int *nt, int *nfft, int *nfreq, int *nfreqBeg, int *nfreqEnd, double *df, double *iomega,double fc,char* Type_STF);
