#include "green_spectra.h"
#include "model.h"
#include "source_and_receiver.h"
#include "dwim.h"
#include "integral_function_coeff.h"
#include "periodic_convergence.h"
#include <math.h>
#include <stdio.h>
//Green function of one pair(source, receiver)
void green_spectra_E(FKRTmodel *model, double df, int nfreqBeg, int nfreqEnd,
	double iomega, double freq_reference, double dk,
	const SourPara *source, const RecvStat *recvstat,
	dcomplex *ur, dcomplex *ut, dcomplex *uz, char *PeriodCheck)
{
	//source and receiver information
	double r0, zSour, zRecv;
	int layerSour, layerRecv;
	//radiaction pattern
	//RadPat=diag{1,1,1};
	//f-k
	double kmin, kcritical, kn, freq, dk_2;
	//for periodic convergence
	int counter, flagSearchCycle[12], numCycle[12];
	int convergence;
	double condition;
	int flagZero[3];
	//bessel and integral
	double j0, j1, j0d, j1d;
	dcomplex fun[2];
	dcomplex tmpU[3], sumU[3];
	dcomplex integterm_last[3];
	dcomplex integterm_new[3];
	//temporary
	int i, ifreq;
	dcomplex dctemp, dctemp2;

	r0 = recvstat->distance;
	zSour = source->depth;
	zRecv = recvstat->depth;
	layerSour = source->layer;
	layerRecv = recvstat->layer;
	//source radiation pattern
	flagZero[0] = 1;
	flagZero[1] = 0;
	flagZero[2] = 1;
	//calculation start...
	for (ifreq = nfreqBeg; ifreq <= nfreqEnd; ifreq++) {
		//printf("ifreq: %d\n", ifreq);
		freq = ifreq*df;
		set_complex_frequency_variables(model, freq, iomega, freq_reference);

		dctemp = dcmplx(PI2*df*3., -iomega);
		kcritical = get_critical_k(model, dctemp, ifreq, layerSour, layerRecv, zSour, zRecv);

		//discrete wavenumber integration
		DWIM_E(model, 0., kcritical, dk,
			layerSour, layerRecv, zSour, zRecv, r0, sumU, integterm_last);

		if (!strcmp(PeriodCheck, "ON")) {
			//convergence judge
			condition = CONVERGENCE_THRESH;
			convergence = 0; //0-convergence, 1-nonconvergence
			for (i = 0; i < 2; i++) {
				if (drcabs(model->qPSV0[i]) > condition) convergence = 1;
				if (drcabs(model->qPSV2[i]) > condition) convergence = 1;
			}
			//periodic_convergence integration calculation
			kn = kcritical;
			dk_2 = dk / 2.;
			counter = 0;
			for (i = 0; i < 12; i++) {
				numCycle[i] = 0;
				flagSearchCycle[i] = 1;
			}
			//while (0) {
				while (convergence != 0 && counter <MAXCYCLECHECKTIME) {
				//while (convergence != 0) {
				kn = kn + dk;
				//integral_function_coeff_E(kn, model, layerSour, layerRecv, zSour, zRecv, fun);
				integral_function_coeff_E0(kn, model, layerSour, layerRecv, zSour, zRecv, fun);
				j0 = BesselJ0(r0*kn);
				j0d = -BesselJ1(r0*kn);
				integration_E(integterm_new, fun, j0, j0d);
				for (i = 0; i < 3; i++) {
					sumU[i] = dcadd(sumU[i], dcrmul(dcadd(integterm_last[i], integterm_new[i]), dk_2));
					integterm_last[i] = integterm_new[i];
				}
				periodic_convergence(kn, sumU, flagZero, &convergence, &counter, numCycle, flagSearchCycle);
			}
		}
		ur[ifreq] = sumU[0];
		ut[ifreq] = sumU[1];
		uz[ifreq] = sumU[2];
	}
}
