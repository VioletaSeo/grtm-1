#include "dcsimpleblas.h"
#include <math.h>
#include <errno.h>
#include <stdlib.h>
 void dcassign22(const dcomplex a[4], dcomplex b[4])
{
	b[0] = a[0];
	b[1] = a[1];
	b[2] = a[2];
	b[3] = a[3];
}

 void dcneg22(dcomplex a[4])
{
	for(int i=0;i<4;i++)
	{
		dcomplex rp=a[i];
        a[i] = dcneg2(rp);
	}
	/*a[0] = dcneg(a[0]);
	a[1] = dcneg(a[1]);
	a[2] = dcneg(a[2]);
	a[3] = dcneg(a[3]);*/
}

 void dcnegOther22(const dcomplex a[4], dcomplex b[4])
{
	for(int i=0;i<4;i++)
	{
		dcomplex rp=a[i];
		b[i] = dcneg2(rp);
	}
	/*b[0] = dcneg(a[0]);
	b[1] = dcneg(a[1]);
	b[2] = dcneg(a[2]);
	b[3] = dcneg(a[3]);*/
}

 void dcadd22(const dcomplex a[4], const dcomplex b[4], dcomplex apb[4])
{
	dcomplex rp,rp1;
    for(int i=0;i<4;i++)
    {
    	rp=a[i];
    	rp1=b[i];
	  apb[i] = dcadd2(rp,rp1);
    }
    /*apb[0] = dcadd(a[0],b[0]);
	apb[1] = dcadd(a[1], b[1]);
	apb[2] = dcadd(a[2], b[2]);
	apb[3] = dcadd(a[3], b[3]);*/
}

 void dcsubd22(const dcomplex a[4], const dcomplex b[4], dcomplex amb[4])
{
	for(int i=0;i<4;i++)
	{
		dcomplex rp=a[i],rp1=b[i];
		amb[i]=dcsub2(rp,rp1);
	}
	/*amb[0] = dcsub(a[0], b[0]);
	amb[1] = dcsub(a[1], b[1]);
	amb[2] = dcsub(a[2], b[2]);
	amb[3] = dcsub(a[3], b[3]);*/
}

 void dcUnitSub22(dcomplex a[2][2])
{
	dcomplex rp=a[0][0];
	a[0][0] = drcsub2(1.0,rp);
	rp=a[0][1];
	a[0][1] = dcneg2(rp);
	rp=a[1][0];
	a[1][0] = dcneg2(rp);
	rp=a[1][1];
	a[1][1] = drcsub2(1.0, rp);
}

 void dcSubUnit22(dcomplex a[2][2])
{
	for(int i=0;i<2;i++)
	{
		dcomplex rp=a[i][i];
        a[i][i] = dcradd2(rp, -1.0);
	}
	/*a[0][0] = dcradd(a[0][0], -1.0);
	a[1][1] = dcradd(a[1][1], -1.0);*/
}

 void dcUnitAdd22(dcomplex a[2][2])
{
	for(int i=0;i<2;i++)
	{
		dcomplex rp=a[i][i];
        a[i][i] = dcradd2(rp, 1.0);
	}
	/*a[0][0] = dcradd(a[0][0], 1.0);
	a[1][1] = dcradd(a[1][1], 1.0);*/
}

 void dcUnitSubOther22(const dcomplex a[2][2], dcomplex b[2][2])
{
	dcomplex rp=a[0][0];
	b[0][0] = drcsub2(1.0, rp);
	rp=a[0][1];
	b[0][1] = dcneg2(rp);
	rp=a[1][0];
	b[1][0] = dcneg2(rp);
	rp=a[1][1];
	b[1][1] = drcsub2(1.0, rp);
}

 void dcSubUnitOther22(const dcomplex a[2][2], dcomplex b[2][2])
{
	for(int i=0;i<2;i++)
	{
		dcomplex rp=a[i][i];
		b[i][i]=dcradd2(rp,-1.0);
	}
	b[0][1] = a[0][1];
	b[1][0] = a[1][0];
	/*b[0][0] = dcradd(a[0][0], -1.0);
	b[0][1] = a[0][1];
	b[1][0] = a[1][0];
	b[1][1] = dcradd(a[1][1], -1.0);*/
}

 void dcUnitAddOther22(const dcomplex a[2][2], dcomplex b[2][2])
{
	for(int i=0;i<2;i++)
	{
		dcomplex rp=a[i][i];
		b[i][i]=dcradd2(rp,1.0);
	}
	b[0][1] = a[0][1];
	b[1][0] = a[1][0];
	/*b[0][0] = dcradd(a[0][0], 1.0);
	b[0][1] = a[0][1];
	b[1][0] = a[1][0];
	b[1][1] = dcradd(a[1][1], 1.0);*/
}

 void dcmulLD22(const dcomplex diag[2], const dcomplex a[2][2], dcomplex b[2][2])
{
	dcomplex rp;
	b[0][0] = dcmul2(a[0][0], diag[0]);
	b[0][1] = dcmul2(a[0][1], diag[0]);
	b[1][0] = dcmul2(a[1][0], diag[1]);
	b[1][1] = dcmul2(a[1][1], diag[1]);
}

void dcmulRD22(const dcomplex a[2][2], const dcomplex diag[2], dcomplex b[2][2])
{
	dcomplex rp;
	b[0][0] = dcmul2(a[0][0], diag[0]);
	b[0][1] = dcmul2(a[0][1], diag[1]);
	b[1][0] = dcmul2(a[1][0], diag[0]);
	b[1][1] = dcmul2(a[1][1], diag[1]);
}

void dcmul22(const dcomplex a[2][2], const dcomplex b[2][2], dcomplex ab[2][2])
{
	
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			dcomplex rp=a[i][0],rp1=a[i][1],rp2=b[0][j],rp3=b[1][j];
			rp=dcmul2(rp,rp2);rp2=dcmul2(rp1,rp3);
			ab[i][j]=dcadd2(rp,rp2);
		}
		
	}
	/*ab[0][0] = dcadd(dcmul2(a[0][0], b[0][0]), dcmul2(a[0][1], b[1][0]));
	ab[0][1] = dcadd(dcmul2(a[0][0], b[0][1]), dcmul2(a[0][1], b[1][1]));
	ab[1][0] = dcadd(dcmul2(a[1][0], b[0][0]), dcmul2(a[1][1], b[1][0]));
	ab[1][1] = dcadd(dcmul2(a[1][0], b[0][1]), dcmul2(a[1][1], b[1][1]));*/
	return;
}
 void dcmul44(const dcomplex a[4][4], const dcomplex b[4][4], dcomplex ab[4][4])
{
	int i, j, k;
	dcomplex rp,rp1;
	for (i = 0; i < 4; i++) {
		for (j = 0; j < 4; j++) {
			ab[i][j] = dcmplx2(0., 0.);
			for (k = 0; k < 4; k++) {
				rp=dcmul2(a[i][k], b[k][j]);
				ab[i][j] = dcadd2(ab[i][j],rp);
			}
		}
	}
	//Tang Le 2019 11.28 20:30
	/*ab[0][0]=dcadd(dcadd(dcmul(a[0][0],b[0][0]),dcmul(a[0][1],b[1][0])),dcadd(dcmul(a[0][2],b[2][0]),dcmul(a[0][3],b[3][0]))) ;
	ab[0][1]=dcadd(dcadd(dcmul(a[0][0],b[0][1]),dcmul(a[0][1],b[1][1])),dcadd(dcmul(a[0][2],b[2][1]),dcmul(a[0][3],b[3][1]))) ;
	ab[0][2]=dcadd(dcadd(dcmul(a[0][0],b[0][2]),dcmul(a[0][1],b[1][2])),dcadd(dcmul(a[0][2],b[2][2]),dcmul(a[0][3],b[3][2]))) ;
	ab[0][3]=dcadd(dcadd(dcmul(a[0][0],b[0][3]),dcmul(a[0][1],b[1][3])),dcadd(dcmul(a[0][2],b[2][3]),dcmul(a[0][3],b[3][3]))) ;
	ab[1][0]=dcadd(dcadd(dcmul(a[1][0],b[0][0]),dcmul(a[1][1],b[1][0])),dcadd(dcmul(a[1][2],b[2][0]),dcmul(a[1][3],b[3][0]))) ;
	ab[1][1]=dcadd(dcadd(dcmul(a[1][0],b[0][1]),dcmul(a[1][1],b[1][1])),dcadd(dcmul(a[1][2],b[2][1]),dcmul(a[1][3],b[3][1]))) ;
	ab[1][2]=dcadd(dcadd(dcmul(a[1][0],b[0][2]),dcmul(a[1][1],b[1][2])),dcadd(dcmul(a[1][2],b[2][2]),dcmul(a[1][3],b[3][2]))) ;
	ab[1][3]=dcadd(dcadd(dcmul(a[1][0],b[0][3]),dcmul(a[1][1],b[1][3])),dcadd(dcmul(a[1][2],b[2][3]),dcmul(a[1][3],b[3][3]))) ;
	ab[2][0]=dcadd(dcadd(dcmul(a[2][0],b[0][0]),dcmul(a[2][1],b[1][0])),dcadd(dcmul(a[2][2],b[2][0]),dcmul(a[2][3],b[3][0]))) ;
	ab[2][1]=dcadd(dcadd(dcmul(a[2][0],b[0][1]),dcmul(a[2][1],b[1][1])),dcadd(dcmul(a[2][2],b[2][1]),dcmul(a[2][3],b[3][1]))) ;
	ab[2][2]=dcadd(dcadd(dcmul(a[2][0],b[0][2]),dcmul(a[2][1],b[1][2])),dcadd(dcmul(a[2][2],b[2][2]),dcmul(a[2][3],b[3][2]))) ;
	ab[2][3]=dcadd(dcadd(dcmul(a[2][0],b[0][3]),dcmul(a[2][1],b[1][3])),dcadd(dcmul(a[2][2],b[2][3]),dcmul(a[2][3],b[3][3]))) ;
	ab[3][0]=dcadd(dcadd(dcmul(a[3][0],b[0][0]),dcmul(a[3][1],b[1][0])),dcadd(dcmul(a[3][2],b[2][0]),dcmul(a[3][3],b[3][0]))) ;
	ab[3][1]=dcadd(dcadd(dcmul(a[3][0],b[0][1]),dcmul(a[3][1],b[1][1])),dcadd(dcmul(a[3][2],b[2][1]),dcmul(a[3][3],b[3][1]))) ;
	ab[3][2]=dcadd(dcadd(dcmul(a[3][0],b[0][2]),dcmul(a[3][1],b[1][2])),dcadd(dcmul(a[3][2],b[2][2]),dcmul(a[3][3],b[3][2]))) ;
	ab[3][3]=dcadd(dcadd(dcmul(a[3][0],b[0][3]),dcmul(a[3][1],b[1][3])),dcadd(dcmul(a[3][2],b[2][3]),dcmul(a[3][3],b[3][3]))) ;*/
	
	return;
}

#define EPSI 1.0e-10
void dcinv22(dcomplex a[2][2])
{
	const double epsi = 1.0e-20;
	dcomplex determ, tmp,rp,rp1;
	rp=dcmul2(a[0][0], a[1][1]);
	rp1=dcmul2(a[0][1], a[1][0]);
	determ = dcsub2(rp,rp1);
	if (drcabs(determ) < epsi) {
		perror("ERROR: Sigular Matrix!");
		determ = dcmplx(epsi, 0.);
	}
	tmp = a[0][0];
	a[0][0] = dcdiv2(a[1][1], determ);
	a[1][1] = dcdiv2(tmp, determ);
	rp=dcdiv2(a[0][1], determ);
	a[0][1] = dcneg2(rp);
	rp=dcdiv(a[1][0], determ);
	a[1][0] = dcneg2(rp);
	return;
}

void dcinv44(dcomplex a[4][4])
{
	const double epsi = 1.0e-10;
	int l[4], m[4];
	double maxval;
	double dtmp;
	dcomplex ctmp;
	int i, j, k;
	dcomplex rp;

	///////////////////////
	for (k = 0; k < 4; k++) {
		maxval = 0.;
		for (i = k; i < 4; i++) {
			for (j = k; j < 4; j++) {
				dtmp = drcabs2(a[i][j]);
				if (dtmp > maxval) {
					maxval = dtmp;
					l[k] = i;
					m[k] = j;
				}
			}
		}
		if (maxval < epsi) {
			perror("ERROR: Sigular Matrix!");
			//exit(EXIT_FAILURE);
		}
		if (l[k] != k) {
			for (j = 0; j < 4; j++) {
				ctmp = a[k][j];
				a[k][j] = a[l[k]][j];
				a[l[k]][j] = ctmp;
			}
		}
		if (m[k] != k) {
			for (i = 0; i < 4; i++) {
				ctmp = a[i][k];
				a[i][k] = a[i][m[k]];
				a[i][m[k]] = ctmp;
			}
		}
		a[k][k] = dcinv2(a[k][k]);
		for (i = 0; i < 4; i++) {
                rp=dcmul2(a[k][k], a[i][k]);
			if (i != k) a[i][k] = dcneg2(rp);
		}
		for (i = 0; i < 4; i++) {
			for (j = 0; j < 4; j++) {
				rp=dcmul2(a[i][k], a[k][j]);
				if (i != k && j != k) a[i][j] = dcadd2(a[i][j],rp);
			}
		}
		for (j = 0; j < 4; j++) {
			if (j != k) a[k][j] = dcmul2(a[k][j], a[k][k]);
		}
	} //loop k

	for (k = 3; k >= 0; k--){
		for (j = 0; j < 4; j++) {
			ctmp = a[k][j];
			a[k][j] = a[m[k]][j];
			a[m[k]][j] = ctmp;
		}
		for (i = 0; i < 4; i++) {
			ctmp = a[i][k];
			a[i][k] = a[i][l[k]];
			a[i][l[k]] = ctmp;
		}
	}
	return;
}
