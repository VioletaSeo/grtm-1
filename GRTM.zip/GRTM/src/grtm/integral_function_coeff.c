#include "integral_function_coeff.h"
#include "dcsimpleblas.h"
#include "source_and_receiver.h"
#include "calc_grt.h"
#include "calc_y.h"
#include "calc_q.h"
#include <time.h>

void integral_function_coeff_D(double k, FKRTmodel *model, const RadPat_D *radpat, 
	const int layerSour, const int layerRecv,
	const double zSour, const double zRecv,
	dcomplex fun_coeff[12],dcomplex fun_coeffd[32])
{

    int i;
    for (i = 0; i < 32; i++) {
		fun_coeffd[i] = dcmplx2(0., 0.);
	}
     dcomplex rp,rp1,rp2;
     double rrp,rrp1;
	//set the wavenumber-related variable
	set_wavenumber_variables(model, k);
	//calculate the wave propagation
	calc_GRT(model, layerSour);
	calc_Y(model, layerSour, layerRecv, zSour, zRecv);
	calc_q_D(model, layerSour, zSour, zRecv);

	/*printf("%lf %lf\n",model->ySH.r,model->ySH.i);
	
	printf("%lf %lf\n",model->yPSV[0].r,model->yPSV[0].i);
	printf("%lf %lf\n",model->yPSV[1].r,model->yPSV[1].i);
	printf("%lf %lf\n",model->yPSV[2].r,model->yPSV[2].i);
	printf("%lf %lf\n",model->yPSV[3].r,model->yPSV[3].i);
	exit(0);*/
	/*printf("%lf %lf\n",model->qSH1.r,model->qSH1.i);
	printf("%lf %lf\n",model->qSH2.r,model->qSH2.i);
	printf("%lf %lf\n",model->qPSV2[0].r,model->qPSV2[0].i);
	printf("%lf %lf\n",model->qPSV2[1].r,model->qPSV2[1].i);//
	printf("%lf %lf\n",model->qPSV1[0].r,model->qPSV1[0].i);//
	printf("%lf %lf\n",model->qPSV1[1].r,model->qPSV1[1].i);
	printf("%lf %lf\n",model->qPSV0[0].r,model->qPSV0[0].i);
	printf("%lf %lf\n",model->qPSV0[1].r,model->qPSV0[1].i);//
	exit(0);*/
	
	//caculate the coeffient of the interal functions
	//for Ur: fun[0]-[4]
	rp=model->qSH1;rrp=-k*radpat->rpsv1;
	fun_coeff[0] = dcrmul2(rp, rrp);
	
	//modified according to Tang Le, for M and D
	rp=model->qPSV2[0];rrp=-k*radpat->rpsv01;
	rp=dcrmul2(rp, rrp);
	rp1=model->qPSV0[0];rrp= k*radpat->rpsv02;
	rp1=dcrmul2(rp1,rrp);
	fun_coeff[1] = dcadd2(rp, rp1);
	rp=model->qSH2;rrp=k*radpat->rpsv2;
	fun_coeff[2] = dcrmul2(rp, rrp);
	rp=model->qSH1;rp1=model->qPSV1[0];rrp=k*radpat->rpsv1;
	rp=dcsub2(rp, rp1);
	fun_coeff[3] = dcrmul2(rp, rrp);
	rp=model->qPSV2[0];rp1=model->qSH2;rrp=k*radpat->rpsv2;
	rp=dcsub2(rp, rp1);
	fun_coeff[4] = dcrmul2(rp, rrp);
	//for Ut: fun[5]-[8]
	rp=model->qPSV1[0];rrp=k*radpat->rsh1;
	fun_coeff[5] = dcrmul2(rp, rrp);
	rp=model->qPSV2[0];rrp= k*radpat->rsh2;
	fun_coeff[6] = dcrmul2(rp,rrp);
	rp=model->qSH1;rp1=model->qPSV1[0];rrp=k*radpat->rsh1;
	rp=dcsub2(rp, rp1);
	fun_coeff[7] = dcrmul2(rp, rrp);
	rp=model->qSH2;rp1=model->qPSV2[0];rrp=k*radpat->rsh2;
	rp=dcsub2(rp, rp1);
	fun_coeff[8] = dcrmul2(rp, rrp);
	//for Uz: fun[9]-[11]
	//fun_coeff[9] = dcrmul(dcadd(model->qPSV2[1], dcrmul(model->qPSV0[1], 2.)), k*radpat->rpsv01);
	//modified according to Tang Le, for M and D
	rp=model->qPSV2[1];rrp1=k*radpat->rpsv01;rp2=model->qPSV0[1];rrp=-k*radpat->rpsv02;
	rp=dcrmul2(rp, rrp1);rp1=dcrmul2(rp2, rrp);
	fun_coeff[9] = dcadd2(rp, rp1);
	rp=model->qPSV1[1];rrp=k*radpat->rpsv1;
	fun_coeff[10] = dcrmul2(rp, rrp);
	rp=model->qPSV2[1];rrp=-k*radpat->rpsv2;
	fun_coeff[11] = dcrmul2(rp, rrp);
	///////////////// for curl ////////////////////////////// 
	// ur
   fun_coeffd[0]= dcrmul(model->qPSV2[1], -k*k/4.*radpat->rpsv2d);//(j1+j3)
    fun_coeffd[1]= dcrmul(model->qPSV1[1], k*k/2.*radpat->rpsv1d);//(j0+j2)
    fun_coeffd[2]= dcrmul(model->qPSV2[1], k*k*radpat->rpsv01d);//(j0^2-j2^2)/j1/2+(j1+j3)/4
    fun_coeffd[3]= dcrmul(model->qPSV0[1], k*k*radpat->rpsv02d);//(j0^2-j2^2)/j1/2+(j1+j3)/4

    fun_coeffd[4]= dcrmul(dcsub(model->qSH2d,model->qPSV2d[0]),k*radpat->rsh2);//j2d
    fun_coeffd[5]= dcrmul(model->qPSV2d[0],k*radpat->rsh2);//j1
    fun_coeffd[6]= dcrmul(model->qSH1d,k*radpat->rsh1);//j1d
    fun_coeffd[7]= dcrmul(model->qPSV1d[0],k/2.*radpat->rsh1);//j0
    fun_coeffd[8]= dcrmul(model->qPSV1d[0],k/2.*radpat->rsh1);//j2
	//ut
	fun_coeffd[9]= dcrmul(dcsub(model->qPSV2d[0],model->qSH2d),k*radpat->rpsv2);//j2d
	fun_coeffd[10]=dcrmul(model->qSH1d,-k/2.*radpat->rpsv1);//j0
	fun_coeffd[11]=dcrmul(model->qSH1d,-k/2.*radpat->rpsv1);//j2
	fun_coeffd[12]=dcrmul(model->qSH2d,k*radpat->rpsv2);//j1
	fun_coeffd[13]=dcrmul(model->qPSV1d[0],-k*radpat->rpsv1);//j1d
	fun_coeffd[14]=dcrmul(model->qPSV0d[0],k*radpat->rpsv02);//j0d
	fun_coeffd[15]=dcrmul(model->qPSV2d[0],-k*radpat->rpsv01);//j0d

	fun_coeffd[16]=dcrmul(model->qPSV2[1],-k*k*radpat->rpsv2);//j2d
	fun_coeffd[17]=dcrmul(model->qPSV1[1],k*k*radpat->rpsv1);//j1d
	fun_coeffd[18]=dcrmul(model->qPSV2[1],k*k*radpat->rpsv01);//j0d
	fun_coeffd[19]=dcrmul(model->qPSV0[1],-k*k*radpat->rpsv02);//j0d
	//uz
	fun_coeffd[20]= dcrmul(dcsub(model->qSH2,model->qPSV2[0]),k*k*radpat->rsh2);//(j0+j2)/4-(j2+j4)/12+j2dd
	fun_coeffd[21]= dcrmul(model->qPSV2[0],k*k*radpat->rsh2);//(j0+j2)/2+j1d
	fun_coeffd[22]= dcrmul(model->qSH1,k*k*radpat->rsh1);//(j0^2-j2^2)/4/j1+j1dd
    fun_coeffd[23]= dcrmul(model->qPSV1[0],k*k/2.*radpat->rsh1);//(j0^2-j2^2)/2/j1+(j1+j3)/4+j0d
    fun_coeffd[24]= dcrmul(model->qPSV1[0],k*k/2.*radpat->rsh1);//(j1+j3)/4+j2d

    fun_coeffd[25]= dcrmul(dcsub(model->qPSV2[0],model->qSH2),k*k*radpat->rpsv2d);//(j0+j2)/4-(j2+j4)/12
    fun_coeffd[26]= dcrmul(model->qSH1,-k*k/2.*radpat->rpsv1d);//(j0^2-j2^2)/2/j1+(j1+j3)/4
    fun_coeffd[27]= dcrmul(model->qSH1,-k*k/2.*radpat->rpsv1d);//(j1+j3)/4
    fun_coeffd[28]= dcrmul(model->qSH2,k*k*radpat->rpsv2d);//(j0+j2)/2
    fun_coeffd[29]= dcrmul(model->qPSV1[0],-k*k*radpat->rpsv1d);//(j0^2-j2^2)/4/j1
    fun_coeffd[30]= dcrmul(model->qPSV0[0],-k*k*radpat->rpsv02d);//(j0+j2)/2
    fun_coeffd[31]= dcrmul(model->qPSV2[0],k*k*radpat->rpsv01d);//(j0+j2)/2
}

void integration_D(dcomplex integ[3], const dcomplex fun_coeff[12], 
	double j0, double j1, double j2, double j0d, double j1d, double j2d,dcomplex integd[3], const dcomplex fun_coeffd[32],
	double j3, double j4, double j1dd, double j2dd)
{
	dcomplex fund[32];
	int i;
    for (i = 0; i < 32; i++) {
		fund[i] = dcmplx2(0., 0.);
	}
	dcomplex fun[12],rp1,rp2,temp,temp1;
	dcomplex rp=fun_coeff[0];
	fun[0] = dcrmul2(rp, j0);
	rp=fun_coeff[1];
	fun[1] = dcrmul2(rp, j0d);
	rp=fun_coeff[2];
	fun[2] = dcrmul2(rp, j1);
	rp=fun_coeff[3];
	fun[3] = dcrmul2(rp, j1d);
	rp=fun_coeff[4];
	fun[4] = dcrmul2(rp, j2d);
	rp=fun_coeff[5];
	fun[5] = dcrmul2(rp, j0);
	rp=fun_coeff[6];
	fun[6] = dcrmul2(rp, j1);
	rp=fun_coeff[7];
	fun[7] = dcrmul2(rp, j1d);
	rp=fun_coeff[8];
	fun[8] = dcrmul2(rp, j2d);
	rp=fun_coeff[9];
	fun[9] = dcrmul2(rp, j0);
	rp=fun_coeff[10];
	fun[10] = dcrmul2(rp, j1);
	rp=fun_coeff[11];
	fun[11] = dcrmul2(rp, j2);
	rp=dcadd2(fun[3], fun[4]);rp1=dcadd2(fun[2], rp);rp2=dcadd2(fun[1], rp1);
	integ[0] = dcadd2(fun[0], rp2);
	rp=dcadd2(fun[7], fun[8]);rp1=dcadd2(fun[6], rp);
	integ[1] = dcadd2(fun[5], rp1);
	rp=dcadd2(fun[10], fun[11]);
	integ[2] = dcadd2(fun[9], rp);

	/*printf("%lf\n",integ[0].r );
	printf("%lf\n",integ[0].i );
	printf("%lf\n",integ[1].r );
	printf("%lf\n",integ[1].i );
	printf("%lf\n",integ[2].r );
	printf("%lf\n",integ[2].i );
	exit(0);*/
	//////////////////// for curl ////////////////////////////
    //ur
fund[0] = dcrmul(fun_coeffd[0], j1+j3);
fund[1] = dcrmul(fun_coeffd[1], j0+j2);
fund[2] = dcrmul(fun_coeffd[2], (j0*j0-j2*j2)/j1/2.+(j1+j3)/4.);
fund[3] = dcrmul(fun_coeffd[3], (j0*j0-j2*j2)/j1/2.+(j1+j3)/4.);

fund[4] = dcrmul(fun_coeffd[4], j2d);
fund[5] = dcrmul(fun_coeffd[5], j1);
fund[6] = dcrmul(fun_coeffd[6], j1d);
fund[7] = dcrmul(fun_coeffd[7], j0);
fund[8] = dcrmul(fun_coeffd[8], j2);
//ut
fund[9] = dcrmul(fun_coeffd[9], j2d);
fund[10] = dcrmul(fun_coeffd[10], j0);
fund[11] = dcrmul(fun_coeffd[11], j2);
fund[12] = dcrmul(fun_coeffd[12], j1);
fund[13] = dcrmul(fun_coeffd[13], j1d);
fund[14] = dcrmul(fun_coeffd[14], j0d);
fund[15] = dcrmul(fun_coeffd[15], j0d);

fund[16] = dcrmul(fun_coeffd[16], j2d);
fund[17] = dcrmul(fun_coeffd[17], j1d);
fund[18] = dcrmul(fun_coeffd[18], j0d);
fund[19] = dcrmul(fun_coeffd[19], j0d);
//uz
fund[20] = dcrmul(fun_coeffd[20], (j0+j2)/4.-(j2+j4)/12.+j2dd );
fund[21] = dcrmul(fun_coeffd[21], (j0+j2)/2.+j1d);
fund[22] = dcrmul(fun_coeffd[22], (j0*j0-j2*j2)/4./j1+j1dd );
fund[23] = dcrmul(fun_coeffd[23], (j0*j0-j2*j2)/2./j1+(j1+j3)/4.+j0d );
fund[24] = dcrmul(fun_coeffd[24], (j1+j3)/4.+j2d );

fund[25] = dcrmul(fun_coeffd[25], (j0+j2)/4.-(j2+j4)/12. );
fund[26] = dcrmul(fun_coeffd[26], (j0*j0-j2*j2)/2./j1+(j1+j3)/4. );
fund[27] = dcrmul(fun_coeffd[27], (j1+j3)/4. );
fund[28] = dcrmul(fun_coeffd[28], (j0+j2)/2. );
fund[29] = dcrmul(fun_coeffd[29], (j0*j0-j2*j2)/4./j1 );
fund[30] = dcrmul(fun_coeffd[30], (j0+j2)/2. );
fund[31] = dcrmul(fun_coeffd[31], (j0+j2)/2. );
temp=dcadd(fund[0], dcadd(fund[1], dcadd(fund[2], fund[3])));
temp1=dcadd(fund[4], dcadd(fund[5], dcadd(fund[6], dcadd(fund[8], fund[7]))));
integd[0] = dcsub(temp,temp1);
temp=dcadd(fund[9], dcadd(fund[10], dcadd(fund[11], dcadd(fund[12], dcadd(fund[13], dcadd(fund[14], fund[15]))))));
temp1=dcadd(fund[16], dcadd(fund[17], dcadd(fund[18],fund[19])));
integd[1] = dcsub(temp,temp1);
temp=dcadd(fund[20], dcadd(fund[21], dcadd(fund[22], dcadd(fund[23], fund[24]))));
temp1=dcadd(fund[25], dcadd(fund[26], dcadd(fund[27], dcadd(fund[28], dcadd(fund[29], dcadd(fund[30], fund[31]))))));
integd[2] = dcsub(temp,temp1);



	///////////////////////////////////////////////////////////
}

void integral_function_coeff_S(double k, FKRTmodel *model, const RadPat_S *radpat,
	const int layerSour, const int layerRecv,
	const double zSour, const double zRecv,
	dcomplex fun_coeff[7],dcomplex fun_coeffd[14])
{
	//set the wavenumber-related variable
	set_wavenumber_variables(model, k);
	//calculate the wave propagation
	calc_GRT(model, layerSour);
	calc_Y(model, layerSour, layerRecv, zSour, zRecv);
	calc_q_S(model, layerSour, zSour, zRecv);
	//caculate the coeffient of the interal functions
	fun_coeff[0] = dcrmul(model->qSH1, k*radpat->rpsv1);
	fun_coeff[1] = dcrmul(model->qPSV0[0], k*radpat->rpsv0);
	fun_coeff[2] = dcrmul(dcsub(model->qPSV1[0], model->qSH1), k*radpat->rpsv1);
	fun_coeff[3] = dcrmul(model->qPSV1[0], k*radpat->rsh1);
	fun_coeff[4] = dcrmul(dcsub(model->qSH1, model->qPSV1[0]), k*radpat->rsh1);
	fun_coeff[5] = dcrmul(model->qPSV0[1], -k*radpat->rpsv0);
	fun_coeff[6] = dcrmul(model->qPSV1[1], -k*radpat->rpsv1);

	// for curl //////////////////////////////////////////// modified by Tang Le 2020 1.14
	//ur
    fun_coeffd[0] = dcrmul(model->qPSV1[1], -k*k/2.*radpat->rpsv1d);//(j0+j2)
    fun_coeffd[1] = dcrmul(model->qPSV0[1], -k*k*radpat->rpsv0d);//(j0*j0-j2*j2)/j1/2.0+(j1+j3)/4.

    fun_coeffd[2] = dcrmul(model->qPSV1d[0], k/2.*radpat->rsh1);//(j0+j2)
    fun_coeffd[3] = dcrmul(model->qSH1d, k*radpat->rsh1);//(j1d)
    //ut
    fun_coeffd[4] = dcrmul(model->qSH1d, k/2.*radpat->rpsv1);//(j0+j2)
    fun_coeffd[5] = dcrmul(model->qPSV1d[0], k*radpat->rpsv1);//(j1d)
    fun_coeffd[6] = dcrmul(model->qPSV0d[0], k*radpat->rpsv0);//(j0d)

    fun_coeffd[7] = dcrmul(model->qPSV1[1], -k*k*radpat->rpsv1);//(j1d)
    fun_coeffd[8] = dcrmul(model->qPSV0[1], -k*k*radpat->rpsv0);//(j0d)
    //uz
    fun_coeffd[9] = dcrmul(model->qPSV1[0], k*k*radpat->rsh1);//(j0*j0-j2*j2)/j1/4.0
    fun_coeffd[10] = dcrmul(model->qSH1, k*k*radpat->rsh1);//(j0*j0-j2*j2)/j1/4.0+(j0d-j2d)/2.

    fun_coeffd[11] = dcrmul(model->qSH1, k*k/4.*radpat->rpsv1d);//(j0*j0-j2*j2)/j1+(j1+j3)
    fun_coeffd[12] = dcrmul(model->qPSV1[0], k*k*radpat->rpsv1d);//(j0*j0-j2*j2)/j1/4.
    fun_coeffd[13] = dcrmul(model->qPSV0[0], -k*k*radpat->rpsv0d);//(j0+j2)/2.

}

void integration_S(dcomplex integ[3], const dcomplex fun_coeff[7],
	double j0, double j1, double j0d, double j1d,double j2, double j3, double j2d, dcomplex integd[3], const dcomplex fun_coeffd[14])
{
	dcomplex fun[7],fund[14],temp,temp1;
	fun[0] = dcrmul(fun_coeff[0], j0);
	fun[1] = dcrmul(fun_coeff[1], j0d);
	fun[2] = dcrmul(fun_coeff[2], j1d);
	fun[3] = dcrmul(fun_coeff[3], j0);
	fun[4] = dcrmul(fun_coeff[4], j1d);
	fun[5] = dcrmul(fun_coeff[5], j0);
	fun[6] = dcrmul(fun_coeff[6], j1);
	integ[0] = dcadd(fun[0], dcadd(fun[1], fun[2]));
	integ[1] = dcadd(fun[3], fun[4]);
	integ[2] = dcadd(fun[5], fun[6]);

	// for curl //////////////////////////////////////////// modified by Tang Le 2020 1.14
	// ur
	fund[0] = dcrmul(fun_coeffd[0], j0+j2);
	fund[1] = dcrmul(fun_coeffd[1], (j0*j0-j2*j2)/j1/2.0+(j1+j3)/4. );

	fund[2] = dcrmul(fun_coeffd[2], j0+j2 );
	fund[3] = dcrmul(fun_coeffd[3], j1d );
	//ut
	fund[4] = dcrmul(fun_coeffd[4], j0+j2 );
	fund[5] = dcrmul(fun_coeffd[5], j1d );
	fund[6] = dcrmul(fun_coeffd[6], j0d );

	fund[7] = dcrmul(fun_coeffd[7], j1d );
	fund[8] = dcrmul(fun_coeffd[8], j0d );
	//uz
	fund[9] = dcrmul(fun_coeffd[9], (j0*j0-j2*j2)/j1/4.0 );
	fund[10] = dcrmul(fun_coeffd[10], (j0*j0-j2*j2)/j1/4.0+(j0d-j2d)/2. );

    fund[11] = dcrmul(fun_coeffd[11], (j0*j0-j2*j2)/j1+(j1+j3) );
    fund[12] = dcrmul(fun_coeffd[12], (j0*j0-j2*j2)/j1/4. );
    fund[13] = dcrmul(fun_coeffd[13], (j0+j2)/2. );	
	
    //
    temp=dcadd(fund[0],fund[1]);
    temp1=dcadd(fund[2],fund[3]);    
    integd[0] = dcsub(temp,temp1);
    //
    temp=dcadd(fund[4], dcadd(fund[5],fund[6]));
    temp1=dcadd(fund[7],fund[8]);    
    integd[1] = dcsub(temp,temp1);
    //
    temp=dcadd(fund[9],fund[10]);    
    temp1=dcadd(fund[11], dcadd(fund[12],fund[13]));
    integd[2] = dcsub(temp,temp1);
    
}

void integral_function_coeff_E(double k, FKRTmodel *model,
	const int layerSour, const int layerRecv,
	const double zSour, const double zRecv,
	dcomplex fun_coeff[2])
{
	//set the wavenumber-related variable
	set_wavenumber_variables(model, k);
	//calculate the wave propagation
	calc_GRT(model, layerSour);
	calc_Y(model, layerSour, layerRecv, zSour, zRecv);
	calc_q_E(model, layerSour, zSour, zRecv);
	//caculate the coeffient of the interal functions
	//model->qPSV0=qPSV0-qPSV2
	fun_coeff[0] = dcrmul(model->qPSV0[0],k);
	fun_coeff[1] = dcrmul(dcneg(model->qPSV0[1]),k);
}

void integration_E(dcomplex integ[3], const dcomplex fun_coeff[2],
	double j0, double j0d)
{
	integ[0] = dcrmul(fun_coeff[0], j0d);
	integ[1] = dcmplx(0., 0.);
	integ[2] = dcrmul(fun_coeff[1], j0);
}

void integral_function_coeff_E0(double k, FKRTmodel *model,
	const int layerSour, const int layerRecv,
	const double zSour, const double zRecv,
	dcomplex fun_coeff[2])
{
	//set the wavenumber-related variable
	set_wavenumber_variables(model, k);
	//calculate the wave propagation
	calc_GRT(model, layerSour);
	calc_Y(model, layerSour, layerRecv, zSour, zRecv);
	calc_q_E0(model, layerSour, zSour, zRecv);
	//caculate the coeffient of the interal functions
	fun_coeff[0] = dcrmul(dcsub(model->qPSV0[0], model->qPSV2[0]),k);
	fun_coeff[1] = dcrmul(dcsub(model->qPSV2[1], model->qPSV0[1]),k);
}
