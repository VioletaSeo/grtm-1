#include "calc_q.h"
#include "dcsimpleblas.h"

void calc_q_D(FKRTmodel *model, const int layerSour, const double zSour, const double zRecv)
{
	//begin: declare variables in FKRTmodel
	double		k;
	dcomplex	omega;
	double		*pZ;
	double		*pMU;
	dcomplex	*pCVP;
	dcomplex	*pCVS;
	dcomplex	*pKZP;
	dcomplex	*pKZS;
	dcomplex	*pGRduSH;
	dcomplex	*pGRudSH;
	dcomplex	**pGRduPSV;
	dcomplex	**pGRudPSV;
	dcomplex	**pEX;
////////vTI///////////////////////////// added by Tang Le
  dcomplex *SHKZS;
  dcomplex **SHE;
  dcomplex **pSVSHE;
  dcomplex **PIEX;
  dcomplex E12[4],E22[4],EXX[4],EZZ[4],E21[4],EZZ1[4],EZZ2[4],E11[4],shvector[4],EXX1[4],EE[16],EZZ3[4];
  /////////////
	//end: declare variables in FKRTmodel
    dcomplex rp,rp1,rp2,rp3;
    double rrp;
	//local variables
	int i;
	double dz;
	dcomplex b_2uawrv, temp1, temp2, temp3;
	dcomplex kxsSH, vxsSH;
	dcomplex sourSH1, sourSH2;

	//temporary linear memory space
	dcomplex WorkSpace[64];
	dcomplex *exus, *exds;
	dcomplex *s0PSV, *s1PSV, *s2PSV;
	dcomplex *Rdu, *Rud, *ExRdu, *ExRud;
	dcomplex *UnitAddExRdu, *ExRdusubUnit, *UnitAddExRud, *UnitSubExRud;
	dcomplex *sourPSV0, *sourPSV1, *sourPSV2;

   //VTI
   dcomplex shexus[1],shexds[1];
   //
	exus = WorkSpace;
	exds = WorkSpace + 2;
	s0PSV = WorkSpace + 6;
	s1PSV = WorkSpace + 8;
	s2PSV = WorkSpace + 10;
	UnitAddExRdu = WorkSpace + 12;
	ExRdusubUnit = WorkSpace + 16;
	UnitAddExRud = WorkSpace + 20;
	UnitSubExRud = WorkSpace + 24;
	Rdu = WorkSpace + 28;
	Rud = WorkSpace + 32;
	ExRdu = WorkSpace + 36;
	ExRud = WorkSpace + 40;
	sourPSV0 = WorkSpace + 44;
	sourPSV1 = WorkSpace + 46;
	sourPSV2 = WorkSpace + 48;

	//begin: refer to variables in FKRTmodel
	pZ = model->z;
	pMU = model->mu;
	omega = model->omega;
	k = model->k;
	pCVP = model->CVp;
	pCVS = model->CVs;
	pKZP = model->kzp;
	pKZS = model->kzs;
	pGRduSH = model->GRduSH;
	pGRudSH = model->GRudSH;
	pGRduPSV = model->GRduPSV;
	pGRudPSV = model->GRudPSV;
	pEX = model->ex;
	/////////////// VTI
 	PIEX=model->iex;
 	SHKZS=model->shkzs;
 	SHE=model->shE;
 	pSVSHE=model->psvshE;

	//end: refer to variables in FKRTmodel
	//extrapolation operators for source
	if (model->media==1)//isotropy
	{
	dz = zSour - pZ[layerSour];
	rp=pKZP[layerSour];
	exds[0] = dcexp(dcrmul2(rp, dz));
	rp=pKZS[layerSour];
	exds[1] = dcexp(dcrmul2(rp, dz));
	dz = pZ[layerSour - 1] - zSour;
	rp=pKZP[layerSour];
	exus[0] = dcexp(dcrmul2(rp, dz));
	rp=pKZS[layerSour];
	exus[1] = dcexp(dcrmul2(rp, dz));
	//SH
	rrp=1.0 / 2.0 / pMU[layerSour];
	vxsSH = dcmplx2(rrp, 0.);
	kxsSH = drcdiv(k / 2.0 / pMU[layerSour], pKZS[layerSour]);
	//PSV
	rp=pKZP[layerSour];rp1=pKZS[layerSour];
	rp=dcmul2(rp, rp1);
	rp1=omega;
	rp=dcmul2(rp1, rp);
	rp1=pCVP[layerSour];
	temp1 = dcmul2(rp1, rp);
	rrp=2.*pMU[layerSour];
	rp=temp1;
	temp2 = dcrmul2(rp, rrp);
	rp=pCVS[layerSour];rp1= temp2;
	b_2uawrv = dcdiv2(rp,rp1);
	rp=pKZP[layerSour];rp1=pKZS[layerSour];
	rp=dcmul2(rp, rp1);
	rp1=b_2uawrv;
	temp1 = dcmul2(rp1, rp);
	rp=temp1;
	rrp=k;
	temp2 = dcrmul2(rp, rrp);
	rp=pKZS[layerSour];rp1=pKZS[layerSour];
	rp=dcmul2(rp, rp1);
	rrp=k*k;
	temp3 = dcradd2(rp,rrp);
	rp=pKZP[layerSour];rp1=pCVS[layerSour];
	rp=dcmul2(rp, rp1);
	rp1=temp1;
	s0PSV[0] = dcmul2(rp1, rp);
	rp=pCVP[layerSour];
	rp=dcneg2(rp);rp1=temp2;
	s0PSV[1] = dcmul2(rp1, rp);
	rp=pCVS[layerSour];
	rp=dcrmul2(rp, -2.);
	rp1=temp2;
	s1PSV[0] = dcmul2(rp1, rp);
	rp=pCVP[layerSour];rp1=temp3;
	rp=dcmul2(rp1, rp);
	rp1=pKZP[layerSour];
	rp=dcmul2(rp1, rp);
	rp1=b_2uawrv;
	s1PSV[1] = dcmul2(rp1, rp);
	rp=pKZS[layerSour];rp1=pCVS[layerSour];
	rp=dcmul2(rp, rp1);
	rrp=k*k;
	rp=dcrmul2(rp, rrp);
	rp1=b_2uawrv;
	s2PSV[0] = dcmul2(rp1, rp);
	s2PSV[1] = s0PSV[1];
	}
	else//VTI
	{
	dz = zSour - pZ[layerSour];
	exds[0] = dcexp(dcrmul(pKZP[layerSour], dz));
	exds[1] = dcexp(dcrmul(pKZS[layerSour], dz));
  	shexds[0]=dcexp(dcrmul(SHKZS[layerSour], dz));

	dz = pZ[layerSour - 1] - zSour;
	exus[0] = dcexp(dcrmul(pKZP[layerSour], dz));
	exus[1] = dcexp(dcrmul(pKZS[layerSour], dz));
  	shexus[0]=dcexp(dcrmul(SHKZS[layerSour], dz));

	}
	//q
	if (zRecv <= zSour) 
	{  //su
		//SH
		if (model->media==1)//isotropy
		{
		rp=pGRduSH[layerSour];
		rp1=exds[1];
		rp=dcmul2(rp, rp1);
		rp1=exds[1];
		temp1 = dcmul2(rp1, rp);
                // temp1 = dcmul(exds[1], dcmul(pGRduSH[layerSour], pEX[layerSour][1]));//tang
		rp=temp1;rp1=drcsub2(1.0, rp);
		rp=vxsSH;
		sourSH1 = dcmul2(rp1, rp);
		rp=temp1;rp1=dcradd2(rp, 1.0);
		rp= kxsSH;
		sourSH2 = dcmul2(rp1,rp);
		//PSV
		dcmulRD22(pGRduPSV[layerSour], exds, Rdu);
		dcmulLD22(exds, Rdu, ExRdu);
		dcUnitAddOther22(ExRdu, UnitAddExRdu);
		dcSubUnitOther22(ExRdu, ExRdusubUnit);
		for (i = 0; i < 2; i++) 
		{
			rp=UnitAddExRdu[i * 2];rp1= s0PSV[0];rp2=UnitAddExRdu[i * 2 + 1];rp3=s0PSV[1];
			rp=dcmul2(rp,rp1);rp1=dcmul2(rp2, rp3);
			sourPSV0[i] = dcadd2(rp, rp1);
			rp=ExRdusubUnit[i * 2];rp1=s1PSV[0];rp2=ExRdusubUnit[i * 2 + 1];rp3=s1PSV[1];
			rp=dcmul2(rp, rp1);rp1=dcmul2(rp2, rp3);
			sourPSV1[i] = dcadd2(rp, rp1);
			rp=UnitAddExRdu[i * 2];rp1=s2PSV[0];rp2=UnitAddExRdu[i * 2 + 1];rp3=s2PSV[1];
			rp=dcmul2(rp, rp1);rp1=dcmul2(rp2, rp3);
			sourPSV2[i] = dcadd2(rp, rp1);
		}

		}
		else//VTI
		{

	 temp1 = dcmul(shexds[0], dcmul(pGRduSH[layerSour], shexds[0]));
     for(i=0;i<4;i++)
     {
       shvector[i]=SHE[layerSour][i];
     }
      dcinv22(shvector);
     temp1=dcmul(temp1,shvector[1]);
     temp2=dcadd(temp1,shvector[3]);
     temp1=dcsub(shvector[3],temp1);

     temp2=dcmul(temp2,SHKZS[layerSour]);
     temp1=dcrmul(temp1,k);
   		sourSH1 = temp2;
		sourSH2 = temp1;
    //psv
		dcmulRD22(pGRduPSV[layerSour], exds, Rdu);
		dcmulLD22(exds, Rdu, ExRdu);
	for(i=0;i<16;i++)
  	{
       EE[i]=pSVSHE[layerSour][i];
  	}

  		dcinv44(EE);
   		partMat44to22(EE,E11,E12,E21,E22); 
      dcmul22(ExRdu,E12,EXX);
      for(i=0;i<4;i++)
      {
        EXX[i]=dcsub(EXX[i],E22[i]);
      }
       //////
       EZZ[0]=dcmul(E12[0],pKZP[layerSour]);    
       EZZ[1]=dcmul(E12[1],pKZP[layerSour]);
       EZZ[2]=dcmul(E12[2],pKZS[layerSour]);    
       EZZ[3]=dcmul(E12[3],pKZS[layerSour]);
       EZZ2[0]=dcmul(E22[0],pKZP[layerSour]);  
       EZZ2[1]=dcmul(E22[1],pKZP[layerSour]);
       EZZ2[2]=dcmul(E22[2],pKZS[layerSour]);
       EZZ2[3]=dcmul(E22[3],pKZS[layerSour]);

      dcmul22(ExRdu,EZZ,EZZ1);
      for(i=0;i<4;i++)
      {
        EZZ2[i]=dcadd(EZZ1[i],EZZ2[i]);
      }

       /////
    
	   dcmul22(model->yPSV,EXX,EXX1);
       dcmul22(model->yPSV,EZZ2,EZZ3);
       
		model->qPSV0[0] =EZZ3[1] ;
		model->qPSV0[1] =dcneg(EZZ3[3]);//
		model->qPSV1[0] =dcneg(dcadd(dcrmul(EXX1[1],k),EZZ3[0])) ;//
   	    model->qPSV1[1] =dcadd(dcrmul(EXX1[3],k),EZZ3[2]);
		model->qPSV2[0] =dcrmul(EXX1[0],k);//
 		model->qPSV2[1] =dcneg(dcrmul(EXX1[2],k));

 		dcmul22(model->yPSVd,EXX,EXX1);
        dcmul22(model->yPSVd,EZZ2,EZZ3);
       
		model->qPSV0d[0] =EZZ3[1] ;
		model->qPSV0d[1] =dcneg(EZZ3[3]);//
		model->qPSV1d[0] =dcneg(dcadd(dcrmul(EXX1[1],k),EZZ3[0])) ;//
   	    model->qPSV1d[1] =dcadd(dcrmul(EXX1[3],k),EZZ3[2]);
		model->qPSV2d[0] =dcrmul(EXX1[0],k);//
 		model->qPSV2d[1] =dcneg(dcrmul(EXX1[2],k));

		}
	}
	else { 

	if(model->media==1)//isotropy
	{ 
		//SH
		rp=pGRudSH[layerSour - 1];rp1=exus[1];
		rp=dcmul2(rp, rp1);
		rp1=exus[1];
      		temp2 = dcmul2(rp1, rp);
                 //temp2 = dcmul(exus[1], dcmul(pGRudSH[layerSour - 1], pEX[layerSour][1]));//tang le
      		rp=temp2;rp1=dcradd2(rp, -1.);rp=vxsSH;
		sourSH1 = dcmul2(rp1,rp );
		rp=temp2;rp1=dcradd2(rp, 1.0);
		rp= kxsSH;
		sourSH2 = dcmul2(rp1,rp);
		//PSV
		dcmulRD22(pGRudPSV[layerSour - 1], exus, Rud);
		dcmulLD22(exus, Rud, ExRud);
		dcUnitAddOther22(ExRud, UnitAddExRud);
		dcUnitSubOther22(ExRud, UnitSubExRud);
		for (i = 0; i < 2; i++) 
		{
			rp=UnitAddExRud[i * 2];rp1=s0PSV[0];rp2=UnitAddExRud[i * 2 + 1];rp3=s0PSV[1];
			rp=dcmul2(rp, rp1);rp1=dcmul2(rp2, rp3);
			sourPSV0[i] = dcadd2(rp, rp1);
			rp=UnitSubExRud[i * 2];rp1=s1PSV[0];rp2=UnitSubExRud[i * 2 + 1];rp3=s1PSV[1];
			rp=dcmul2(rp, rp1);rp1=dcmul2(rp2, rp3);
			sourPSV1[i] = dcadd2(rp, rp1);
			rp=UnitAddExRud[i * 2];rp1=s2PSV[0];rp2=UnitAddExRud[i * 2 + 1];rp3=s2PSV[1];
			rp=dcmul2(rp, rp1);rp1=dcmul2(rp2, rp3);
			sourPSV2[i] = dcadd2(rp, rp1);
		}
	}
	else//VTI
	{
		  for(i=0;i<4;i++)
           {
                shvector[i]=SHE[layerSour][i];
           }
             dcinv22(shvector);

          temp1 = dcmul(shexus[0], dcmul(pGRudSH[layerSour-1], shexus[0]));
          temp1=dcmul(temp1,shvector[3]);
          temp2=dcadd(temp1,shvector[1]);
          temp1=dcsub(temp1,shvector[1]);
      
          temp2=dcmul(temp2,SHKZS[layerSour]);
          temp1=dcrmul(temp1,k);

        	sourSH1 = temp2;
		    sourSH2 = temp1;
        	//PSV
          for(i=0;i<16;i++)
         {
           EE[i]=pSVSHE[layerSour][i];
         }

      dcinv44(EE);partMat44to22(EE,E11,E12,E21,E22);

	       	dcmulRD22(pGRudPSV[layerSour - 1], exus, Rud);
	      	dcmulLD22(exus, Rud, ExRud);
         dcmul22(ExRud,E22,EXX);
       for(i=0;i<4;i++)
       {
         EXX[i]=dcsub(E12[i],EXX[i]);
       }
       EZZ[0]=dcmul(E12[0],pKZP[layerSour]);    
       EZZ[1]=dcmul(E12[1],pKZP[layerSour]);
       EZZ[2]=dcmul(E12[2],pKZS[layerSour]);    
       EZZ[3]=dcmul(E12[3],pKZS[layerSour]);
       EZZ2[0]=dcmul(E22[0],pKZP[layerSour]);  
       EZZ2[1]=dcmul(E22[1],pKZP[layerSour]);
       EZZ2[2]=dcmul(E22[2],pKZS[layerSour]);
       EZZ2[3]=dcmul(E22[3],pKZS[layerSour]);
       dcmul22(ExRud,EZZ2,EZZ3);
       for(i=0;i<4;i++)
       {
         EZZ3[i]=dcadd(EZZ[i],EZZ3[i]);
       } 
       dcmul22(model->yPSV,EXX,EXX1);
       dcmul22(model->yPSV,EZZ3,EZZ2);

		model->qPSV0[0] =EZZ2[1] ;
		model->qPSV0[1] =dcneg(EZZ2[3]) ;//
		model->qPSV1[0] =dcneg(dcadd(dcrmul(EXX1[1],k),EZZ2[0])) ;//
   	    model->qPSV1[1] =dcadd(dcrmul(EXX1[3],k),EZZ2[2]) ;
		model->qPSV2[0] =dcrmul(EXX1[0],k) ;
		model->qPSV2[1] =dcneg(dcrmul(EXX1[2],k)) ;//


		// for curl
		dcmul22(model->yPSVd,EXX,EXX1);
        dcmul22(model->yPSVd,EZZ3,EZZ2);

		model->qPSV0d[0] =EZZ2[1] ;
		model->qPSV0d[1] =dcneg(EZZ2[3]) ;//
		model->qPSV1d[0] =dcneg(dcadd(dcrmul(EXX1[1],k),EZZ2[0])) ;//
   	    model->qPSV1d[1] =dcadd(dcrmul(EXX1[3],k),EZZ2[2]) ;
		model->qPSV2d[0] =dcrmul(EXX1[0],k) ;
		model->qPSV2d[1] =dcneg(dcrmul(EXX1[2],k)) ;//

		}


	}

	//SH
	rp=model->ySH;rp1=sourSH1;
	model->qSH1 = dcmul2(rp, rp1);
	rp=model->ySH;rp1=sourSH2;
	model->qSH2 = dcmul2(rp, rp1);
	//SH for curl////////////////////
	rp=model->ySHd;rp1=sourSH1;
	model->qSH1d = dcmul2(rp, rp1);
	rp=model->ySHd;rp1=sourSH2;
	model->qSH2d = dcmul2(rp, rp1);
	//////////////////////////////////
	//PS
	if (model->media==1)//isotropy
	{
	for (i = 0; i < 2; i++) 
	{
		rp=model->yPSV[i * 2];rp1=sourPSV0[0];rp2=model->yPSV[i * 2 + 1];rp3= sourPSV0[1];
		rp=dcmul2(rp, rp1);rp1=dcmul2(rp2,rp3);
		model->qPSV0[i] = dcadd2(rp, rp1);
		rp1=model->yPSV[i * 2];rp=sourPSV1[0];rp2=model->yPSV[i * 2 + 1];rp3=sourPSV1[1];
		rp=dcmul2(rp1, rp);rp1=dcmul2(rp2, rp3);
		model->qPSV1[i] = dcadd2(rp, rp1);
		rp=model->yPSV[i * 2];rp1=sourPSV2[0];rp2=model->yPSV[i * 2 + 1];rp3=sourPSV2[1];
		rp=dcmul2(rp, rp1);rp1=dcmul2(rp2, rp3);
		model->qPSV2[i] = dcadd2(rp, rp1);
	}
    ///////////////////// psv for curl /////////////
    for (i = 0; i < 2; i++) 
    {
		rp=model->yPSVd[i * 2];rp1=sourPSV0[0];rp2=model->yPSVd[i * 2 + 1];rp3= sourPSV0[1];
		rp=dcmul2(rp, rp1);rp1=dcmul2(rp2,rp3);
		model->qPSV0d[i] = dcadd2(rp, rp1);
		rp1=model->yPSVd[i * 2];rp=sourPSV1[0];rp2=model->yPSVd[i * 2 + 1];rp3=sourPSV1[1];
		rp=dcmul2(rp1, rp);rp1=dcmul2(rp2, rp3);
		model->qPSV1d[i] = dcadd2(rp, rp1);
		rp=model->yPSVd[i * 2];rp1=sourPSV2[0];rp2=model->yPSVd[i * 2 + 1];rp3=sourPSV2[1];
		rp=dcmul2(rp, rp1);rp1=dcmul2(rp2, rp3);
		model->qPSV2d[i] = dcadd2(rp, rp1);
	}
	}


    ////////////////////////////////////////////////
	return;
}

void calc_q_S(FKRTmodel *model, const int layerSour, const double zSour, const double zRecv)
{
	//begin: declare variables in FKRTmodel
	double		k;
	dcomplex	omega;
	double		*pZ;
	double		*pMU;
	dcomplex	*pCVP;
	dcomplex	*pCVS;
	dcomplex	*pKZP;
	dcomplex	*pKZS;
	dcomplex	*pGRduSH;
	dcomplex	*pGRudSH;
	dcomplex    **pGRduPSV;
	dcomplex    **pGRudPSV;
	dcomplex    **pEX;
	//VTI
    dcomplex *SHKZS;
    dcomplex **SHE;    //eigvector_sh
    dcomplex **pSVSHE;//eigvector_psv
    dcomplex **PIEX;
    dcomplex EAA[4],EBB[4],shvector[4],EE[16],E11[4],E12[4],E21[4],E22[4];
///////////////
	//end: declare variables in FKRTmodel

	//local variables
	int i;
	double dz;
	dcomplex b_2uawrv, temp1, temp2;
	dcomplex fSH;
	dcomplex sourSH1;
    dcomplex rp,rp1,rp2,rp3;
    double rrp,rrp1;
	//temporary linear memory space
	dcomplex WorkSpace[64];
	dcomplex *exus, *exds;
	dcomplex *f0PSV, *f1PSV;
	dcomplex *Rdu, *Rud, *ExRdu, *ExRud;
	dcomplex *UnitAddExRdu, *ExRdusubUnit, *UnitAddExRud, *UnitSubExRud;
	dcomplex *sourPSV0, *sourPSV1;
   //VTI
   dcomplex shexus[1],shexds[1];
   //
	exus = WorkSpace;
	exds = WorkSpace + 2;
	f0PSV = WorkSpace + 6;
	f1PSV = WorkSpace + 8;
	UnitAddExRdu = WorkSpace + 12;
	ExRdusubUnit = WorkSpace + 16;
	UnitAddExRud = WorkSpace + 20;
	UnitSubExRud = WorkSpace + 24;
	Rdu = WorkSpace + 28;
	Rud = WorkSpace + 32;
	ExRdu = WorkSpace + 36;
	ExRud = WorkSpace + 40;
	sourPSV0 = WorkSpace + 44;
	sourPSV1 = WorkSpace + 46;

	//begin: refer to variables in FKRTmodel
	pZ = model->z;
	pMU = model->mu;
	omega = model->omega;
	k = model->k;
	pCVP = model->CVp;
	pCVS = model->CVs;
	pKZP = model->kzp;
	pKZS = model->kzs;
	pGRduSH = model->GRduSH;
	pGRudSH = model->GRudSH;
	pGRduPSV = model->GRduPSV;
	pGRudPSV = model->GRudPSV;
	pEX = model->ex;
	/////////////// VTI/////
 	PIEX=model->iex;
 	SHKZS=model->shkzs;
 	SHE=model->shE;
 	pSVSHE=model->psvshE;
	//end: refer to variables in FKRTmodel
	//extrapolation operators for source
	if (model->media==1)//isotropy
	{
	dz = zSour - pZ[layerSour];
	rp=pKZP[layerSour];
	exds[0] = dcexp(dcrmul2(rp, dz));
	rp=pKZS[layerSour];
	exds[1] = dcexp(dcrmul2(rp, dz));
	dz = pZ[layerSour - 1] - zSour;
	rp=pKZP[layerSour];
	exus[0] = dcexp(dcrmul2(rp, dz));
	rp=pKZS[layerSour];
	exus[1] = dcexp(dcrmul2(rp, dz));
	//SH
	fSH = drcdiv(0.5 / pMU[layerSour], pKZS[layerSour]);
	//PSV
	rp=pKZP[layerSour];rp1=pKZS[layerSour];
	rp=dcmul2(rp, rp1);rp1=omega;
	rp=dcmul2(rp1, rp);
	rp1=pCVP[layerSour];
	temp1 = dcmul2(rp1, rp);
	rrp= 2.*pMU[layerSour];rp=temp1;
	temp2 = dcrmul2(rp,rrp);
	rp=pCVS[layerSour];rp1= temp2;
	b_2uawrv = dcdiv2(rp,rp1);
	rp=pKZP[layerSour];rp1=pKZS[layerSour];
	rp=dcmul2(rp, rp1);
	rp1=pCVS[layerSour];
	rp=dcmul2(rp1, rp);
	rp1=b_2uawrv;
	f0PSV[0] = dcmul2(rp1, rp);
	rp=pKZP[layerSour];rp1=pCVP[layerSour];
	rp=dcmul2(rp, rp1);
	rrp=-k;
	rp=dcrmul2(rp, rrp);
	rp1=b_2uawrv;
	f0PSV[1] = dcmul2(rp1, rp);
	rp=pKZS[layerSour];rp1=pCVS[layerSour];
	rp=dcmul2(rp, rp1);
	rrp=k;
	rp=dcrmul2(rp,rrp);
    rp1=b_2uawrv;
	f1PSV[0] = dcmul2(rp1, rp);
	rp=pKZP[layerSour];rp1=pKZS[layerSour];
	rp=dcmul2(rp, rp1);
	rp1=pCVP[layerSour];
	rp1=dcneg2(rp1);
	rp=dcmul2(rp1,rp);
	rp1=b_2uawrv;
	f1PSV[1] = dcmul2(rp1, rp);
    }
    else//VTI
    {
    dz = zSour - pZ[layerSour];
	exds[0] = dcexp(dcrmul(pKZP[layerSour], dz));
	exds[1] = dcexp(dcrmul(pKZS[layerSour], dz));
  	shexds[0]=dcexp(dcrmul(SHKZS[layerSour], dz));

	dz = pZ[layerSour - 1] - zSour;
	exus[0] = dcexp(dcrmul(pKZP[layerSour], dz));
	exus[1] = dcexp(dcrmul(pKZS[layerSour], dz));
  	shexus[0]=dcexp(dcrmul(SHKZS[layerSour], dz));

    }
	//q
	if (zRecv <= zSour)
	 {  //su
						   
	   //SH

	 if(model->media==1)//isotropy
      {
		rp=pGRduSH[layerSour];
		rp1=exds[1];
		rp=dcmul2(rp, rp1);
		rp1=exds[1];
		temp1 = dcmul2(rp1, rp);
		//sourSH1 = dcmul(drcsub(1.0, temp1), fSH);
		//modified according to Tang Le
		rp=temp1;rp=dcradd2(rp, 1.0);
		rp1= fSH;
		sourSH1 = dcmul2(rp,rp1);
		//PSV
		dcmulRD22(pGRduPSV[layerSour], exds, Rdu);
		dcmulLD22(exds, Rdu, ExRdu);
		dcUnitAddOther22(ExRdu, UnitAddExRdu);
		dcSubUnitOther22(ExRdu, ExRdusubUnit);
		for (i = 0; i < 2; i++) 
		{
			rp=ExRdusubUnit[i * 2];rp1=f0PSV[0];rp2=ExRdusubUnit[i * 2 + 1];rp3=f0PSV[1];
			rp=dcmul2(rp, rp1);rp2=dcmul2(rp2, rp3);
			sourPSV0[i] = dcadd2(rp, rp2);
			rp=UnitAddExRdu[i * 2];rp1=f1PSV[0];rp2=UnitAddExRdu[i * 2 + 1];rp3=f1PSV[1];
			rp=dcmul2(rp, rp1);rp2=dcmul2(rp2, rp3);
			sourPSV1[i] = dcadd2(rp, rp2);
		}
      }
      else//vti
      {

     // SH
     temp1 = dcmul(shexds[0], dcmul(pGRduSH[layerSour], shexds[0]));
     for(i=0;i<4;i++)
     {
       shvector[i]=SHE[layerSour][i];
     }
     dcinv22(shvector);
     temp1=dcmul(temp1,shvector[1]);
     temp1=dcsub(shvector[3],temp1);
     sourSH1 = temp1;
     //PSV
     dcmulRD22(pGRduPSV[layerSour], exds, Rdu);
	 dcmulLD22(exds, Rdu, ExRdu);
	 for(i=0;i<16;i++)
  	 {
       EE[i]=pSVSHE[layerSour][i];
  	 }

  	 dcinv44(EE);
   	 partMat44to22(EE,E11,E12,E21,E22); 
     dcmul22(ExRdu,E12,EAA);
     for(i=0;i<4;i++)
     {
        EAA[i]=dcsub(E22[i],EAA[i]);
     }

     model->qPSV1[0]=dcneg(dcadd(dcmul(model->yPSV[0],EAA[0]),dcmul(model->yPSV[1],EAA[2])));
     model->qPSV1[1]=(dcadd(dcmul(model->yPSV[2],EAA[0]),dcmul(model->yPSV[3],EAA[2]))); 

     model->qPSV0[0]=dcneg(dcadd(dcmul(model->yPSV[0],EAA[1]),dcmul(model->yPSV[1],EAA[3])));
     model->qPSV0[1]=(dcadd(dcmul(model->yPSV[2],EAA[1]),dcmul(model->yPSV[3],EAA[3]))); 
     // curl
     model->qPSV1d[0]=dcneg(dcadd(dcmul(model->yPSV[0],EAA[0]),dcmul(model->yPSV[1],EAA[2])));
     model->qPSV1d[1]=(dcadd(dcmul(model->yPSV[2],EAA[0]),dcmul(model->yPSV[3],EAA[2]))); 

     model->qPSV0d[0]=dcneg(dcadd(dcmul(model->yPSV[0],EAA[1]),dcmul(model->yPSV[1],EAA[3])));
     model->qPSV0d[1]=(dcadd(dcmul(model->yPSV[2],EAA[1]),dcmul(model->yPSV[3],EAA[3]))); 
     


     }



	}
	else { 



        if (model->media==1)//isotropy
        {
	    //zRecv > zSour
	        //sd
			//SH

		rp=pGRudSH[layerSour - 1];rp1=exus[1];
		rp=dcmul2(rp, rp1);
		rp1=exus[1];
		temp2 = dcmul2(rp1,rp );
		//sourSH1 = dcmul(dcradd(temp2, -1.), fSH);
		//modified according to Tang Le
		rp=temp2;rp=dcradd2(rp, 1.0);
		rp1=fSH;
		sourSH1 = dcmul2(rp, rp1);
		//PSV
		dcmulRD22(pGRudPSV[layerSour - 1], exus, Rud);
		dcmulLD22(exus, Rud, ExRud);
		dcUnitAddOther22(ExRud, UnitAddExRud);
		dcUnitSubOther22(ExRud, UnitSubExRud);
		for (i = 0; i < 2; i++) 
		{
			rp=UnitSubExRud[i * 2];rp1=f0PSV[0];rp2=UnitSubExRud[i * 2 + 1];rp3=f0PSV[1];
			rp=dcmul2(rp, rp1);rp2=dcmul2(rp2, rp3);
			sourPSV0[i] = dcadd2(rp, rp2);
			rp=UnitAddExRud[i * 2];rp1=f1PSV[0];rp2=UnitAddExRud[i * 2 + 1];rp3=f1PSV[1];
			rp=dcmul2(rp, rp1);rp1=dcmul2(rp2, rp3);
			sourPSV1[i] = dcadd2(rp, rp1);
		}

	    }
	    else//VTI
	    {
	    	// SH
	      for(i=0;i<4;i++)
           {
                shvector[i]=SHE[layerSour][i];
           }
          dcinv22(shvector);
          temp1 = dcmul(shexus[0], dcmul(pGRudSH[layerSour-1], shexus[0]));
          temp1=dcmul(temp1,shvector[3]);
          temp1=dcsub(temp1,shvector[1]);
		  sourSH1 = temp1;
     //PSV
          for(i=0;i<16;i++)
          {
           EE[i]=pSVSHE[layerSour][i];
          }

          dcinv44(EE);
          partMat44to22(EE,E11,E12,E21,E22);
	      dcmulRD22(pGRudPSV[layerSour - 1], exus, Rud);
	      dcmulLD22(exus, Rud, ExRud);
          dcmul22(ExRud,E22,EBB);
     
          for(i=0;i<4;i++)
          {
            EBB[i]=dcsub(EBB[i],E12[i]);
          }

     model->qPSV1[0]=dcneg(dcadd(dcmul(model->yPSV[0],EBB[0]),dcmul(model->yPSV[1],EBB[2])));
     model->qPSV1[1]=(dcadd(dcmul(model->yPSV[2],EBB[0]),dcmul(model->yPSV[3],EBB[2]))); 

     model->qPSV0[0]=dcneg(dcadd(dcmul(model->yPSV[0],EBB[1]),dcmul(model->yPSV[1],EBB[3])));
     model->qPSV0[1]=(dcadd(dcmul(model->yPSV[2],EBB[1]),dcmul(model->yPSV[3],EBB[3]))); 
     // curl
     model->qPSV1d[0]=dcneg(dcadd(dcmul(model->yPSV[0],EBB[0]),dcmul(model->yPSV[1],EBB[2])));
     model->qPSV1d[1]=(dcadd(dcmul(model->yPSV[2],EBB[0]),dcmul(model->yPSV[3],EBB[2]))); 

     model->qPSV0d[0]=dcneg(dcadd(dcmul(model->yPSV[0],EBB[1]),dcmul(model->yPSV[1],EBB[3])));
     model->qPSV0d[1]=(dcadd(dcmul(model->yPSV[2],EBB[1]),dcmul(model->yPSV[3],EBB[3]))); 


	    }


	}

	//SH
	rp=model->ySH;rp1= sourSH1;
	model->qSH1 = dcmul2(rp,rp1);
	// for curl /////////
	rp=model->ySHd;rp1= sourSH1;
	model->qSH1d = dcmul2(rp,rp1);
	///////////////////////
	//PS
	if(model->media==1)//isotropy
	{
	for (i = 0; i < 2; i++) {
		rp=model->yPSV[i * 2];rp1=sourPSV0[0];rp2=model->yPSV[i * 2 + 1];rp3=sourPSV0[1];
		rp=dcmul2(rp, rp1);rp1=dcmul2(rp2, rp3);
		model->qPSV0[i] = dcadd2(rp, rp1);
		rp=model->yPSV[i * 2];rp1=sourPSV1[0];rp2=model->yPSV[i * 2 + 1];rp3=sourPSV1[1];
		rp=dcmul2(rp, rp1);rp1=dcmul2(rp2, rp3);
		model->qPSV1[i] = dcadd2(rp, rp1);
				//printf("%lf %lf\n",model->qPSV0[i],model->qPSV1[i);
		
	}
//	exit(0);
	///////// for curl /////////////
	//PS
	for (i = 0; i < 2; i++) {
		rp=model->yPSVd[i * 2];rp1=sourPSV0[0];rp2=model->yPSVd[i * 2 + 1];rp3=sourPSV0[1];
		rp=dcmul2(rp, rp1);rp1=dcmul2(rp2, rp3);
		model->qPSV0d[i] = dcadd2(rp, rp1);
		rp=model->yPSVd[i * 2];rp1=sourPSV1[0];rp2=model->yPSVd[i * 2 + 1];rp3=sourPSV1[1];
		rp=dcmul2(rp, rp1);rp1=dcmul2(rp2, rp3);
		model->qPSV1d[i] = dcadd2(rp, rp1);
	}

    }
//printf("%lf %lf\n",model->qPSV0[1],model->qPSV1[1]);
//exit(0);
	return;
}

void calc_q_E(FKRTmodel *model, const int layerSour, const double zSour, const double zRecv)
{
	//begin: declare variables in FKRTmodel
	double		k;
	dcomplex	omega;
	double		*pZ;
	double		*pMU;
	dcomplex	*pCVP;
	dcomplex	*pCVS;
	dcomplex	*pKZP;
	dcomplex	*pKZS;
	dcomplex    **pGRduPSV;
	dcomplex    **pGRudPSV;
	dcomplex    **pEX;
	//end: declare variables in FKRTmodel

	//local variables
	int i;
	double dz;
	dcomplex b_2uawrv, temp1, temp2, temp3;
    dcomplex rp,rp1,rp2,rp3;
    double rrp,rrp1;
	//temporary linear memory space
	dcomplex WorkSpace[64];
	dcomplex *exus, *exds;
	dcomplex *s0PSV;
	dcomplex *Rdu, *Rud, *ExRdu, *ExRud;
	dcomplex *UnitAddExRdu, *UnitAddExRud;
	dcomplex *sourPSV0;

	exus = WorkSpace;
	exds = WorkSpace + 2;
	s0PSV = WorkSpace + 6;
	UnitAddExRdu = WorkSpace + 12;
	UnitAddExRud = WorkSpace + 20;
	Rdu = WorkSpace + 28;
	Rud = WorkSpace + 32;
	ExRdu = WorkSpace + 36;
	ExRud = WorkSpace + 40;
	sourPSV0 = WorkSpace + 44;

	//begin: refer to variables in FKRTmodel
	pZ = model->z;
	pMU = model->mu;
	omega = model->omega;
	k = model->k;
	pCVP = model->CVp;
	pCVS = model->CVs;
	pKZP = model->kzp;
	pKZS = model->kzs;
	pGRduPSV = model->GRduPSV;
	pGRudPSV = model->GRudPSV;
	pEX = model->ex;
	//end: refer to variables in FKRTmodel
	//extrapolation operators for source
	dz = zSour - pZ[layerSour];
	rp=pKZP[layerSour];
	exds[0] = dcexp(dcrmul2(rp, dz));
	rp=pKZS[layerSour];
	exds[1] = dcexp(dcrmul2(rp, dz));
	dz = pZ[layerSour - 1] - zSour;
	rp=pKZP[layerSour];
	exus[0] = dcexp(dcrmul2(rp, dz));
	rp=pKZS[layerSour];
	exus[1] = dcexp(dcrmul2(rp, dz));
	//PSV
	rp=pKZP[layerSour];rp1=pKZS[layerSour];
	rp=dcmul2(rp, rp1);
	rp1=omega;
	rp=dcmul2(rp1, rp);
	rp1=pCVP[layerSour];
	temp1 = dcmul2(rp1, rp);
	rrp=2.*pMU[layerSour];
	rp=temp1;
	temp2 = dcrmul2(rp, rrp);
	rp=pCVS[layerSour];rp1=temp2;
	b_2uawrv = dcdiv2(rp, rp1);
	//temp1 = dcmul(b_2uawrv, dcmul(pKZP[layerSour], pKZS[layerSour]));
	//temp2 = dcrmul(temp1, k);
	//s0PSV[0] = dcmul(temp1, dcmul(pKZP[layerSour], pCVS[layerSour]));
	//s0PSV[1] = dcmul(temp2, dcneg(pCVP[layerSour]));
	//s2PSV[0] = dcmul(b_2uawrv, dcrmul(dcmul(pKZS[layerSour], pCVS[layerSour]), k*k));
	//s2PSV[1] = s0PSV[1];
	//following.s0PSV=original.s0PSV-original.s2PSV
	rp=pKZP[layerSour];rp1=dcmul2(rp, rp);
	rrp=-k*k;
	rp=dcradd2(rp1, rrp);
	rp1=pKZS[layerSour];rp2=pCVS[layerSour];
	rp1=dcmul2(rp1, rp2);
	rp=dcmul2(rp1, rp);
	rp1=b_2uawrv;
	s0PSV[0] = dcmul2(rp1, rp);
	s0PSV[1] = dcmplx2(0., 0.);
	//q
	if (zRecv <= zSour) {  //su
		//PSV
		dcmulRD22(pGRduPSV[layerSour], exds, Rdu);
		dcmulLD22(exds, Rdu, ExRdu);
		dcUnitAddOther22(ExRdu, UnitAddExRdu);
		for (i = 0; i < 2; i++) {
			rp=UnitAddExRdu[i * 2];
			rp1=s0PSV[0];
			sourPSV0[i] = dcmul2(rp, rp1);
		}
	}
	else {  //sd
		//PSV
		dcmulRD22(pGRudPSV[layerSour - 1], exus, Rud);
		dcmulLD22(exus, Rud, ExRud);
		dcUnitAddOther22(ExRud, UnitAddExRud);
		for (i = 0; i < 2; i++) {
			rp=UnitAddExRud[i * 2];rp1=s0PSV[0];
			sourPSV0[i] = dcmul2(rp, rp1);
		}
	}

	//PS
	//following.qPSV0=original.qPSV0-original.qPSV2
	for (i = 0; i < 2; i++) {
		rp=model->yPSV[i * 2];rp1=sourPSV0[0];rp2=model->yPSV[i * 2 + 1];rp3=sourPSV0[1];
		rp=dcmul2(rp, rp1);rp1=dcmul2(rp2, rp3);
		model->qPSV0[i] = dcadd2(rp, rp1);
	}

	return;
}

void calc_q_E0(FKRTmodel *model, const int layerSour, const double zSour, const double zRecv)
{
	//begin: declare variables in FKRTmodel
	double		k;
	dcomplex	omega;
	double		*pZ;
	double		*pMU;
	dcomplex	*pCVP;
	dcomplex	*pCVS;
	dcomplex	*pKZP;
	dcomplex	*pKZS;
	dcomplex	*pGRduSH;
	dcomplex	*pGRudSH;
	dcomplex	**pGRduPSV;
	dcomplex	**pGRudPSV;
	dcomplex	**pEX;
	//end: declare variables in FKRTmodel

	//local variables
	int i;
	double dz;
	dcomplex b_2uawrv, temp1, temp2;

	//temporary linear memory space
	dcomplex WorkSpace[64];
	dcomplex *exus, *exds;
	dcomplex *s0PSV, *s2PSV;
	dcomplex *Rdu, *Rud, *ExRdu, *ExRud;
	dcomplex *UnitAddExRdu, *UnitAddExRud;
	dcomplex *sourPSV0, *sourPSV1, *sourPSV2;

	exus = WorkSpace;
	exds = WorkSpace + 2;
	s0PSV = WorkSpace + 6;
	s2PSV = WorkSpace + 10;
	UnitAddExRdu = WorkSpace + 12;
	UnitAddExRud = WorkSpace + 20;
	Rdu = WorkSpace + 28;
	Rud = WorkSpace + 32;
	ExRdu = WorkSpace + 36;
	ExRud = WorkSpace + 40;
	sourPSV0 = WorkSpace + 44;
	sourPSV1 = WorkSpace + 46;
	sourPSV2 = WorkSpace + 48;

	//begin: refer to variables in FKRTmodel
	pZ = model->z;
	pMU = model->mu;
	omega = model->omega;
	k = model->k;
	pCVP = model->CVp;
	pCVS = model->CVs;
	pKZP = model->kzp;
	pKZS = model->kzs;
	pGRduSH = model->GRduSH;
	pGRudSH = model->GRudSH;
	pGRduPSV = model->GRduPSV;
	pGRudPSV = model->GRudPSV;
	pEX = model->ex;
	//end: refer to variables in FKRTmodel
	//extrapolation operators for source
	dz = zSour - pZ[layerSour];
	exds[0] = dcexp(dcrmul(pKZP[layerSour], dz));
	exds[1] = dcexp(dcrmul(pKZS[layerSour], dz));
	dz = pZ[layerSour - 1] - zSour;
	exus[0] = dcexp(dcrmul(pKZP[layerSour], dz));
	exus[1] = dcexp(dcrmul(pKZS[layerSour], dz));
	//PSV
	temp1 = dcmul(pCVP[layerSour], dcmul(omega, dcmul(pKZP[layerSour], pKZS[layerSour])));
	temp2 = dcrmul(temp1, 2.*pMU[layerSour]);
	b_2uawrv = dcdiv(pCVS[layerSour], temp2);
	temp1 = dcmul(b_2uawrv, dcmul(pKZP[layerSour], pKZS[layerSour]));
	temp2 = dcrmul(temp1, k);
	s0PSV[0] = dcmul(temp1, dcmul(pKZP[layerSour], pCVS[layerSour]));
	s0PSV[1] = dcmul(temp2, dcneg(pCVP[layerSour]));
	s2PSV[0] = dcmul(b_2uawrv, dcrmul(dcmul(pKZS[layerSour], pCVS[layerSour]), k*k));
	s2PSV[1] = s0PSV[1];
	//q
	if (zRecv <= zSour) {  //su
		//PSV
		dcmulRD22(pGRduPSV[layerSour], exds, Rdu);
		dcmulLD22(exds, Rdu, ExRdu);
		dcUnitAddOther22(ExRdu, UnitAddExRdu);
		for (i = 0; i < 2; i++) {
			sourPSV0[i] = dcadd(dcmul(UnitAddExRdu[i * 2], s0PSV[0]), dcmul(UnitAddExRdu[i * 2 + 1], s0PSV[1]));
			sourPSV2[i] = dcadd(dcmul(UnitAddExRdu[i * 2], s2PSV[0]), dcmul(UnitAddExRdu[i * 2 + 1], s2PSV[1]));
		}
	}
	else {  //sd
		//PSV
		dcmulRD22(pGRudPSV[layerSour - 1], exus, Rud);
		dcmulLD22(exus, Rud, ExRud);
		dcUnitAddOther22(ExRud, UnitAddExRud);
		for (i = 0; i < 2; i++) {
			sourPSV0[i] = dcadd(dcmul(UnitAddExRud[i * 2], s0PSV[0]), dcmul(UnitAddExRud[i * 2 + 1], s0PSV[1]));
			sourPSV2[i] = dcadd(dcmul(UnitAddExRud[i * 2], s2PSV[0]), dcmul(UnitAddExRud[i * 2 + 1], s2PSV[1]));
		}
	}
	//PS
	for (i = 0; i < 2; i++) {
		model->qPSV0[i] = dcadd(dcmul(model->yPSV[i * 2], sourPSV0[0]), dcmul(model->yPSV[i * 2 + 1], sourPSV0[1]));
		model->qPSV2[i] = dcadd(dcmul(model->yPSV[i * 2], sourPSV2[0]), dcmul(model->yPSV[i * 2 + 1], sourPSV2[1]));
	}

	return;
}
