#include "model.h"
#include <stdlib.h>
#include <errno.h>
#include <math.h>
#include <stdio.h>


void alloc_initialize_model(FKRTmodel *model, int allocLayers)
{
	int lay, item;
	double		*pZ;
	double		*pRHO;
	double		*pVP;
	double		*pVS;
	double		*pQP;
	double		*pQS;
	double		*pMU;
///////////// FOR VTI medium
    double  *pAA;
    double  *pFF;
    double  *pNN;
    double  *pCC;
    double  *pLL;
    dcomplex **pIEX;
    dcomplex *pSHKZS;
    dcomplex **pSVSHE;
    dcomplex **SHE;
///////////////
	dcomplex	*pCVP;
	dcomplex	*pCVS;
	dcomplex	*pKZP;
	dcomplex	*pKZS;
	dcomplex	*pTddSH;
	dcomplex	*pTuuSH;
	dcomplex	*pRduSH;
	dcomplex	*pRudSH;
	dcomplex	*pGTddSH;
	dcomplex	*pGTuuSH;
	dcomplex	*pGRduSH;
	dcomplex	*pGRudSH;
	dcomplex    **pTddPSV;
	dcomplex    **pTuuPSV;
	dcomplex    **pRduPSV;
	dcomplex    **pRudPSV;
	dcomplex    **pGTddPSV;
	dcomplex    **pGTuuPSV;
	dcomplex    **pGRduPSV;
	dcomplex    **pGRudPSV;
	dcomplex    **pEX;
	//allocate
//////// FOR VTI medium
    pAA= alloc1double(allocLayers );
	pFF= alloc1double(allocLayers );
	pNN= alloc1double(allocLayers );
	pCC= alloc1double(allocLayers );
	pLL= alloc1double(allocLayers );
    pIEX = alloc2dcomplex(2, allocLayers );
    pSHKZS = alloc1dcomplex(allocLayers );//eigvalue p
    SHE = alloc2dcomplex(4, allocLayers );
    pSVSHE = alloc2dcomplex(16, allocLayers );
////////

	pZ = alloc1double(allocLayers );
	pRHO = alloc1double(allocLayers );
	pVP = alloc1double(allocLayers );
	pVS = alloc1double(allocLayers );
	pQP = alloc1double(allocLayers );
	pQS = alloc1double(allocLayers );
	pMU = alloc1double(allocLayers );
	pCVP = alloc1dcomplex(allocLayers );
	pCVS = alloc1dcomplex(allocLayers );
	pKZP = alloc1dcomplex(allocLayers );
	pKZS = alloc1dcomplex(allocLayers );
	pTddSH = alloc1dcomplex(allocLayers );
	pTuuSH = alloc1dcomplex(allocLayers );
	pRduSH = alloc1dcomplex(allocLayers );
	pRudSH = alloc1dcomplex(allocLayers );
	pGTddSH = alloc1dcomplex(allocLayers );
	pGTuuSH = alloc1dcomplex(allocLayers );
	pGRduSH = alloc1dcomplex(allocLayers );
	pGRudSH = alloc1dcomplex(allocLayers );
	pTddPSV = alloc2dcomplex(4, allocLayers );
	pTuuPSV = alloc2dcomplex(4, allocLayers );
	pRduPSV = alloc2dcomplex(4, allocLayers );
	pRudPSV = alloc2dcomplex(4, allocLayers );
	pGTddPSV = alloc2dcomplex(4, allocLayers );
	pGTuuPSV = alloc2dcomplex(4, allocLayers );
	pGRduPSV = alloc2dcomplex(4, allocLayers );
	pGRudPSV = alloc2dcomplex(4, allocLayers );
	pEX = alloc2dcomplex(2, allocLayers );
	//scalar variables
	model->totalLayer = 0;
	model->k = 0.;
	model->omega = dcmplx(0., 0.);
	//initializing
///////////FOR VTI medium
    memset(pAA, 0, sizeof(double)*allocLayers );
	memset(pFF, 0, sizeof(double)*allocLayers );
	memset(pNN, 0, sizeof(double)*allocLayers );
	memset(pCC, 0, sizeof(double)*allocLayers );
	memset(pLL, 0, sizeof(double)*allocLayers );
    memset(pIEX[0], 0, sizeof(dcomplex) * 2 * allocLayers );
	memset(pSHKZS, 0, sizeof(dcomplex)*allocLayers );
    memset(SHE[0], 0, sizeof(dcomplex) * 4 * allocLayers );
    memset(pSVSHE[0], 0, sizeof(dcomplex) * 16 * allocLayers );
///////////
	memset(pZ, 0, sizeof(double)*allocLayers );
	memset(pRHO, 0, sizeof(double)*allocLayers );
	memset(pVP, 0, sizeof(double)*allocLayers );
	memset(pVS, 0, sizeof(double)*allocLayers );
	memset(pQP, 0, sizeof(double)*allocLayers );
	memset(pQS, 0, sizeof(double)*allocLayers);
	memset(pMU, 0, sizeof(double)*allocLayers );
	memset(pCVP, 0, sizeof(dcomplex)*allocLayers );
	memset(pCVS, 0, sizeof(dcomplex)*allocLayers );
	memset(pKZP, 0, sizeof(dcomplex)*allocLayers );
	memset(pKZS, 0, sizeof(dcomplex)*allocLayers );
	memset(pTddSH, 0, sizeof(dcomplex)*allocLayers );
	memset(pTuuSH, 0, sizeof(dcomplex)*allocLayers );
	memset(pRduSH, 0, sizeof(dcomplex)*allocLayers );
	memset(pRudSH, 0, sizeof(dcomplex)*allocLayers );
	memset(pGTddSH, 0, sizeof(dcomplex)*allocLayers );
	memset(pGTuuSH, 0, sizeof(dcomplex)*allocLayers );
	memset(pGRduSH, 0, sizeof(dcomplex)*allocLayers );
	memset(pGRudSH, 0, sizeof(dcomplex)*allocLayers );
	memset(pTddPSV[0], 0, sizeof(dcomplex) * 4 * allocLayers );
	memset(pTuuPSV[0], 0, sizeof(dcomplex) * 4 * allocLayers );
	memset(pRduPSV[0], 0, sizeof(dcomplex) * 4 * allocLayers );
	memset(pRudPSV[0], 0, sizeof(dcomplex) * 4 * allocLayers );
	memset(pGTddPSV[0], 0, sizeof(dcomplex) * 4 * allocLayers );
	memset(pGTuuPSV[0], 0, sizeof(dcomplex) * 4 * allocLayers );
	memset(pGRduPSV[0], 0, sizeof(dcomplex) * 4 * allocLayers );
	memset(pGRudPSV[0], 0, sizeof(dcomplex) * 4 * allocLayers );
	memset(pEX[0], 0, sizeof(dcomplex) * 2 * allocLayers );
	//vector pointer to model
	model->z = pZ;
	model->Rho = pRHO;
	model->Vp = pVP;
	model->Vs = pVS;
	model->Qp = pQP;
	model->Qs = pQS;
	model->mu = pMU;
	//complex vectors variables
	model->CVp = pCVP;
	model->CVs = pCVS;
	model->kzp = pKZP;
	model->kzs = pKZS;
	model->TddSH = pTddSH;
	model->TuuSH = pTuuSH;
	model->RduSH = pRduSH;
	model->RudSH = pRudSH;
	model->GTddSH = pGTddSH;
	model->GTuuSH = pGTuuSH;
	model->GRduSH = pGRduSH;
	model->GRudSH = pGRudSH;
	model->TddPSV = pTddPSV;
	model->TuuPSV = pTuuPSV;
	model->RduPSV = pRduPSV;
	model->RudPSV = pRudPSV;
	model->GTddPSV = pGTddPSV;
	model->GTuuPSV = pGTuuPSV;
	model->GRduPSV = pGRduPSV;
	model->GRudPSV = pGRudPSV;
	model->ex = pEX;

  /// VTI
  model->AA=pAA;
  model->FF=pFF;
  model->NN=pNN;
  model->CC=pCC;
  model->LL=pLL;
  model->iex=pIEX;
  model->shkzs=pSHKZS;
  model->shE=SHE;
  model->psvshE=pSVSHE;
}

void dealloc_model(FKRTmodel *model)
{
	free1double(model->z);
	free1double(model->Rho);
	free1double(model->Vp);
	free1double(model->Vs);
	free1double(model->Qp);
	free1double(model->Qs);
	free1double(model->mu);
	/////////////FOR VTI meidium
    free1double(model->AA);
	free1double(model->FF);
	free1double(model->NN);
	free1double(model->CC);
	free1double(model->LL);
    free2dcomplex(model->iex);
    free1dcomplex(model->shkzs);
    free2dcomplex(model->shE);
    free2dcomplex(model->psvshE);
	//complex vectors variables
	free1dcomplex(model->CVp);
	free1dcomplex(model->CVs);
	free1dcomplex(model->kzp);
	free1dcomplex(model->kzs);
	free1dcomplex(model->TddSH);
	free1dcomplex(model->TuuSH);
	free1dcomplex(model->RduSH);
	free1dcomplex(model->RudSH);
	free1dcomplex(model->GTddSH);
	free1dcomplex(model->GTuuSH);
	free1dcomplex(model->GRduSH);
	free1dcomplex(model->GRudSH);
	free2dcomplex(model->TddPSV);
	free2dcomplex(model->TuuPSV);
	free2dcomplex(model->RduPSV);
	free2dcomplex(model->RudPSV);
	free2dcomplex(model->GTddPSV);
	free2dcomplex(model->GTuuPSV);
	free2dcomplex(model->GRduPSV);
	free2dcomplex(model->GRudPSV);
	free2dcomplex(model->ex);
}

void input_physical_model(FKRTmodel *model, const char *filemodel,int mediatype)
{
	char tempstr[1024];
	int total_layers, lay, i;
	double z, rho, vp, vs, qp, qs;
	FILE *pFile;
	double		*pZ;
	double		*pRHO;
	double		*pVP;
	double		*pVS;
	double		*pQP;
	double		*pQS;
	double		*pMU;
///////////////////for VTI medium///////////
  double aa,ff,nn,cc,ll;
  double   *pAA;
  double   *pFF;
  double   *pNN;
  double   *pCC;
  double   *pLL;

  ////////////////////////////////////////
	if ((pFile = fopen(filemodel, "r")) == NULL) 
  {
		printf("Model file could not be opened.\n");
		exit(EXIT_FAILURE);
	}
	else 
  {

		if (!feof(pFile)) fgets(tempstr, 1024, pFile);
		if (!feof(pFile)) fscanf(pFile, "%d", &total_layers);
		if (!feof(pFile)) fgets(tempstr, 1024, pFile);
		if (total_layers < 1) 
        {
			printf("Model layers <1.\n");
			exit(EXIT_FAILURE);
		}

		alloc_initialize_model(model, total_layers + 2); //add a fictitious layer below the deepest point

      // isotropy media
		if(mediatype==1)
		{
		//pointer to model
		model->media=mediatype;
		pZ = model->z;
		pRHO = model->Rho;
		pVP = model->Vp;
		pVS = model->Vs;
		pQP = model->Qp;
		pQS = model->Qs;
		pMU = model->mu;
		if (!feof(pFile)) fgets(tempstr, 1024, pFile);
		for (lay = 1; lay <= total_layers; lay++) 
        {
			if (feof(pFile))
            {
				printf("Model file is erroneous.\n");
				exit(EXIT_FAILURE);
			}
			fscanf(pFile, "%d %lf %lf %lf %lf %lf %lf", &i, &z, &rho, &vs, &vp, &qp, &qs);
			if (!feof(pFile)) fgets(tempstr, 1024, pFile);
			pZ[lay - 1] = z/1000.;
			pRHO[lay] = rho/1000.;
			pVP[lay] = vp/1000.;
			pVS[lay] = vs/1000.;
			pQP[lay] = qp;
			pQS[lay] = qs;
			pMU[lay] = rho/1000.*vs/1000.*vs/1000;
						
		}
		model->totalLayer = total_layers + 1;
		lay = total_layers+1;
		pZ[lay - 1] = pZ[lay - 2]+1000000;
		pRHO[lay] = pRHO[lay-1];
		pVP[lay] = pVP[lay-1];
		pVS[lay] = pVS[lay-1];
		pQP[lay] = pQP[lay-1];
		pQS[lay] = pQS[lay-1];
		pMU[lay] = pMU[lay-1];
	}
	else // VTI
	{
		        model->media=0;
	           	pZ = model->z;
                pAA = model->AA;
          		pFF = model->FF;
          		pNN = model->NN;
          		pCC = model->CC;
          		pLL = model->LL;
              
                pVP = model->Vp;
	            pVS = model->Vs;
             	pQP = model->Qp;
            	pQS = model->Qs;
            	pMU = model->mu;
          	   	pRHO = model->Rho;
          	   	if (!feof(pFile)) fgets(tempstr, 1024, pFile);
          	   for (lay = 1; lay <= total_layers; lay++) 
              {

		       	if (feof(pFile))
               {
			     	printf("Model file is erroneous.\n");
			     	exit(EXIT_FAILURE);
		      	}
		          	fscanf(pFile, "%d %lf %lf %lf %lf %lf %lf %lf %lf %lf", &i, &z, &aa, &ff, &nn, &cc, &ll,&rho,&qp,&qs);
		          	if (!feof(pFile)) fgets(tempstr, 1024, pFile);
		          	pZ[lay - 1] = z/1000;
		            pRHO[lay] = rho/1000.;
              	    pAA[lay] = aa;
		          	pFF[lay] = ff;
		          	pNN[lay] = nn;
		          	pCC[lay] = cc+0.0000001;
		          	pLL[lay] = ll;
					//printf("%lf %lf %lf %lf %lf %lf %lf %lf %lf\n",aa,ff,nn,cc,ll,z,rho/1000,qp,qs);
                    pQP[lay] = qp;
          			pQS[lay] = qs;
                if(aa>cc)
                {
       	       	pVP[lay] =sqrt(aa/rho*1000.);  
       	       	
                }
                else
                {
                 	pVP[lay] =sqrt(cc/rho*1000.);  

                }

                if(ll>nn)
                {
                 	pVS[lay] = sqrt(nn/rho*1000.);
                }
                else
                {
                	pVS[lay] = sqrt(ll/rho*1000.);

                }
                pMU[lay] = rho*(1/.1000)*pVS[lay]*pVS[lay];

//printf("%lf %lf\n",pVS[lay],pVP[lay] );
	        }
            model->totalLayer = total_layers + 1;
		    lay = total_layers+1;
		    pZ[lay - 1] = pZ[lay - 2]+1000000;
			pAA[lay] = pAA[lay-1];
			pFF[lay] = pFF[lay-1];
			pNN[lay] = pNN[lay-1];
			pCC[lay] = pCC[lay-1];
			pLL[lay] = pLL[lay-1];
            pVP[lay] = pVP[lay-1];
			pVS[lay] = pVS[lay-1];
			pRHO[lay] = pRHO[lay-1];
  	        pQP[lay] = pQP[lay-1];
			pQS[lay] = pQS[lay-1];
          	pMU[lay] = pMU[lay-1];


	}//media

	}
	fclose(pFile);
	return;
}

/**
compute the layer number of arbitrary depth
**/
int get_layernumber(const FKRTmodel *model, const double depth)
{
	int			totalLayer;
	double		*pZ;
	int layernumber, i;

	totalLayer = model->totalLayer;
	pZ = model->z;

	if (depth < pZ[0]) {
		printf("The point is not located in the valid layer.");
		exit(EXIT_FAILURE);
	}

	for (i = totalLayer - 1; i >= 0; i--) {
		if (depth > pZ[i]) {
			layernumber = i + 1;
			break;
		}
	}
	if (depth == pZ[0]) {
		layernumber = 1;
	}

	return layernumber;
}

void get_max_min_velocity(const FKRTmodel *model, double *velmax, double *velmin)
{
	int			totalLayer;
	double		*pVs, *pVp;
	int i;

	totalLayer = model->totalLayer;
	pVs = model->Vs;
	pVp = model->Vp;

	*velmax = pVp[1];
	*velmin = pVs[1];

	for (i = 2; i <= totalLayer; i++) {
		if (pVp[i] > *velmax) *velmax = pVp[i];
		if (pVs[i] < *velmin) *velmin = pVs[i];
	}
	return;
}

double get_critical_k(FKRTmodel *model, dcomplex omagemin, int nf,
	int layerSour, int layerRecv, double zSour, double zRecv)
{
	int lay;
	double kmax, wnmax, dzmin, temp1, temp2;
	double		*pZ;
	dcomplex omega;
	dcomplex	*pCVP;
	dcomplex	*pCVS;
	omega = model->omega;
	pZ = model->z;
	pCVP = model->CVp;
	pCVS = model->CVs;
	if (nf <= 3) omega = omagemin;
	if (layerRecv == layerSour - 1) {
		wnmax = MAX(drcabs(dcdiv(omega, pCVS[layerSour])), drcabs(dcdiv(omega, pCVS[layerRecv])));
		dzmin = MIN(zSour - pZ[layerRecv], pZ[layerRecv] - zRecv);
	}
	else if (layerRecv == layerSour) 
	{
		/*printf("%lf\n", omega.r);
		printf("%lf\n", omega.i);
		printf("%lf\n", pCVS[layerSour].i);
		printf("%lf\n", pCVS[layerSour].r);
		printf("%lf\n", dzmin);*/

		wnmax = drcabs(dcdiv(omega, pCVS[layerSour]));
		dzmin = fabs(zSour - zRecv);
	
	}
	else if (layerRecv == layerSour + 1) {
		wnmax = MAX(drcabs(dcdiv(omega, pCVS[layerSour])), drcabs(dcdiv(omega, pCVS[layerRecv])));
		dzmin = MIN(pZ[layerSour] - zSour, zRecv - pZ[layerSour]);
	}
	else if (layerRecv < layerSour - 1) {
		wnmax = MAX(drcabs(dcdiv(omega, pCVS[layerSour])), drcabs(dcdiv(omega, pCVS[layerRecv])));
		dzmin = MIN(zSour - pZ[layerSour - 1], pZ[layerRecv] - zRecv);
		for (lay = layerRecv + 1; lay <= layerSour - 1; lay++) {
			temp1 = drcabs(dcdiv(omega, pCVS[lay]));
			temp2 = pZ[lay] - pZ[lay - 1];
			if (wnmax < temp1)  wnmax = temp1;
			if (dzmin > temp2) dzmin = temp2;
		}
	}
	else if (layerRecv > layerSour + 1) {
		wnmax = MAX(drcabs(dcdiv(omega, pCVS[layerSour])), drcabs(dcdiv(omega, pCVS[layerRecv])));
		dzmin = MIN(pZ[layerSour] - zSour, zRecv - pZ[layerRecv - 1]);
		for (lay = layerRecv + 1; lay <= layerSour - 1; lay++) {
			temp1 = drcabs(dcdiv(omega, pCVS[lay]));
			temp2 = pZ[lay] - pZ[lay - 1];
			if (wnmax < temp1)  wnmax = temp1;
			if (dzmin > temp2) dzmin = temp2;
		}
	}

	if (dzmin < 0.2) {
		if (nf < 10) {
			kmax = MIN(wnmax + 2.0, 20.*wnmax);
		}
		else {
			kmax = MIN(wnmax + 2.0, 2.*wnmax);
		}
	}
	else {
		kmax = sqrt(9.0 / dzmin / dzmin + wnmax*wnmax);
	}
	if (kmax - wnmax < 0.5) kmax = wnmax + 0.5;

	return kmax;
}

void set_complex_frequency_variables(FKRTmodel *model, double freq, double iomega, double freq_reference)
{
	int totalLayer, lay;
	dcomplex omega_r, omega, cs, cp, temp1;
	double *pVs, *pVp, *pQs, *pQp;
	dcomplex *pCVS, *pCVP;
	//get from model
	totalLayer = model->totalLayer;
	pVs = model->Vs;
	pVp = model->Vp;
	pQs = model->Qs;
	pQp = model->Qp;
	pCVS = model->CVs;
	pCVP = model->CVp;
	//set to model
	omega = dcmplx(PI2*freq, -iomega);
	model->omega = omega;
	omega_r = dcmplx(PI2*freq_reference, 0.);
	temp1 = dclog(dcdiv(omega, omega_r));
	for (lay = 1; lay <= totalLayer; lay++) {
		cs = dcdiv(drcsub(1.0, dcrmul(temp1, 1. / PI / pQs[lay])), dcmplx(1, -0.5 / pQs[lay]));
		cp = dcdiv(drcsub(1.0, dcrmul(temp1, 1. / PI / pQp[lay])), dcmplx(1, -0.5 / pQp[lay]));
		pCVS[lay] = drcdiv(pVs[lay], cs);
		pCVP[lay] = drcdiv(pVp[lay], cp);
		//pCVS[lay] = dcmplx(pVs[lay], 0.);
		//pCVP[lay] = dcmplx(pVp[lay], 0.);
		//printf("%lf\n",pQs[lay] );
		//printf("%lf\n",pQp[lay] );
	}
}

void set_wavenumber_variables(FKRTmodel *model, double k)
{
	int totalLayer, lay,i;
	dcomplex omega2,omega1,omega3;;
	dcomplex *pCVS, *pCVP;
	dcomplex *pKZS, *pKZP,*pSHKZS,**SHE,**pSVSHE;
	dcomplex eig2[2],eig2vector[4],eig4[4],eig4vector[16];
	//get from model
	totalLayer = model->totalLayer;
	omega2 = model->omega;
	omega1=omega2;
	omega3 = dcmul(omega2, omega2);
	pCVS = model->CVs;
	pCVP = model->CVp;
	pKZS = model->kzs;
	pKZP = model->kzp;

    pSHKZS=model->shkzs;
  	SHE=model->shE;
  	pSVSHE=model->psvshE;
	//set to model
	model->k = k;
//printf("%lf %lf %lf\n",k,model->omega.r,model->omega.i );
//exit(0);
	for (lay = 1; lay <= totalLayer; lay++)
	{

		if (model->media==1)
		{
		pKZS[lay] = dcsqrt(drcsub(k*k, dcdiv(omega3, dcmul(pCVS[lay], pCVS[lay]))));
		pKZP[lay] = dcsqrt(drcsub(k*k, dcdiv(omega3, dcmul(pCVP[lay], pCVP[lay]))));
		if (pKZS[lay].r < 0.) pKZS[lay] = dcneg(pKZS[lay]);
		if (pKZP[lay].r < 0.) pKZP[lay] = dcneg(pKZP[lay]);
		}
		else
		{
	       eig22(model,omega1,k,eig2,eig2vector,lay);

        	if(eig2[0].r>0)
        	{
        		pSHKZS[lay]=eig2[0];
        
        	}
        	else
        	{ 
        		pSHKZS[lay]=eig2[1];
        
        	}
        ////
        	for(i=0;i<4;i++)
        	{
        		SHE[lay][i]=eig2vector[i];
        //printf("%lf %lf\n",SHE[lay][i].r,SHE[lay][i].i);
        	}
       
        ////
       		eig44(model,omega1,k,eig4,eig4vector,lay);
        	if(eig4[3].r>0)
        	{
        		pKZS[lay]=eig4[3];
        	}
        	else
        	{ 
        		pKZS[lay]=eig4[1];
        	}
        	if(eig4[2].r>0)
        	{
        		pKZP[lay]=eig4[2];
        	}
        	else
        	{
        	 pKZP[lay]=eig4[0];
        	}
        	for(i=0;i<16;i++)
       		{
        		pSVSHE[lay][i]=eig4vector[i];
           //printf("Vpkzpeig==%lf %lf\n",pSVSHE[lay][i].r,pSVSHE[lay][i].i);
	
        	}
//exit(0);
		}

	}
}
