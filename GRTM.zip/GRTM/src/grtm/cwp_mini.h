//modified from cwp.h

/* Copyright (c) Colorado School of Mines, 2011.*/
/* All rights reserved.                       */

/* cwp.h - include file for general purpose CWP stuff */

#ifndef CWP_MINI_H
#define CWP_MINI_H

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

#ifndef PI
#define PI (double) (3.1415926535897932385)
#endif

#ifndef D_PI 
#define D_PI (double) (3.1415926535897932385)
#endif

#ifndef PI2
#define PI2 (double)  (6.283185307179586477)
#endif

#ifndef SGN
#define SGN(x) ((x) < 0 ? -1.0 : 1.0)
#endif
#ifndef ABS
#define ABS(x) ((x) < 0 ? -(x) : (x))
#endif
#ifndef MAX
#define	MAX(x,y) ((x) > (y) ? (x) : (y))
#endif
#ifndef MIN
#define	MIN(x,y) ((x) < (y) ? (x) : (y))
#endif

#ifndef dcomplex
typedef struct _dcomplexStruct { /* double-precision complex number */
	double r, i;
} dcomplex;
#endif/* dcomplex */

#ifndef dcmul2
#define dcmul2(a,b) ({dcomplex c=a;(c.r)=((a.r)*(b.r))+(-(a.i)*(b.i));(c.i)=(((a.i)*(b.r))+((b.i)*(a.r)));(c);})
#endif

#ifndef dcrmul2
#define dcrmul2(a,b) ({(a.r)=((a.r)*(b));(a.i)=((a.i)*(b));(a);})
#endif

#ifndef dcadd2
#define dcadd2(a,b) ({(a.r)=((a.r)+(b.r));(a.i)=((a.i)+(b.i));a;})
#endif

#ifndef dcneg2
#define dcneg2(a) ({(a.r)=(-a.r);(a.i)=(-a.i);a;})
#endif

#ifndef drcabs2
#define drcabs2(a) ({ double s=((a.r*a.r)+(a.i*a.i));sqrt(s);})
#endif

#ifndef dcsub2
#define dcsub2(a,b) ({(a.r)=((a.r)-(b.r));(a.i)=((a.i)-(b.i));a;})
#endif

#ifndef drcsub2
#define drcsub2(a,b) ({(b.r)=(a-(b.r));(b.i)=(-(b.i));b;})
#endif

#ifndef dcradd2
#define dcradd2(a,b) ({(a.r)=((a.r)+(b));a;})
#endif

#ifndef dcmplx2
#define dcmplx2(a,b) ({dcomplex c;(c.r)=(a);c.i=b;c;})
#endif

#ifndef dcdiv2
#define dcdiv2(a,b) ({double s=((b.r)*(b.r))+((b.i)*(b.i));dcomplex c;(c.r)=(((a.r)*(b.r))+((a.i)*(b.i)))/(s);(c.i)=(((a.i)*(b.r))-((a.r)*(b.i)))/(s);c;})
#endif

#ifndef dcinv2
#define dcinv2(a) ({double s=1.0/((a.r*a.r)+(a.i*a.i));(a.r)=(a.r)*(s);a.i=(-a.i)*(s);a;})
#endif
/* allocate and free multi-dimensional arrays */
void *alloc1(size_t n1, size_t size);
void *realloc1(void *v, size_t n1, size_t size);
void **alloc2(size_t n1, size_t n2, size_t size);
void ***alloc3(size_t n1, size_t n2, size_t n3, size_t size);
void ****alloc4(size_t n1, size_t n2, size_t n3, size_t n4, size_t size);
void *****alloc5(size_t n1, size_t n2, size_t n3, size_t n4, size_t n5, size_t size);
void ******alloc6(size_t n1, size_t n2, size_t n3, size_t n4, size_t n5, size_t n6,
	size_t size);

void free1(void *p);
void free2(void **p);
void free3(void ***p);
void free4(void ****p);
void free5(void *****p);
void free6(void ******p);
int *alloc1int(size_t n1);
int *realloc1int(int *v, size_t n1);
int **alloc2int(size_t n1, size_t n2);
int ***alloc3int(size_t n1, size_t n2, size_t n3);
float *alloc1float(size_t n1);
float *realloc1float(float *v, size_t n1);
float **alloc2float(size_t n1, size_t n2);
float ***alloc3float(size_t n1, size_t n2, size_t n3);

float ****alloc4float(size_t n1, size_t n2, size_t n3, size_t n4);
void free4float(float ****p);
float *****alloc5float(size_t n1, size_t n2, size_t n3, size_t n4, size_t n5);
void free5float(float *****p);
float ******alloc6float(size_t n1, size_t n2, size_t n3, size_t n4, size_t n5, size_t n6);
void free6float(float ******p);
int ****alloc4int(size_t n1, size_t n2, size_t n3, size_t n4);
void free4int(int ****p);
int *****alloc5int(size_t n1, size_t n2, size_t n3, size_t n4, size_t n5);
void free5int(int *****p);

double *alloc1double(size_t n1);
double *realloc1double(double *v, size_t n1);
double **alloc2double(size_t n1, size_t n2);
double ***alloc3double(size_t n1, size_t n2, size_t n3);

dcomplex *alloc1dcomplex(size_t n1);
dcomplex *realloc1dcomplex(dcomplex *v, size_t n1);
dcomplex **alloc2dcomplex(size_t n1, size_t n2);
dcomplex ***alloc3dcomplex(size_t n1, size_t n2, size_t n3);

void free1int(int *p);
void free2int(int **p);
void free3int(int ***p);

void free1float(float *p);
void free2float(float **p);
void free3float(float ***p);

void free1double(double *p);
void free2double(double **p);
void free3double(double ***p);

void free1dcomplex(dcomplex *p);
void free2dcomplex(dcomplex **p);
void free3dcomplex(dcomplex ***p);

/* double complex */
dcomplex dcadd(dcomplex a, dcomplex b);
dcomplex dcsub(dcomplex a, dcomplex b);
dcomplex dcmul(dcomplex a, dcomplex b);
dcomplex dcdiv(dcomplex a, dcomplex b);
double drcabs(dcomplex z);
dcomplex dcmplx(double re, double im);
dcomplex dconjg(dcomplex z);
dcomplex dcneg(dcomplex z);
dcomplex dcinv(dcomplex z);
dcomplex dcsqrt(dcomplex z);
dcomplex dcexp(dcomplex z);
dcomplex dcrmul(dcomplex a, double x);
/* double complex functions */
dcomplex dclog(dcomplex a);
/*add by luhy*/
dcomplex dclog(dcomplex a);
dcomplex dcradd(dcomplex a, double x);
dcomplex drcsub(double x, dcomplex b);
dcomplex drcdiv(double x, dcomplex b);


#endif /* CWP_H */
