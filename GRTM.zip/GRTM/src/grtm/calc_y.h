#pragma once

#include "model.h"

void calc_Y(FKRTmodel *model, const int layerSour, const int layerRecv,
	const double zSour, const double zRecv);