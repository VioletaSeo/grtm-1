#include "green_spectra.h"
#include "model.h"
#include "source_and_receiver.h"
#include "dwim.h"
#include "integral_function_coeff.h"
#include "periodic_convergence.h"
#include <math.h>
#include <stdio.h>
//Green function of one pair(source, receiver)
void green_spectra_S(FKRTmodel *model, double df, int nfreqBeg, int nfreqEnd,
	double iomega, double freq_reference, double dk,
	const SourPara *source, const RecvStat *recvstat,
	dcomplex *ur, dcomplex *ut, dcomplex *uz, char *PeriodCheck,dcomplex *urd, dcomplex *utd, dcomplex *uzd)
{
	//source and receiver information
	double r0, zSour, zRecv;
	int layerSour, layerRecv;
	//radiaction pattern
	RadPat_S  radpat;
	//f-k
	double kmin, kcritical, kn, freq, dk_2;
	//for periodic convergence
	int counter, flagSearchCycle[12], numCycle[12];
	int convergence;
	double condition;
	int flag0or1[7];
	int flagZero[3];
	//bessel and integral
	double j0, j1, j0d, j1d,j2,j3,j2d;
	dcomplex fun[7],fund[14];
	dcomplex tmpU[3], sumU[3],sumUd[3];
	dcomplex integterm_last[3],integterm_lastd[3];
	dcomplex integterm_new[3],integterm_newd[3];
	//temporary
	int i, ifreq;
	dcomplex dctemp, dctemp2;

	r0 = recvstat->distance;
	zSour = source->depth;
	zRecv = recvstat->depth;
	layerSour = source->layer;
	layerRecv = recvstat->layer;
	//source radiation pattern
	calc_R_S(recvstat->azimuth, source->para[INDEX_NX], source->para[INDEX_NY], source->para[INDEX_NZ], &radpat);
	for (i = 0; i < 7; i++) {
		flag0or1[i] = 1;
	}
	if (fabs(radpat.rpsv1) < ZEROSOURCE) {
		radpat.rpsv1 = 0.;
		flag0or1[0] = 0;
		flag0or1[2] = 0;
		flag0or1[6] = 0;
	}
	if (fabs(radpat.rpsv0) < ZEROSOURCE) {
		radpat.rpsv0 = 0.;
		flag0or1[1] = 0;
		flag0or1[5] = 0;
	}
	if (fabs(radpat.rsh1) < ZEROSOURCE) {
		radpat.rsh1 = 0.;
		flag0or1[3] = 0;
		flag0or1[4] = 0;
	}
	flagZero[0] = flag0or1[0] + flag0or1[1] + flag0or1[2];
	flagZero[1] = flag0or1[3] + flag0or1[4];
	flagZero[2] = flag0or1[5] + flag0or1[6];
	//calculation start...
	for (ifreq = nfreqBeg; ifreq <= nfreqEnd; ifreq++) {
//printf("ifreq: %d\n", nfreqEnd);
//       for (ifreq = 200; ifreq <= 209; ifreq++) {
//		printf("ifreq: %d\n", ifreq);
		freq = ifreq*df;
		set_complex_frequency_variables(model, freq, iomega, freq_reference);

		dctemp = dcmplx(PI2*df*3., -iomega);
		kcritical = get_critical_k(model, dctemp, ifreq, layerSour, layerRecv, zSour, zRecv);
		kcritical=kcritical;
		//discrete wavenumber integration
		DWIM_S(model, &radpat, 0., kcritical, dk,
			layerSour, layerRecv, zSour, zRecv, r0, sumU, integterm_last,sumUd, integterm_lastd);

		if (!strcmp(PeriodCheck, "ON")) {
			//convergence judge
			condition = CONVERGENCE_THRESH;
			convergence = 0; //0-convergence, 1-nonconvergence
			if (drcabs(model->qSH1) > condition) convergence = 1;
			for (i = 0; i < 2; i++) {
				if (drcabs(model->qPSV0[i]) > condition) convergence = 1;
				if (drcabs(model->qPSV1[i]) > condition) convergence = 1;
			}
			//periodic_convergence integration calculation
			kn = kcritical;
			dk_2 = dk / 2.;
			counter = 0;
			for (i = 0; i < 12; i++) {
				numCycle[i] = 0;
				flagSearchCycle[i] = 1;
			}
			//while (0) {
			while (convergence != 0 && counter <MAXCYCLECHECKTIME) {
			//while (convergence != 0) {
				kn = kn + dk;
				integral_function_coeff_S(kn, model, &radpat, layerSour, layerRecv, zSour, zRecv, fun,fund);
				BesselJ01d(r0*kn, &j0, &j1, &j0d, &j1d,&j2,&j3,&j2d);
                integration_S(integterm_new, fun, j0, j1, j0d, j1d,j2,j3,j2d,integterm_newd, fund);
				for (i = 0; i < 3; i++) {
					sumU[i] = dcadd(sumU[i], dcrmul(dcadd(integterm_last[i], integterm_new[i]), dk_2));
					integterm_last[i] = integterm_new[i];
				}
				periodic_convergence(kn, sumU, flagZero, &convergence, &counter, numCycle, flagSearchCycle);
			}
		}
		///////////// for curl /////////////
		if (!strcmp(PeriodCheck, "ON")) 
     
		    {
			//convergence judge
			condition = CONVERGENCE_THRESH;
			convergence = 0; //0-convergence, 1-nonconvergence
			if (drcabs(model->qSH1) > condition) convergence = 1;
			for (i = 0; i < 2; i++) 
		      {
				if (drcabs(model->qPSV0[i]) > condition) convergence = 1;
				if (drcabs(model->qPSV1[i]) > condition) convergence = 1;
			}
			//periodic_convergence integration calculation
			kn = kcritical;
			dk_2 = dk / 2.;
			counter = 0;
			for (i = 0; i < 12; i++) 
		      {
				numCycle[i] = 0;
				flagSearchCycle[i] = 1;
			}
			//while (0) {
			while (convergence != 0 && counter <MAXCYCLECHECKTIME) //
		      {
		//	while (convergence != 0) {
				kn = kn + dk;
				integral_function_coeff_S(kn, model, &radpat, layerSour, layerRecv, zSour, zRecv, fun,fund);
				BesselJ01d(r0*kn, &j0, &j1, &j0d, &j1d,&j2,&j3,&j2d);
                integration_S(integterm_new, fun, j0, j1, j0d, j1d,j2,j3,j2d,integterm_newd, fund);
				for (i = 0; i < 3; i++) 
       			 {
					sumUd[i] = dcadd(sumUd[i], dcrmul(dcadd(integterm_lastd[i], integterm_newd[i]), dk_2));
					integterm_lastd[i] = integterm_newd[i];
				}
				periodic_convergence(kn, sumUd, flagZero, &convergence, &counter, numCycle, flagSearchCycle);
			}
		}
		ur[ifreq] = sumU[0];
		ut[ifreq] = sumU[1];
		uz[ifreq] = sumU[2];
		urd[ifreq] = sumUd[0];
		utd[ifreq] = sumUd[1];
		uzd[ifreq] = sumUd[2];
/*		printf("%lf %lf\n",sumUd[1].r,sumUd[1].i);
		printf("%lf %lf\n",sumUd[0].r,sumUd[0].i);
		printf("%lf %lf\n",sumUd[2].r,sumUd[2].i);*/
	}
}
