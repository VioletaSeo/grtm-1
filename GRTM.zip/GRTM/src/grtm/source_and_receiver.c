#include "source_and_receiver.h"
#include <ctype.h>
#include "cwp_mini.h"
#include "model.h"

void calc_source_parameters_D(SourPara *source, const FKRTmodel *model)
{
	int layer;
	layer = get_layernumber(model, source->depth);
	source->amplitude = source->para[INDEX_A0S]*source->para[INDEX_D0S]*model->mu[layer];
	source->layer = layer;
}

void calc_source_parameters_S(SourPara *source, const FKRTmodel *model)
{
	int layer;
	layer = get_layernumber(model, source->depth);
	source->layer = layer;
}

void calc_source_parameters_E(SourPara *source, const FKRTmodel *model)
{
	int layer;
	layer = get_layernumber(model, source->depth);
	source->layer = layer;
}

void calc_source_parameters_M(SourPara *source, const FKRTmodel *model)
{
	int layer;
	layer = get_layernumber(model, source->depth);
	source->layer = layer;
}

void calc_receiver_parameters(RecvStat *recvstat, const FKRTmodel *model)
{
	recvstat->layer = get_layernumber(model, recvstat->depth);
}

void calc_R_D(double azimuth, double dip, double rake, double strike, RadPat_D *R)
{
	double fai, fai2;
	fai = azimuth - strike;
	fai2 = 2.*fai;
	R->rsh1 = -cos(2. * dip)*sin(rake)*cos(fai) - cos(dip)*cos(rake)*sin(fai);
	R->rsh2 = sin(dip)*(cos(rake)*cos(fai2) - cos(dip)*sin(rake)*sin(fai2));
	R->rpsv1 = cos(2. * dip)*sin(rake)*sin(fai) - cos(dip)*cos(rake)*cos(fai);
	R->rpsv2 = sin(dip)*(cos(rake)*sin(fai2) + cos(dip)*sin(rake)*cos(fai2));
	R->rpsv01 = -sin(dip)*cos(dip)*sin(rake);
	R->rpsv02 = -2.*R->rpsv01;
	///////// for curl //// derivative ///////////
		R->rsh1d = cos(2. * dip)*sin(rake)*sin(fai) - cos(dip)*cos(rake)*cos(fai);
		R->rsh2d = sin(dip)*(cos(rake)*(-2.*sin(fai2)) - cos(dip)*sin(rake)*2.*cos(fai2));
		R->rpsv1d = cos(2. * dip)*sin(rake)*cos(fai) + cos(dip)*cos(rake)*sin(fai);
		R->rpsv2d = sin(dip)*(cos(rake)*2.*cos(fai2) - cos(dip)*sin(rake)*2.*sin(fai2));
		R->rpsv01d =0;
		R->rpsv02d =0;
}

void calc_R_M(double azimuth, const SourPara *source, RadPat_D *R)
{
	double dip, rake, strike;
	double fai, fai2;
	double mxx, myy, mzz, mxy, mxz, myz;
	if (source->SourceType == 'D') {
		dip = source->para[INDEX_DIP];
		rake = source->para[INDEX_RAKE];
		strike = source->para[INDEX_STRIKE];
		fai = azimuth - strike;
		fai2 = 2.*fai;
		R->rsh1 = -cos(2. * dip)*sin(rake)*cos(fai) - cos(dip)*cos(rake)*sin(fai);
		R->rsh2 = sin(dip)*(cos(rake)*cos(fai2) - cos(dip)*sin(rake)*sin(fai2));
		R->rpsv1 = cos(2. * dip)*sin(rake)*sin(fai) - cos(dip)*cos(rake)*cos(fai);
		R->rpsv2 = sin(dip)*(cos(rake)*sin(fai2) + cos(dip)*sin(rake)*cos(fai2));
		R->rpsv01 = -sin(dip)*cos(dip)*sin(rake);
		R->rpsv02 = -2.*R->rpsv01;
        ///////// for curl //// derivative ///////////
		R->rsh1d = cos(2. * dip)*sin(rake)*sin(fai) - cos(dip)*cos(rake)*cos(fai);
		R->rsh2d = sin(dip)*(cos(rake)*(-2.*sin(fai2)) - cos(dip)*sin(rake)*2.*cos(fai2));
		R->rpsv1d = cos(2. * dip)*sin(rake)*cos(fai) + cos(dip)*cos(rake)*sin(fai);
		R->rpsv2d = sin(dip)*(cos(rake)*2.*cos(fai2) - cos(dip)*sin(rake)*2.*sin(fai2));
		R->rpsv01d =0;
		R->rpsv02d =0;
	}
	else if (source->SourceType == 'M') {
		mxx = source->para[INDEX_MXX];
		myy = source->para[INDEX_MYY];
		mzz = source->para[INDEX_MZZ];
		mxy = source->para[INDEX_MXY];
		mxz = source->para[INDEX_MXZ];
		myz = source->para[INDEX_MYZ];
		fai = azimuth;
		fai2 = 2.*fai;
		R->rsh1 = mxz*sin(fai) - myz*cos(fai);
		R->rsh2 = (myy - mxx) / 2.*sin(fai2) + mxy*cos(fai2);
		//R->rpsv1 = mxz*cos(fai) - myz*sin(fai);
		//modified according to Tang Le
		R->rpsv1 = mxz*cos(fai) + myz*sin(fai);
		R->rpsv2 = -(myy - mxx) / 2.*cos(fai2) + mxy*sin(fai2);
		R->rpsv01 = (mxx + myy) / 2.;
		R->rpsv02 = mzz;
		//modified by Tang Le 2020.1.13
		R->rsh1d = mxz*cos(fai) +myz*sin(fai);
		R->rsh2d = (myy - mxx)*cos(fai2) - 2.*mxy*sin(fai2);
		R->rpsv1d = -mxz*sin(fai) + myz*cos(fai);
		R->rpsv2d = (myy - mxx)*sin(fai2) + 2.*mxy*cos(fai2);
		R->rpsv01d = 0.;
		R->rpsv02d = 0.;
		//
	}
}

void calc_R_S(double azimuth, double nx, double ny, double nz, RadPat_S *R)
{
	R->rsh1 = ny*cos(azimuth) - nx*sin(azimuth);
	//R->rpsv0 = nx*cos(azimuth) + ny*sin(azimuth);
	//R->rpsv1 = nz;
	//modified according to Tang Le
	R->rpsv1 = nx*cos(azimuth) + ny*sin(azimuth);
	R->rpsv0 = nz;

	// for curl /////////////////
	//modified by Tang Le 2020 1.14
	R->rsh1d = -ny*sin(azimuth) - nx*cos(azimuth);
	R->rpsv1d =-nx*sin(azimuth) + ny*cos(azimuth);
	R->rpsv0d = 0.;

}

SourPara* get_sources(int *nsour, const char *sourfile,double *fc,char *Type_STF,double *tou)
{
	char tempstr[1024];
	char sourtype;
	int isour;
	FILE *pFile;
	SourPara *lstsource;
	//
	double amp, zs;
	double nx, ny, nz;
	double d0s, a0s, dip, rake, strike;
	double mxx, myy, mzz, mxy, mxz, myz;

	if ((pFile = fopen(sourfile, "r")) == NULL) {
		printf("Source file could not be opened.\n");
		exit(EXIT_FAILURE);
	}
	else {
		if (!feof(pFile)) fgets(tempstr, 1024, pFile);
		if (!feof(pFile)) fscanf(pFile, "%d", nsour);
		if (!feof(pFile)) fgets(tempstr, 1024, pFile);
		if (*nsour < 1) {
			printf("number of source <1.\n");
			exit(EXIT_FAILURE);
		}
		lstsource = alloc1SourPara(*nsour);
		memset(lstsource, 0, sizeof(SourPara)*(*nsour));
		for (isour = 0; isour < *nsour; isour++) {
			if (!feof(pFile)) fgets(tempstr, 1024, pFile);
			if (!feof(pFile)) fscanf(pFile, "%c", &sourtype);
			if (!feof(pFile)) fgets(tempstr, 1024, pFile);
			sourtype = toupper(sourtype);
			lstsource[isour].SourceType = sourtype;
			if (sourtype == 'E') {
				if (!feof(pFile)) fscanf(pFile, "%lf", &zs);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);
				if (!feof(pFile)) fscanf(pFile, "%lf", &amp);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);

				if (!feof(pFile)) fscanf(pFile, "%lf",fc);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);

				if (!feof(pFile)) fscanf(pFile, "%s", Type_STF);   
		        if (!feof(pFile)) fgets(tempstr, 1024, pFile);

		        if (!feof(pFile)) fscanf(pFile, "%lf", tou);       
		        if (!feof(pFile)) fgets(tempstr, 1024, pFile);
				lstsource[isour].depth = zs/1000.;
				lstsource[isour].amplitude = amp;
			}
			if (sourtype == 'S') {
				if (!feof(pFile)) fscanf(pFile, "%lf", &zs);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);
				if (!feof(pFile)) fscanf(pFile, "%lf", &nx);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);
				if (!feof(pFile)) fscanf(pFile, "%lf", &ny);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);
				if (!feof(pFile)) fscanf(pFile, "%lf", &nz);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);
				if (!feof(pFile)) fscanf(pFile, "%lf", &amp);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);

				if (!feof(pFile)) fscanf(pFile, "%lf",fc);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);

				if (!feof(pFile)) fscanf(pFile, "%s", Type_STF);   
		        if (!feof(pFile)) fgets(tempstr, 1024, pFile);

		        if (!feof(pFile)) fscanf(pFile, "%lf", tou);       
		        if (!feof(pFile)) fgets(tempstr, 1024, pFile);

				lstsource[isour].depth = zs/1000.;
				lstsource[isour].para[0] = nx;
				lstsource[isour].para[1] = ny;
				lstsource[isour].para[2] = nz;
				lstsource[isour].amplitude = amp;
			}
			if (sourtype == 'D') {
				if (!feof(pFile)) fscanf(pFile, "%lf", &zs);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);
				if (!feof(pFile)) fscanf(pFile, "%lf", &dip);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);
				if (!feof(pFile)) fscanf(pFile, "%lf", &rake);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);
				if (!feof(pFile)) fscanf(pFile, "%lf", &strike);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);
				if (!feof(pFile)) fscanf(pFile, "%lf", &d0s);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);
				if (!feof(pFile)) fscanf(pFile, "%lf", &a0s);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);
				if (!feof(pFile)) fscanf(pFile, "%lf", &amp);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);

				if (!feof(pFile)) fscanf(pFile, "%lf",fc);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);

				if (!feof(pFile)) fscanf(pFile, "%s", Type_STF);   
		        if (!feof(pFile)) fgets(tempstr, 1024, pFile);

		        if (!feof(pFile)) fscanf(pFile, "%lf", tou);       
		        if (!feof(pFile)) fgets(tempstr, 1024, pFile);


				lstsource[isour].depth = zs/1000.;
				lstsource[isour].para[0] = dip*PI / 180.;
				lstsource[isour].para[1] = rake*PI / 180.;
				lstsource[isour].para[2] = strike*PI / 180.;
				lstsource[isour].para[3] = d0s;
				lstsource[isour].para[4] = a0s;
			}
			if (sourtype == 'M') {
				//################### moment tensor source ########################
				if (!feof(pFile)) fscanf(pFile, "%lf", &zs);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);
				if (!feof(pFile)) fscanf(pFile, "%lf", &mxx);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);
				if (!feof(pFile)) fscanf(pFile, "%lf", &myy);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);
				if (!feof(pFile)) fscanf(pFile, "%lf", &mzz);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);
				if (!feof(pFile)) fscanf(pFile, "%lf", &mxy);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);
				if (!feof(pFile)) fscanf(pFile, "%lf", &mxz);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);
				if (!feof(pFile)) fscanf(pFile, "%lf", &myz);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);
				if (!feof(pFile)) fscanf(pFile, "%lf", &amp);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);

				if (!feof(pFile)) fscanf(pFile, "%lf",fc);
				if (!feof(pFile)) fgets(tempstr, 1024, pFile);

				if (!feof(pFile)) fscanf(pFile, "%s", Type_STF);   
		        if (!feof(pFile)) fgets(tempstr, 1024, pFile);

		        if (!feof(pFile)) fscanf(pFile, "%lf", tou);       
		        if (!feof(pFile)) fgets(tempstr, 1024, pFile);

				lstsource[isour].depth = zs/1000;
				lstsource[isour].para[INDEX_MXX] = mxx;
				lstsource[isour].para[INDEX_MYY] = myy;
				lstsource[isour].para[INDEX_MZZ] = mzz;
				lstsource[isour].para[INDEX_MXY] = mxy;
				lstsource[isour].para[INDEX_MXZ] = mxz;
				lstsource[isour].para[INDEX_MYZ] = myz;
				lstsource[isour].amplitude = amp;
			}
		}
	}
	fclose(pFile);
	return lstsource;
}

RecvStat* get_receivers(int *nrecv, const char *recvfile)
{
	char tempstr[1024];
	int nline, iline, temp,allreceivers;
	int *nr;
	double *r0, *f0, *z0, *dr, *df, *dz,*gx,*gy,*gz;
	FILE *pFile;
	RecvStat *lstreceive;
	int irecv, i,gather;

	if ((pFile = fopen(recvfile, "r")) == NULL) {
		printf("Receiver file could not be opened.\n");
		exit(EXIT_FAILURE);
	}
	else {
		if (!feof(pFile)) fgets(tempstr, 1024, pFile);
		if (!feof(pFile)) fscanf(pFile, "%d", &nline);//all reveivers=inline
		if (!feof(pFile)) fgets(tempstr, 1024, pFile);
		if (nline < 1) {
			printf("number of receiver <1.\n");
			exit(EXIT_FAILURE);
		}
		nr = alloc1int(nline);
		r0 = alloc1double(nline);
		f0 = alloc1double(nline);
		z0 = alloc1double(nline);
		dr = alloc1double(nline);
		df = alloc1double(nline);
		dz = alloc1double(nline);

		gx = alloc1double(nline);
		gy = alloc1double(nline);
	    gz = alloc1double(nline);

		if (!feof(pFile)) fgets(tempstr, 1024, pFile);
		for (iline = 0; iline < nline; iline++) 
		{
			//if (!feof(pFile)) fscanf(pFile, "%d %d %lf %lf %lf %lf %lf %lf", &temp, &nr[iline], &r0[iline], &f0[iline], &z0[iline], &dr[iline], &df[iline], &dz[iline]);

            if (!feof(pFile)) fscanf(pFile, "%d %lf %lf %lf",&nr[iline], &gx[iline], &gy[iline], &gz[iline]);
			if (!feof(pFile)) fgets(tempstr, 1024, pFile);

			r0[iline]=sqrt(gx[iline]*gx[iline]+gy[iline]*gy[iline]);
			r0[iline]=r0[iline]/1000.;
			z0[iline]=gz[iline]/1000.;
			// solve the receiver's angle
			if(gx[iline]==0.0&&gy[iline]==0.0)
			    f0[iline]=0.0;
			if(gx[iline]==0.0&&gy[iline]>0.0)
				f0[iline]=PI/2.;
			if(gx[iline]==0.0&&gy[iline]<0.0)
				f0[iline]=PI*3./2.;
			if(gy[iline]==0.0&&gx[iline]>0.0)
				f0[iline]=0.0;
			if(gy[iline]==0.0&&gx[iline]<0.0)
				f0[iline]=PI;

			if(gx[iline]>0.0&&gy[iline]>0.0)
				f0[iline]=atan(gy[iline]/gx[iline]);
			if(gx[iline]>0.0&&gy[iline]<0.0)
				f0[iline]=2.*PI-atan(fabs(gy[iline])/gx[iline]);

			if(gx[iline]<0.0&&gy[iline]>0.0)
				f0[iline]=(PI-atan(gy[iline]/fabs(gx[iline])));
			if(gx[iline]<0.0&&gy[iline]<0.0)
				f0[iline]=PI+atan(fabs(gy[iline])/fabs(gx[iline]));
			//dr[iline]=dr[iline]/1000.;
			//dz[iline]=dz[iline]/1000.;
		}
	}
	fclose(pFile);
	/* *nrecv = 0;
	for (iline = 0; iline < nline; iline++) {
		*nrecv = *nrecv + nr[iline];
	}*/
	*nrecv=nline;
	lstreceive = alloc1RecvStat(*nrecv);
	irecv = 0;
	for (iline = 0; iline < nline; iline++) 
	{
		gather=0;
		/*for (i = 0; i < nr[iline]; i++) {
			lstreceive[irecv].distance = r0[iline] + i*dr[iline];
			lstreceive[irecv].azimuth = (f0[iline] + i*df[iline])*PI / 180.;
			lstreceive[irecv].depth = z0[iline] + i*dz[iline];
			lstreceive[irecv].line=iline+1;
			lstreceive[irecv].ngather=gather+1;
			gather++;
			irecv++;
		}*/
		    lstreceive[iline].distance = r0[iline];
		    lstreceive[iline].sign_r = gx[iline]/fabs(gx[iline]);
			lstreceive[iline].azimuth = f0[iline];
			lstreceive[iline].depth = z0[iline];
			lstreceive[iline].line=iline+1;
			lstreceive[iline].ngather=gather+1;

			lstreceive[iline].g_x = gx[iline];
			lstreceive[iline].g_y = gy[iline];
			lstreceive[iline].g_z = gz[iline];

	}
	free1int(nr);
	free1double(r0);
	free1double(f0);
	free1double(z0);
	free1double(dr);
	free1double(df);
	free1double(dz);
	free1double(gx);
	free1double(gy);
	free1double(gz);
	return lstreceive;
}

void preprocessing_model_source_receiver(FKRTmodel *model, SourPara* lstsourpara, RecvStat* lstrecvstat, int nsour, int nrecv)
{
	int i;
	double maxdepth= lstsourpara[0].depth;
	//get the deepest depth of source
	for (i = 1; i < nsour; i++) {
		if (lstsourpara[i].depth > maxdepth) maxdepth = lstsourpara[i].depth;
	}
	//get the deepest depth or receiver
	for (i = 0; i < nrecv; i++) {
		if (lstrecvstat[i].depth > maxdepth) maxdepth = lstrecvstat[i].depth;
	}
	//set the depth of the deepset fictitious layer
	model->z[model->totalLayer] = maxdepth + 10;
	//calculate the layer and amplitude of source
	for (i = 0; i < nsour; i++) {
		if (lstsourpara[i].SourceType == 'E') {
			calc_source_parameters_E(&lstsourpara[i], model);
		}
		else if (lstsourpara[i].SourceType == 'S') {
			calc_source_parameters_S(&lstsourpara[i], model);
		}
		else if (lstsourpara[i].SourceType == 'D') {
			calc_source_parameters_D(&lstsourpara[i], model);
		}
		else if (lstsourpara[i].SourceType == 'M') {
			calc_source_parameters_M(&lstsourpara[i], model);
		}
	}
	//calculate the layer of receiver
	for (i = 0; i < nrecv; i++) {
		calc_receiver_parameters(&lstrecvstat[i], model);
	}
}

SourPara *alloc1SourPara(size_t n1)
{
	return (SourPara*)alloc1(n1, sizeof(SourPara));
}

RecvStat *alloc1RecvStat(size_t n1)
{
	return (RecvStat*)alloc1(n1, sizeof(RecvStat));
}

void free1SourPara(SourPara *p)
{
	free1(p);
}

void free1RecvStat(RecvStat *p)
{
	free1(p);
}
