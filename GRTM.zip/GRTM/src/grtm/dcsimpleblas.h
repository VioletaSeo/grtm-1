#pragma once

#include "cwp_mini.h"

#include "dcsimpleblas.h"
#include <math.h>
#include <errno.h>
#include <stdlib.h>
void dcassign22(const dcomplex a[4], dcomplex b[4]);

void dcneg22(dcomplex a[4]);

void dcnegOther22(const dcomplex a[4], dcomplex b[4]);

void dcadd22(const dcomplex a[4], const dcomplex b[4], dcomplex apb[4]);

void dcsubd22(const dcomplex a[4], const dcomplex b[4], dcomplex amb[4]);

void dcUnitSub22(dcomplex a[2][2]);

void dcSubUnit22(dcomplex a[2][2]);

void dcUnitAdd22(dcomplex a[2][2]);

void dcUnitSubOther22(const dcomplex a[2][2], dcomplex b[2][2]);

void dcSubUnitOther22(const dcomplex a[2][2], dcomplex b[2][2]);

void dcUnitAddOther22(const dcomplex a[2][2], dcomplex b[2][2]);

void dcmulLD22(const dcomplex diag[2], const dcomplex a[2][2], dcomplex b[2][2]);

void dcmulRD22(const dcomplex a[2][2], const dcomplex diag[2], dcomplex b[2][2]);

void dcmul22(const dcomplex a[2][2], const dcomplex b[2][2], dcomplex ab[2][2]);

void dcmul44(const dcomplex a[4][4], const dcomplex b[4][4], dcomplex ab[4][4]);

void dcinv22(dcomplex a[2][2]);

void dcinv44(dcomplex a[4][4]);
