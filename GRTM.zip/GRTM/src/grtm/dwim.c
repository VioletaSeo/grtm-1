#include "dwim.h"
#include "dcsimpleblas.h"
#include "source_and_receiver.h"
#include "integral_function_coeff.h"
#include "calc_grt.h"
#include "calc_y.h"
#include "calc_q.h"
#include<time.h>

void DWIM_D(FKRTmodel *model, const RadPat_D *radpat, const double kmin, const double kmax, const double dk,
	const int layerSour, const int layerRecv, const double zSour, const double zRecv, const double distance_SR,
	dcomplex integral[3], dcomplex integterm_last[3],dcomplex integrald[3], dcomplex integterm_lastd[3])
{
	//local variables
	int i;
	double kn, dk_2;
	double j0, j1, j2,j3,j4, j0d, j1d, j2d,j1dd,j2dd;
	dcomplex fun[12],fund[32];
	dcomplex integterm_new[3],integterm_newd[3];
	dcomplex rp,rp1;
	

	//first integral point
	/*kn = kmin;
	integral_function_coeff_D(kn, model, radpat, layerSour, layerRecv, zSour, zRecv, fun);
	BesselJ012d(distance_SR*kn, &j0, &j1, &j2, &j0d, &j1d, &j2d);
	integration_D(integterm_last, fun, j0, j1, j2, j0d, j1d, j2d);*/
	for (i = 0; i < 3; i++) {
		integral[i] = dcmplx2(0., 0.);
		integterm_last[i]=dcmplx2(0., 0.);
		integrald[i] = dcmplx2(0., 0.);
		integterm_lastd[i]=dcmplx2(0., 0.);

	}
	//loop for kn
	dk_2 = dk / 2.;
	//printf("%lf\n",kmax );
	//exit(0);
	for (kn = dk; kn < kmax; kn = kn + dk) {
	

		integral_function_coeff_D(kn, model, radpat, layerSour, layerRecv, zSour, zRecv, fun,fund);
		BesselJ012d(distance_SR*kn, &j0, &j1, &j2, &j0d, &j1d, &j2d,&j3,&j4,&j1dd,&j2dd);
		integration_D(integterm_new, fun, j0, j1, j2, j0d, j1d, j2d,integterm_newd,fund, j3, j4, j1dd, j2dd);
	
	/*printf("%lf\n",fun[0].r );
	printf("%lf\n",fun[0].i );
	printf("%lf\n",fun[1].r );
	printf("%lf\n",fun[1].i );
	printf("%lf\n",fun[2].r );
	printf("%lf\n",fun[2].i );*/
	/*printf("%lf\n",integterm_new[0].i );
	printf("%lf\n",integterm_new[1].r );
	printf("%lf\n",integterm_new[1].i );
	printf("%lf\n",integterm_new[2].r );
	printf("%lf\n",integterm_new[2].i );*/

		for (i = 0; i < 3; i++) {
			rp=integterm_last[i];rp1=integterm_new[i];
			rp=dcadd2(rp,rp1);
			rp=dcrmul2(rp, dk_2);
			rp1=integral[i];
			integral[i] = dcadd2(rp1, rp);
			integterm_last[i] = integterm_new[i];
			////////// for curl //////////////////////////
			rp=integterm_lastd[i];rp1=integterm_newd[i];
			rp=dcadd2(rp,rp1);
			rp=dcrmul2(rp, dk_2);
			rp1=integrald[i];
			integrald[i] = dcadd2(rp1, rp);
			integterm_lastd[i] = integterm_newd[i];
			////////////////////////////////////////////////
		}
	}

	/*printf("%lf\n",integral[0].r );
	printf("%lf\n",integral[0].i );
	printf("%lf\n",integral[1].r );
	printf("%lf\n",integral[1].i );
	printf("%lf\n",integral[2].r );
	printf("%lf\n",integral[2].i );
	exit(0);*/
	/*printf("%lf\n",integterm_last[0].r );
	printf("%lf\n",integterm_last[0].i );
	printf("%lf\n",integterm_last[1].r );
	printf("%lf\n",integterm_last[1].i );
	printf("%lf\n",integterm_last[2].r );
	printf("%lf\n",integterm_last[2].i );
	exit(0);*/
	//last integral point
	dk_2 = (kmax - kn + dk) / 2.;
	kn = kmax;
	   integral_function_coeff_D(kn, model, radpat, layerSour, layerRecv, zSour, zRecv, fun,fund);
		BesselJ012d(distance_SR*kn, &j0, &j1, &j2, &j0d, &j1d, &j2d,&j3,&j4,&j1dd,&j2dd);
		integration_D(integterm_new, fun, j0, j1, j2, j0d, j1d, j2d,integterm_newd,fund, j3, j4, j1dd, j2dd);
	for (i = 0; i < 3; i++) {
		    rp=integterm_last[i];rp1=integterm_new[i];
			rp=dcadd2(rp,rp1);
			rp=dcrmul2(rp, dk_2);
			rp1=integral[i];
			integral[i] = dcadd2(rp1, rp);
			integterm_last[i] = integterm_new[i];
			/////////////// for curl ////////////////////
			rp=integterm_lastd[i];rp1=integterm_newd[i];
			rp=dcadd2(rp,rp1);
			rp=dcrmul2(rp, dk_2);
			rp1=integrald[i];
			integrald[i] = dcadd2(rp1, rp);
			integterm_lastd[i] = integterm_newd[i];
			//////////////////////////////////////////////
	}
    /*printf("%lf\n",integral[0].r );
	printf("%lf\n",integral[0].i );
	printf("%lf\n",integral[1].r );
	printf("%lf\n",integral[1].i );
	printf("%lf\n",integral[2].r );
	printf("%lf\n",integral[2].i );
	exit(0);*/
	return;
}

void DWIM_S(FKRTmodel *model, const RadPat_S *radpat, const double kmin, const double kmax, const double dk,
	const int layerSour, const int layerRecv, const double zSour, const double zRecv, const double distance_SR,
	dcomplex integral[3], dcomplex integterm_last[3],dcomplex integrald[3], dcomplex integterm_lastd[3])
{
	//local variables
	int i;
	double kn, dk_2;
	double j0, j1, j0d, j1d,j2,j3,j2d;
	dcomplex fun[7],fund[14];
	dcomplex integterm_new[3],integterm_newd[3];

	//first integral point
	kn = kmin;
	/*integral_function_coeff_S(kn, model, radpat, layerSour, layerRecv, zSour, zRecv, fun);
	BesselJ01d(distance_SR*kn, &j0, &j1, &j0d, &j1d);
	integration_S(integterm_last, fun, j0, j1, j0d, j1d);*/
	for (i = 0; i < 3; i++) {
		integral[i] = dcmplx(0., 0.);
		integterm_last[i]=dcmplx(0., 0.);
		integrald[i] = dcmplx(0., 0.);
		integterm_lastd[i]=dcmplx(0., 0.);
	}
	//loop for kn
	dk_2 = dk / 2.;
	for (kn = kmin + dk; kn < kmax; kn = kn + dk) {
//	for (kn = 100*dk; kn < kmax; kn = kn + dk) {
	//printf("%lf\n",dk);
		integral_function_coeff_S(kn, model, radpat, layerSour, layerRecv, zSour, zRecv, fun,fund);
		BesselJ01d(distance_SR*kn, &j0, &j1, &j0d, &j1d,&j2,&j3,&j2d);
		integration_S(integterm_new, fun, j0, j1, j0d, j1d,j2,j3,j2d,integterm_newd, fund);
		for (i = 0; i < 3; i++) {
			integral[i] = dcadd(integral[i], dcrmul(dcadd(integterm_last[i], integterm_new[i]), dk_2));
			integterm_last[i] = integterm_new[i];
			//// for curl //////////////////////
			integrald[i] = dcadd(integrald[i], dcrmul(dcadd(integterm_lastd[i], integterm_newd[i]), dk_2));
			integterm_lastd[i] = integterm_newd[i];
		}
	}
	//last integral point
	dk_2 = (kmax - kn + dk) / 2.;
	kn = kmax;
	integral_function_coeff_S(kn, model, radpat, layerSour, layerRecv, zSour, zRecv, fun,fund);
	BesselJ01d(distance_SR*kn, &j0, &j1, &j0d, &j1d,&j2,&j3,&j2d);
	integration_S(integterm_new, fun, j0, j1, j0d, j1d,j2,j3,j2d,integterm_newd, fund);
	for (i = 0; i < 3; i++) {
		integral[i] = dcadd(integral[i], dcrmul(dcadd(integterm_last[i], integterm_new[i]), dk_2));
		integterm_last[i] = integterm_new[i];
		// for curl ///////////////////
		integrald[i] = dcadd(integrald[i], dcrmul(dcadd(integterm_lastd[i], integterm_newd[i]), dk_2));
		integterm_lastd[i] = integterm_newd[i];
	}

	return;
}

void DWIM_E(FKRTmodel *model, const double kmin, const double kmax, const double dk,
	const int layerSour, const int layerRecv, const double zSour, const double zRecv, const double distance_SR,
	dcomplex integral[3], dcomplex integterm_last[3])
{
	//local variables
	int i;
	double kn, dk_2;
	double j0, j0d;
	dcomplex fun[2];
	dcomplex integterm_new[3];

	//first integral point
	kn = kmin;
	//integral_function_coeff_E(kn, model, layerSour, layerRecv, zSour, zRecv, fun);
	integral_function_coeff_E0(kn, model, layerSour, layerRecv, zSour, zRecv, fun);
	j0 = BesselJ0(distance_SR*kn);
	j0d = -BesselJ1(distance_SR*kn);
	integration_E(integterm_last, fun, j0, j0d);
	for (i = 0; i < 3; i++) {
		integral[i] = dcmplx(0., 0.);
	}
	//loop for kn
	dk_2 = dk / 2.;
	for (kn = kmin + dk; kn < kmax; kn = kn + dk) {
		//integral_function_coeff_E(kn, model, layerSour, layerRecv, zSour, zRecv, fun);
		integral_function_coeff_E0(kn, model, layerSour, layerRecv, zSour, zRecv, fun);
		j0 = BesselJ0(distance_SR*kn);
		j0d = -BesselJ1(distance_SR*kn);
		integration_E(integterm_new, fun, j0, j0d);
		for (i = 0; i < 3; i++) {
			integral[i] = dcadd(integral[i], dcrmul(dcadd(integterm_last[i], integterm_new[i]), dk_2));
			integterm_last[i] = integterm_new[i];
		}
	}
	//last integral point
	dk_2 = (kmax - kn + dk) / 2.;
	kn = kmax;
	//integral_function_coeff_E(kn, model, layerSour, layerRecv, zSour, zRecv, fun);
	integral_function_coeff_E0(kn, model, layerSour, layerRecv, zSour, zRecv, fun);
	j0 = BesselJ0(distance_SR*kn);
	j0d = -BesselJ1(distance_SR*kn);
	integration_E(integterm_new, fun, j0, j0d);
	for (i = 0; i < 3; i++) {
		integral[i] = dcadd(integral[i], dcrmul(dcadd(integterm_last[i], integterm_new[i]), dk_2));
		integterm_last[i] = integterm_new[i];
	}

	return;
}
