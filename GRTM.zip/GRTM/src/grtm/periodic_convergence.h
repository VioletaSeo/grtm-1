#pragma once

#include "cwp_mini.h"

void  periodic_convergence(double kn, dcomplex Urtz[3], int flagZero[3], int *convergence,
	int *counter, int numCycle[12], int flagSearchCycle[12]);

void  periodic_convergence_E(double kn, dcomplex Urtz[3], int *convergence,
	int *counter, int numCycle[12], int flagSearchCycle[12]);