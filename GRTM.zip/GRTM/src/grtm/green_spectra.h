#pragma once

#include "model.h"
#include "cwp_mini.h"
#include "source_and_receiver.h"


#define CONVERGENCE_THRESH 1.e-3

#define MAXCYCLECHECKTIME 35000

void green_spectra_D(FKRTmodel *pmodel, double df, int nfreqBeg, int nfreqEnd,
	double iomega, double freq_reference, double dk,
	const SourPara *source, const RecvStat *recvstat,
	dcomplex *ur, dcomplex *ut, dcomplex *uz, char *PeriodCheck,dcomplex *urd, dcomplex *utd, dcomplex *uzd);

void green_spectra_S(FKRTmodel *pmodel, double df, int nfreqBeg, int nfreqEnd,
	double iomega, double freq_reference, double dk,
	const SourPara *source, const RecvStat *recvstat,
	dcomplex *ur, dcomplex *ut, dcomplex *uz, char *PeriodCheck,dcomplex *urd, dcomplex *utd, dcomplex *uzd);

void green_spectra_E(FKRTmodel *model, double df, int nfreqBeg, int nfreqEnd,
	double iomega, double freq_reference, double dk,
	const SourPara *source, const RecvStat *recvstat,
	dcomplex *ur, dcomplex *ut, dcomplex *uz, char *PeriodCheck);
