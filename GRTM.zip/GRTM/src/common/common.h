/*
 
 global macros and structures

*/

/*#define PI         3.141592653589793

#define MAX(a,b)   ( (a)>=(b)? (a) : (b) )
#define MIN(a,b)   ( (a)>=(b)? (b) : (a) )


struct seismic_traces {
	unsigned long ntrace; // number of traces
	unsigned long natt;   // number of attributes
	unsigned long nt;     // number of time samples
	char *att_name;       // 1D char array containing the name of each attribute, each attribute name can have up to 60 characters
    short *att_datatype;  //  1=int, 2=float  
	float *att_val;       // attribute values (use int *att_val_int=(int *)att_val for int attributes)
	float *d1, *d2, *d3, *d4, *d5, *d6;          // seismic data
	char description[120]; // comments
};



struct seismic_volume {
	int nx, ny, nz; // number of grids in the x, y and z direction
	float dx, dy, dz;  // grid spacing in the x, y and z direction
	float x0, y0, z0;  // coordinate origin
	char prop_name[60]; // name of the property
	float *v;      // property value
	char description[120]; // comments
};*/





