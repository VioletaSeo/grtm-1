#include "bessel.h"
#include <math.h>

#define SGN(x) ((x) < 0 ? -1.0 : 1.0)
#define POLY4(x,a0,a1,a2,a3,a4)    (a0 + x*(a1 + x*(a2 + x*(a3 + x*a4))))
#define POLY5(x,a0,a1,a2,a3,a4,a5) (a0 + x*(a1 + x*(a2 + x*(a3 + x*(a4 + x*a5)))))
//coeffients for J0(x):x[0 8]
#define	J0_P0	 5.75684905737669E+10
#define	J0_P1	-1.33625903539519E+10
#define	J0_P2	 6.51619640750087E+08
#define	J0_P3	-1.12144241822730E+07
#define	J0_P4	 7.73923301724046E+04
#define	J0_P5	-1.84905245643054E+02
#define	J0_Q0	 5.75684904106765E+10
#define	J0_Q1	 1.02953298576634E+09
#define	J0_Q2	 9.49468071877899E+06
#define	J0_Q3	 5.92726485342324E+04
#define	J0_Q4	 2.67853271212668E+02
#define	J0_Q5	 1.00000000000000E+00
//coeffients for J0(x):x[8 inf]
#define	PZERO0	 9.99999999921017E-01
#define	PZERO1	-1.09862862785560E-03
#define	PZERO2	 2.73451040704000E-05
#define	PZERO3	-2.07337063950000E-06
#define	PZERO4	 2.09388721100000E-07
#define	QZERO0	-1.56249999575526E-02
#define	QZERO1	 1.43048876535100E-04
#define	QZERO2	-6.91114765160000E-06
#define	QZERO3	 7.62109516100000E-07
#define	QZERO4	-9.34945152000000E-08
//coeffients for J1(x):x[8 inf]
#define	PONE0	 1.00000000008854E+00
#define	PONE1	 1.83105000086400E-03
#define	PONE2	-3.51639649610000E-05
#define	PONE3	 2.45752017400000E-06
#define	PONE4	-2.40337019000000E-07
#define	QONE0	 4.68749999528700E-02
#define	QONE1	-2.00269087313000E-04
#define	QONE2	 8.44919909600000E-06
#define	QONE3	-8.82289870000000E-07
#define	QONE4	 1.05787412000000E-07
//coeffients for J1(x):x[0 8]
#define	J1_P0	 7.23626142317360E+10
#define	J1_P1	-7.89505923522244E+09
#define	J1_P2	 2.42396853162386E+08
#define	J1_P3	-2.97261143962119E+06
#define	J1_P4	 1.57044826089959E+04
#define	J1_P5	-3.01603660660947E+01
#define	J1_Q0	 1.44725228442551E+11
#define	J1_Q1	 2.30053517770143E+09
#define	J1_Q2	 1.85833047401538E+07
#define	J1_Q3	 9.94474339494556E+04
#define	J1_Q4	 3.76999139743766E+02
#define	J1_Q5	 1.00000000000000E+00
//constant number
#define TWO_OVER_PI 0.636619772367581 // 2/pi
#define QUARTER_PI  0.785398163397448 // pi/4
#define QUARTER_PI3 2.35619449019234 //  pi/4*3
// # x: input variable # j0, j1, j2 :zero, first and second order bessel # j0d, j1d , j2d : first derivative of bessel
void BesselJ012d(const double x, double* j0, double* j1, double*j2, double* j0d, double* j1d, double* j2d,double* j3, double* j4,double* j1dd, double* j2dd)
{
	
	*j0 = BesselJ0(x);
	*j1 = BesselJ1(x);
	*j2 = BesselJ2(x);
	*j3 = BesselJ3(x);
	*j4 = BesselJn(4,x);

	*j0d = -*j1;
	*j1d = (*j0 - *j2) / 2.0;
	*j2d = (*j1 - *j3) / 2.0;
	*j1dd=(*j0d-*j2d)/2.;
	*j2dd=*j1d/2.-(*j2-*j4)/4.;

}
// # x: input variable # j0, j1 :zero, first and second order bessel # j0d, j1d : first derivative of bessel
void BesselJ01d(const double x, double* j0, double* j1, double* j0d, double* j1d,double* j2, double* j3, double* j2d)
{
	
	*j0 = BesselJ0(x);
	*j1 = BesselJ1(x);
	*j2 = BesselJ2(x);
	*j3 = BesselJ3(x);

	*j0d = -*j1;
	*j1d = (*j0 - *j2) / 2.0;
	*j2d = (*j1 - *j3) / 2.0;
}
// # zero order bessel
double BesselJ0(const double x)
{
	double absx, z, y, xn;
	absx = fabs(x);
	if (absx < 8.0)	{
		y = x*x;
		return POLY5(y, J0_P0, J0_P1, J0_P2, J0_P3, J0_P4, J0_P5)
			/ POLY5(y, J0_Q0, J0_Q1, J0_Q2, J0_Q3, J0_Q4, J0_Q5);
	}
	else {
		z = 8. / absx;
		y = z*z;
		xn = absx - QUARTER_PI;
		return sqrt(TWO_OVER_PI / absx)*(cos(xn)*POLY4(y,PZERO0, PZERO1, PZERO2, PZERO3, PZERO4)
			- sin(xn)*z*POLY4(y, QZERO0, QZERO1, QZERO2, QZERO3, QZERO4));
	}
}
// # first order bessel
double BesselJ1(const double x)
{
	double absx, z, y, xn;
	absx = fabs(x);
	if (absx < 8.0) {
		y = x*x;
		return x*POLY5(y, J1_P0, J1_P1, J1_P2, J1_P3, J1_P4, J1_P5)
			/ POLY5(y, J1_Q0, J1_Q1, J1_Q2, J1_Q3, J1_Q4, J1_Q5);
	}
	else {
		z = 8. / absx;
		y = z*z;
		xn = absx - QUARTER_PI3;
		return sqrt(TWO_OVER_PI / absx)*(cos(xn)*POLY4(y, PONE0, PONE1, PONE2, PONE3, PONE4)
			- sin(xn)*z*POLY4(y, QONE0, QONE1, QONE2, QONE3, QONE4))*SGN(x);
	}
}

#define IACC 40
#define BIGNO 1e10
#define BIGNI 1e-10
// # second order bessel
double BesselJ2(const double x)
{
	int j, jsum, m;
	double ax, bj, bjm, bjp, sum, tox, ans;

	if (x == 0.0) return 0.0;

	ax = fabs(x);
	tox = 2.0 / ax;
	if (ax > 2.0) {
		bjm = BesselJ0(ax);
		bj = BesselJ1(ax);
		ans = tox*bj - bjm;
	}
	else {
		m = 2 * ((2 + (int)sqrt(IACC*2)) / 2);
		jsum = 0;
		bjp = ans = sum = 0.0;
		bj = 1.0;
		for (j = m; j>0; j--) {
			bjm = j*tox*bj - bjp;
			bjp = bj;
			bj = bjm;
			if (fabs(bj) > BIGNO) {
				bj *= BIGNI;
				bjp *= BIGNI;
				ans *= BIGNI;
				sum *= BIGNI;
			}
			if (jsum) sum += bj;
			jsum = !jsum;
			if (j == 2) ans = bjp;
		}
		sum = 2.0*sum - bj;
		ans /= sum;
	}
	return ans;
}
// # third order bessel
double BesselJ3(const double x)
{
	int j, jsum, m;
	double ax, bj, bjm, bjp, sum, tox, ans;

	if (x == 0.0) return 0.0;

	ax = fabs(x);
	tox = 2.0 / ax;
	if (ax > 3.0) {
		bjm = BesselJ0(ax);
		bj  = BesselJ1(ax);
		ans = 2.0*tox*(tox*bj - bjm) - bj;
	}
	else {
		m = 2 * ((3 + (int)sqrt(IACC*3)) / 2);
		jsum = 0;
		bjp = ans = sum = 0.0;
		bj = 1.0;
		for (j = m; j>0; j--) {
			bjm = j*tox*bj - bjp;
			bjp = bj;
			bj = bjm;
			if (fabs(bj) > BIGNO) {
				bj *= BIGNI;
				bjp *= BIGNI;
				ans *= BIGNI;
				sum *= BIGNI;
			}
			if (jsum) sum += bj;
			jsum = !jsum;
			if (j == 3) ans = bjp;
		}
		sum = 2.0*sum - bj;
		ans /= sum;
	}
	return x < 0.0 ? -ans : ans;
}
// # n order bessel
double BesselJn(const int n, const double x)
{
	int j, jsum, m;
	double ax, bj, bjm, bjp, sum, tox, ans;

	if (n == 0) return BesselJ0(x);
	if (n == 1) return BesselJ1(x);
	if (x == 0.0) return 0.0;

	ax = fabs(x);
	tox = 2.0 / ax;
	if (ax >(double) n) {
		bjm = BesselJ0(ax);
		bj = BesselJ1(ax);
		for (j = 1; j<n; j++) {
			bjp = j*tox*bj - bjm;
			bjm = bj;
			bj = bjp;
		}
		ans = bj;
	}
	else {
		m = 2 * ((n + (int)sqrt(IACC*n)) / 2);
		jsum = 0;
		bjp = ans = sum = 0.0;
		bj = 1.0;
		for (j = m; j>0; j--) {
			bjm = j*tox*bj - bjp;
			bjp = bj;
			bj = bjm;
			if (fabs(bj) > BIGNO) {
				bj *= BIGNI;
				bjp *= BIGNI;
				ans *= BIGNI;
				sum *= BIGNI;
			}
			if (jsum) sum += bj;
			jsum = !jsum;
			if (j == n) ans = bjp;
		}
		sum = 2.0*sum - bj;
		ans /= sum;
	}
	return x < 0.0 && (n & 1) ? -ans : ans;
}
