#pragma once

#include <math.h>

#ifndef M_PI
#define M_PI (double) (3.1415926535897932385)
#endif

#ifndef M_SQRT1_2
#define M_SQRT1_2 (double) (1./sqrt(2.))
#endif

//int in;		/* 0: forward FFT; non-zero: inverse FFT */
//int n;		/* number of points */
//double *x, *y;	/* arrays of points */
void fft842(int in, int n, double *x, double *y);
void r2tx(int nthpo, double *cr0, double *cr1, double *ci0, double *ci1);
void r4tx(int nthpo, double *cr0, double *cr1, double *cr2, double *cr3,
	double *ci0, double *ci1, double *ci2, double *ci3);
void r8tx(int nx, int nthpo, int length,
	double *cr0, double *cr1, double *cr2, double *cr3,
	double *cr4, double *cr5, double *cr6, double *cr7,
	double *ci0, double *ci1, double *ci2, double *ci3,
	double *ci4, double *ci5, double *ci6, double *ci7);