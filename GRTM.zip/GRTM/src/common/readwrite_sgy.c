#include<stdio.h>
#include"readwrite_sgy.h"
//n=1 volume header ## n=0 no volume header
// char *filename :read segy filename
// SEGYheader *h : segy file header
// short ntarce: number of trace per trace
// short nt: number of sampling per trace
void read_segy_file(int n,char *filename,SEGYheader **h, float **d,short *ntrace,short *nt)
{
int i;
short ntrace1,nt1;
long int len;
FILE *fid;

if((fid=fopen(filename,"rb"))!=NULL)
{
          if(n==1)
           {
              fseek(fid,3212,SEEK_SET);
             fread(&ntrace1,sizeof(unsigned short),1,fid); // number of traces
             fseek(fid,3220,SEEK_SET);
              fread(&nt1,sizeof(unsigned short),1,fid); // number of time samples
              fseek(fid,0,SEEK_END);
              len = ftell(fid); // file length
            }
            else
             {
                fseek(fid,114,SEEK_SET);
                fread(&nt1,sizeof(short),1,fid); // number of traces
                fseek(fid,0,SEEK_END);
                len = ftell(fid); // file length
                ntrace1=len/(240+nt1*sizeof(float));
              }

   *h = (SEGYheader *) malloc(ntrace1*sizeof(SEGYheader));
   *d = (float *) malloc(ntrace1*nt1*sizeof(float));
    for(i=0;i<ntrace1;i++) 
    {
        fseek(fid, 3600*n+i*(240+nt1*sizeof(float)), SEEK_SET);
        fread(&h[0][i].tracl,sizeof(int),1,fid); // 1-4
        fread(&h[0][i].tracr,sizeof(int),1,fid); // 5-8
        fread(&h[0][i].fldr,sizeof(int),1,fid); // 9-12
        fread(&h[0][i].tracf,sizeof(int),1,fid); // 13-16
        fread(&h[0][i].ep,sizeof(int),1,fid); // 17-20
        fread(&h[0][i].cdp,sizeof(int),1,fid); // 21-24
        fread(&h[0][i].cdpt,sizeof(int),1,fid); // 25-28
        fread(&h[0][i].trid,sizeof(short),1,fid); // 29-30
        fread(&h[0][i].nva,sizeof(short),1,fid); // 31-32
        fread(&h[0][i].nhs,sizeof(short),1,fid); // 33-34
        fread(&h[0][i].duse,sizeof(short),1,fid); // 35-36
        fread(&h[0][i].offset,sizeof(int),1,fid); // 37-40
        fread(&h[0][i].gelev,sizeof(int),1,fid); // 41-44
        fread(&h[0][i].selev,sizeof(int),1,fid); // 45-48
        fread(&h[0][i].sdepth,sizeof(int),1,fid); // 49-52
        fread(&h[0][i].gdel,sizeof(int),1,fid); // 53-56
        fread(&h[0][i].sdel,sizeof(int),1,fid); // 57-60
        fread(&h[0][i].swdep,sizeof(int),1,fid); // 61-64
        fread(&h[0][i].gwdep,sizeof(int),1,fid); // 65-68
        fread(&h[0][i].scalel,sizeof(short),1,fid); // 69-70
        fread(&h[0][i].scalco,sizeof(short),1,fid); // 71-72
        fread(&h[0][i].sx,sizeof(int),1,fid); // 73-76
        fread(&h[0][i].sy,sizeof(int),1,fid); // 77-80
        fread(&h[0][i].gx,sizeof(int),1,fid); // 81-84, Group coordinate - Longitude
        fread(&h[0][i].gy,sizeof(int),1,fid); // 85-88, Group coordinate - Latitude
        fread(&h[0][i].counit,sizeof(short),1,fid); // 89-90
        fread(&h[0][i].wevel,sizeof(short),1,fid); // 91-92
        fread(&h[0][i].swevel,sizeof(short),1,fid); // 93-94
        fread(&h[0][i].sut,sizeof(short),1,fid); // 95-96
        fread(&h[0][i].gut,sizeof(short),1,fid); // 97-98
        fread(&h[0][i].sstat,sizeof(short),1,fid); // 99-100
        fread(&h[0][i].gstat,sizeof(short),1,fid); // 101-102
        fread(&h[0][i].tstat,sizeof(short),1,fid); // 103-104
        fread(&h[0][i].laga,sizeof(short),1,fid); // 105-106
        fread(&h[0][i].lagb,sizeof(short),1,fid); // 107-108
        fread(&h[0][i].delrt,sizeof(short),1,fid); // 109-110
        fread(&h[0][i].muts,sizeof(short),1,fid); // 111-112
        fread(&h[0][i].mute,sizeof(short),1,fid); // 113-114
        fread(&h[0][i].ns,sizeof(short),1,fid); // 115-116, Number of samples in th[i]s trace.
        fread(&h[0][i].dt,sizeof(short),1,fid); // 117-118, Sample interval, in microseconds, for th[i]s trace.
        fread(&h[0][i].gain,sizeof(short),1,fid); // 119-120
        fread(&h[0][i].igc,sizeof(short),1,fid); // 121-122
        fread(&h[0][i].igi,sizeof(short),1,fid); // 123-124
        fread(&h[0][i].corr,sizeof(short),1,fid); // 125-126
        fread(&h[0][i].sfs,sizeof(short),1,fid); // 127-128
        fread(&h[0][i].sfe,sizeof(short),1,fid); // 129-130
        fread(&h[0][i].slen,sizeof(short),1,fid); // 131-132
        fread(&h[0][i].styp,sizeof(short),1,fid); // 133-134
        fread(&h[0][i].stas,sizeof(short),1,fid); // 135-136
        fread(&h[0][i].stae,sizeof(short),1,fid); // 137-138
        fread(&h[0][i].tatyp,sizeof(short),1,fid); // 139-140
        fread(&h[0][i].afilf,sizeof(short),1,fid); // 141-142, Alias filter frequency.
        fread(&h[0][i].afils,sizeof(short),1,fid); // 143-144
        fread(&h[0][i].nofilf,sizeof(short),1,fid); // 145-146
        fread(&h[0][i].nofils,sizeof(short),1,fid); // 147-148
        fread(&h[0][i].lcf,sizeof(short),1,fid); // 149-150
        fread(&h[0][i].hcf,sizeof(short),1,fid); // 151-152
        fread(&h[0][i].lcs,sizeof(short),1,fid); // 153-154
        fread(&h[0][i].hcs,sizeof(short),1,fid); // 155-156
        fread(&h[0][i].year,sizeof(short),1,fid); // 157-158, year data recorded
        fread(&h[0][i].day,sizeof(short),1,fid); // 159-160
        fread(&h[0][i].hour,sizeof(short),1,fid); // 161-162
        fread(&h[0][i].minute,sizeof(short),1,fid); // 163-164
        fread(&h[0][i].sec,sizeof(short),1,fid); // 165-166
        fread(&h[0][i].timbas,sizeof(short),1,fid); // 167-168
        fread(&h[0][i].trwf,sizeof(short),1,fid); // 169-170, trace weighting factor
        fread(&h[0][i].grnors,sizeof(short),1,fid); // 171-172
        fread(&h[0][i].grnofr,sizeof(short),1,fid); // 173-174
        fread(&h[0][i].grnlof,sizeof(short),1,fid); // 175-176
        fread(&h[0][i].gaps,sizeof(short),1,fid); // 177-178
        fread(&h[0][i].otrav,sizeof(short),1,fid); // 179-180
    
        fseek(fid, 3600*n+i*(240+nt1*sizeof(float))+240, SEEK_SET);
        fread(&d[0][i*nt1],sizeof(float),nt1,fid);
       }
      *ntrace=ntrace1;
      *nt=nt1;
       fclose(fid);
      }
      else
         {
           printf(" !!! ERROR !!! can't open %s \n",filename);
         }

}
// write .segy data without volume
// char *filename :write segy filename
// SEGYheader *h : segy file header
// float *d : data without header and volume
// short ntarce: number of trace per trace
// short nt: number of sampling per trace
void write_segy_file(char *filename, SEGYheader *h, float *d,short ntrace,short nt)
{

int i;
FILE *fid;
float temp[15];
memset(temp,0,sizeof(temp));
if((fid=fopen(filename,"wb"))!=NULL)
{
     
    for(i=0;i<ntrace;i++) 
    {
        fwrite(&h[i].tracl,sizeof(int),1,fid); // 1-4
        fwrite(&h[i].tracr,sizeof(int),1,fid); // 5-8
        fwrite(&h[i].fldr,sizeof(int),1,fid); // 9-12
        fwrite(&h[i].tracf,sizeof(int),1,fid); // 13-16
        fwrite(&h[i].ep,sizeof(int),1,fid); // 17-20
        fwrite(&h[i].cdp,sizeof(int),1,fid); // 21-24
        fwrite(&h[i].cdpt,sizeof(int),1,fid); // 25-28
        fwrite(&h[i].trid,sizeof(short),1,fid); // 29-30
        fwrite(&h[i].nva,sizeof(short),1,fid); // 31-32
        fwrite(&h[i].nhs,sizeof(short),1,fid); // 33-34
        fwrite(&h[i].duse,sizeof(short),1,fid); // 35-36
        fwrite(&h[i].offset,sizeof(int),1,fid); // 37-40
        fwrite(&h[i].gelev,sizeof(int),1,fid); // 41-44
        fwrite(&h[i].selev,sizeof(int),1,fid); // 45-48
        fwrite(&h[i].sdepth,sizeof(int),1,fid); // 49-52
        fwrite(&h[i].gdel,sizeof(int),1,fid); // 53-56
        fwrite(&h[i].sdel,sizeof(int),1,fid); // 57-60
        fwrite(&h[i].swdep,sizeof(int),1,fid); // 61-64
        fwrite(&h[i].gwdep,sizeof(int),1,fid); // 65-68
        fwrite(&h[i].scalel,sizeof(short),1,fid); // 69-70
        fwrite(&h[i].scalco,sizeof(short),1,fid); // 71-72
        fwrite(&h[i].sx,sizeof(int),1,fid); // 73-76
        fwrite(&h[i].sy,sizeof(int),1,fid); // 77-80
        fwrite(&h[i].gx,sizeof(int),1,fid); // 81-84, Group coordinate - Longitude
        fwrite(&h[i].gy,sizeof(int),1,fid); // 85-88, Group coordinate - Latitude
        fwrite(&h[i].counit,sizeof(short),1,fid); // 89-90
        fwrite(&h[i].wevel,sizeof(short),1,fid); // 91-92
        fwrite(&h[i].swevel,sizeof(short),1,fid); // 93-94
        fwrite(&h[i].sut,sizeof(short),1,fid); // 95-96
        fwrite(&h[i].gut,sizeof(short),1,fid); // 97-98
        fwrite(&h[i].sstat,sizeof(short),1,fid); // 99-100
        fwrite(&h[i].gstat,sizeof(short),1,fid); // 101-102
        fwrite(&h[i].tstat,sizeof(short),1,fid); // 103-104
        fwrite(&h[i].laga,sizeof(short),1,fid); // 105-106
        fwrite(&h[i].lagb,sizeof(short),1,fid); // 107-108
        fwrite(&h[i].delrt,sizeof(short),1,fid); // 109-110
        fwrite(&h[i].muts,sizeof(short),1,fid); // 111-112
        fwrite(&h[i].mute,sizeof(short),1,fid); // 113-114
        fwrite(&h[i].ns,sizeof(short),1,fid); // 115-116, Number of samples in this trace.
        fwrite(&h[i].dt,sizeof(short),1,fid); // 117-118, Sample interval, in microseconds, for this trace.
        fwrite(&h[i].gain,sizeof(short),1,fid); // 119-120
        fwrite(&h[i].igc,sizeof(short),1,fid); // 121-122
        fwrite(&h[i].igi,sizeof(short),1,fid); // 123-124
        fwrite(&h[i].corr,sizeof(short),1,fid); // 125-126
        fwrite(&h[i].sfs,sizeof(short),1,fid); // 127-128
        fwrite(&h[i].sfe,sizeof(short),1,fid); // 129-130
        fwrite(&h[i].slen,sizeof(short),1,fid); // 131-132
        fwrite(&h[i].styp,sizeof(short),1,fid); // 133-134
        fwrite(&h[i].stas,sizeof(short),1,fid); // 135-136
        fwrite(&h[i].stae,sizeof(short),1,fid); // 137-138
        fwrite(&h[i].tatyp,sizeof(short),1,fid); // 139-140
        fwrite(&h[i].afilf,sizeof(short),1,fid); // 141-142, Alias filter frequency.
        fwrite(&h[i].afils,sizeof(short),1,fid); // 143-144
        fwrite(&h[i].nofilf,sizeof(short),1,fid); // 145-146
        fwrite(&h[i].nofils,sizeof(short),1,fid); // 147-148
        fwrite(&h[i].lcf,sizeof(short),1,fid); // 149-150
        fwrite(&h[i].hcf,sizeof(short),1,fid); // 151-152
        fwrite(&h[i].lcs,sizeof(short),1,fid); // 153-154
        fwrite(&h[i].hcs,sizeof(short),1,fid); // 155-156
        fwrite(&h[i].year,sizeof(short),1,fid); // 157-158, year data recorded
        fwrite(&h[i].day,sizeof(short),1,fid); // 159-160
        fwrite(&h[i].hour,sizeof(short),1,fid); // 161-162
        fwrite(&h[i].minute,sizeof(short),1,fid); // 163-164
        fwrite(&h[i].sec,sizeof(short),1,fid); // 165-166
        fwrite(&h[i].timbas,sizeof(short),1,fid); // 167-168
        fwrite(&h[i].trwf,sizeof(short),1,fid); // 169-170, trace weighting factor
        fwrite(&h[i].grnors,sizeof(short),1,fid); // 171-172
        fwrite(&h[i].grnofr,sizeof(short),1,fid); // 173-174
        fwrite(&h[i].grnlof,sizeof(short),1,fid); // 175-176
        fwrite(&h[i].gaps,sizeof(short),1,fid); // 177-178
        fwrite(&h[i].otrav,sizeof(short),1,fid); // 179-180
        fwrite(temp,sizeof(float),15,fid); // 179-180

        fwrite(&d[i*nt],sizeof(float),nt,fid);
       }
     
       fclose(fid);
     }
    else {
           printf(" !!! ERROR !!! can't open %s \n",filename);
         }



}
