#include <stdlib.h>
#include <stdio.h>
#include <math.h>

//#define LAG_CORR(i,n)  i+n-1


void cross_correlation(double *x0, double *y0, int n, double *acorr, int *lag)
 {
/*
  calculate the cross-correlation series of the two series x and y

  corr(k) = sum( x(i) * y(i+k) ), i=1,2,...,n
  k = -(n-1), -(n-2), ..., 0, 1, ..., n-1

  Input:
     x0, y0: series of length n
     n: length of the input series

  Output:
     corr: cross-correlation series of length 2n-1
                  corr[0], corr[1], ..., corr[2n-3], corr[2n-2]
           delay:  -(n-1),  -(n-2), ...,        n-2,        n-1
     *acorr : maximum of corr
     *lag   : lag of y ( x(i) and y(i+lag) have the max correlation coefficient )

  Xinding Fang
  2019-12-24
*/

int i, j, k;
double *x, *y, mx, my, d, *corr;
   
x = (double *) malloc(n*sizeof(double));
y = (double *) malloc(n*sizeof(double));
corr = (double *) malloc((2*n-1)*sizeof(double));

// Calculate the mean of x and y
mx = 0;
my = 0;   
for(i=0;i<n;i++) {
    mx = mx + x0[i];
    my = my + y0[i];
}
mx = mx/n;
my = my/n;

// remove means
for(i=0;i<n;i++) {
	x[i] = x0[i] - mx;
	y[i] = y0[i] - my;
}

// Calculate the denominator 
mx = 0;
my = 0;
for(i=0;i<n;i++) {
    mx = mx + x[i]*x[i];
    my = my + y[i]*y[i];
}
d = 1.0/sqrt(mx*my);

// Calculate the correlation series 
*acorr = 0.0;
*lag = -(n-1);
for(k=0; k<2*n-1; k++) {
    corr[k] = 0.0;
    for(i=0; i<n; i++) {
        j = i + k-(n-1);
        corr[k] = corr[k] + ( (j>=0 && j<n) ? (x[i]*y[j]) : 0.0);
    }
    corr[k] = corr[k]*d; // correlation coefficient

    if(corr[k]>*acorr) {
       *acorr = (*acorr>=corr[k]) ? *acorr : corr[k];
       *lag = k-(n-1);
    }
}

free(x);
free(y);
free(corr);

}

