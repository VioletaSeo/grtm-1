#pragma once

void BesselJ012d(const double x, double* j0, double* j1, double*j2, double* j0d, double* j1d, double* j2d,double* j3, double* j4,double* j1dd, double* j2dd);

void BesselJ01d(const double x, double* j0, double* j1, double* j0d, double* j1d,double* j2, double* j3, double* j2d);

double BesselJ0(const double x);

double BesselJ1(const double x);

double BesselJ2(const double x);

double BesselJ3(const double x);

double BesselJn(const int n, const double x);


